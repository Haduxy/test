// Decompiled by JEB v3.7.0.201909272058

function sub_4F03(uint256 par1, uint256 par2, uint256 par3) private returns (uint256) {
    *0x0 = par3;
    *0x20 = 0x8;
    var2 = keccak256(0x0, 0x40);
    var3 = storage[var2 + 0x6];
    *0x0 = var3;
    uint256 var1 = var3;
    var3 = keccak256(0x0, 0x40);
    var2 = storage[var3 + 0x6];
    var3 = var1;
    var1 = 0x0;
    uint256 var4 = var2;
    var2 = par2 / 0xa;
    uint256 var6 = var3;
    var3 = ((int256)par2) * 0x3 / 0x64;
    uint256 var5 = var6;
    var6 = var4;
    var4 = par2 / 0x64;
    uint256 var7 = var6;
    var6 = var5;
    uint256 var8 = (uint256)(par1 != par3);

    if(par1 != par3) {
        *0x0 = par3;
        *0x20 = 0x8;
        var8 = keccak256(0x0, 0x40);
        var8 = storage[var8 + 0x1];
        var8 = (uint256)(var8 != 0x0);
    }

    if(var8 != 0x0) {
        *0x0 = par3;
        *0x20 = 0x8;
        var8 = keccak256(0x0, 0x40);
        var8 = storage[var8 + 0x4];
        var8 = __impl_potSwap(var8, var2);
        *0x0 = par3;
        *0x20 = 0x8;
        var9 = keccak256(0x0, 0x40);
        storage[var9 + 0x4] = var8;
    }
    else {
        var8 = __impl_potSwap(var2, 0x0);
        var1 = var8;
    }

    var8 = (uint256)(par1 != var6);

    if(var8 != 0x0) {
        var8 = (uint256)(par3 != var6);
    }

    if(var8 != 0x0) {
        *0x0 = var6;
        *0x20 = 0x8;
        var8 = keccak256(0x0, 0x40);
        var8 = storage[var8 + 0x1];
        var8 = (uint256)(var8 != 0x0);
    }

    if(var8 != 0x0) {
        *0x0 = var6;
        *0x20 = 0x8;
        var8 = keccak256(0x0, 0x40);
        var8 = storage[var8 + 0x4];
        var8 = __impl_potSwap(var8, var3);
        *0x0 = var6;
        *0x20 = 0x8;
        var9 = keccak256(0x0, 0x40);
        storage[var9 + 0x4] = var8;
    }
    else {
        var8 = __impl_potSwap(var3, var1);
        var1 = var8;
    }

    var8 = (uint256)(par1 != var7);

    if(var8 != 0x0) {
        var8 = (uint256)(par3 != var7);
    }

    if(var8 != 0x0) {
        *0x0 = var7;
        *0x20 = 0x8;
        var8 = keccak256(0x0, 0x40);
        var8 = storage[var8 + 0x1];
        var8 = (uint256)(var8 != 0x0);
    }

    if(var8 != 0x0) {
        *0x0 = var7;
        *0x20 = 0x8;
        var8 = keccak256(0x0, 0x40);
        var8 = storage[var8 + 0x4];
        var8 = __impl_potSwap(var8, var4);
        *0x0 = var7;
        *0x20 = 0x8;
        var9 = keccak256(0x0, 0x40);
        storage[var9 + 0x4] = var8;
    }
    else {
        var8 = __impl_potSwap(var4, var1);
        var1 = var8;
    }

    return var1;
}
