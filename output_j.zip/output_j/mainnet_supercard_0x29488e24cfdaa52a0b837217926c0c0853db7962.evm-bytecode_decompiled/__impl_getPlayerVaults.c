// Decompiled by JEB v3.7.0.201909272058

function __impl_getPlayerVaults(uint256 par1) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    uint256 var6;
    var0 = storage[0x5];
    *0x0 = var0;
    *0x20 = 0xb;
    var2 = keccak256(0x0, 0x40);
    var2 = storage[var2 + 0x2];
    uint256 var1 = var2;
    var2 = 0x0;
    uint256 var3 = var0;
    var5 = timestamp();
    uint256 var4 = (uint256)(var1 < var5);

    if(var4 != 0x0) {
        *0x0 = var0;
        *0x20 = 0xb;
        var4 = keccak256(0x0, 0x40);
        var4 = storage[var4 + 0x3];
        var4 = (uint256)((var4 & 0xff) == 0x0);
    }

    if(var4 != 0x0) {
        *0x0 = var3;
        *0x20 = 0xb;
        var4 = keccak256(0x0, 0x40);
        var4 = storage[var4];
        var4 = (uint256)(var4 != 0x0);
    }

    if(var4 != 0x0) {
        *0x0 = var3;
        *0x20 = 0xb;
        var4 = keccak256(0x0, 0x40);
        var4 = storage[var4];

        if(par1 == var4) {
            *0x0 = var3;
            *0x20 = 0xb;
            var4 = keccak256(0x0, 0x40);
            var4 = storage[var4 + 0x7];
            var6 = sub_4385(0x30, var4);
            *0x0 = par1;
            *0x20 = 0x8;
            var7 = keccak256(0x0, 0x40);
            var7 = storage[var7 + 0x2];
            __impl_potSwap(var6 / 0x64, var7);
            *0x0 = par1;
            *0x20 = 0x9;
            var8 = keccak256(0x0, 0x40);
            *0x0 = var3;
            *0x20 = var8;
            var5 = keccak256(0x0, 0x40);
            var5 = storage[var5 + 0x2];
            var7 = var5;
            var8 = sub_43FC(var3, par1);
            var6 = __impl_getTimeLeft(var5, var8);
            *0x0 = par1;
            *0x20 = 0x8;
            var7 = keccak256(0x0, 0x40);
            var7 = storage[var7 + 0x3];
            __impl_potSwap(var6, var7);
            *0x0 = par1;
            *0x20 = 0x8;
            var6 = keccak256(0x0, 0x40);
            var6 = storage[var6 + 0x4];
            var2 = var6;
        }
        else {
            *0x0 = par1;
            *0x20 = 0x8;
            var7 = keccak256(0x0, 0x40);
            var8 = storage[var7 + 0x2];
            *0x20 = 0x9;
            var9 = keccak256(0x0, 0x40);
            *0x0 = var3;
            *0x20 = var9;
            var6 = keccak256(0x0, 0x40);
            var5 = storage[var6 + 0x2];
            sub_43FC(var3, par1);
            goto loc_1E53;
        }
    }
    else {
    loc_1E53:
        *0x0 = par1;
        *0x20 = 0x8;
        var4 = keccak256(0x0, 0x40);
        var5 = storage[var4 + 0x2];
        var5 = storage[var4 + 0x5];
        sub_452A(var5, par1);
    }

    return var2;
}
