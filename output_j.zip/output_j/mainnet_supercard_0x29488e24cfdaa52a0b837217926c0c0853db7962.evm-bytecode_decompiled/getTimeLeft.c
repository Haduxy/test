// Decompiled by JEB v3.7.0.201909272058

function getTimeLeft() public payable {

    if($msg.value != 0x0) {
        revert(0x0, 0x0);
    }

    var1 = storage[0x5];
    *0x0 = var1;
    *0x20 = 0xb;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3 + 0x2];
    uint256 var2 = var1;
    var4 = timestamp();
    uint256 $tmp = var4;
    var4 = var3;
    var3 = $tmp;

    if($tmp < var4) {
        var4 = storage[0x2];
        *0x0 = var2;
        *0x20 = 0xb;
        var5 = keccak256(0x0, 0x40);
        var5 = storage[var5 + 0x4];

        if(var4 + var5 < var3) {
            *0x0 = var2;
            *0x20 = 0xb;
            var4 = keccak256(0x0, 0x40);
            var4 = storage[var4 + 0x2];
            __impl_getTimeLeft(var3, var4);
        }

        var4 = storage[0x2];
        *0x0 = var2;
        *0x20 = 0xb;
        var5 = keccak256(0x0, 0x40);
        var5 = storage[var5 + 0x4];
        __impl_getTimeLeft(var3, var4 + var5);
    }
}
