// Decompiled by JEB v3.7.0.201909272058

function sub_387D(uint256 par1, uint256 par2) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    uint256 var3 = __impl_getTimeLeft(par2, par1);
    sub_4620(var3);
    sub_4620(par1);
    return 0x38a3;
}
