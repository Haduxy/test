// Decompiled by JEB v3.7.0.201909272058

function iWantXKeys() public /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var2 = storage[0x5];
    var3 = storage[0x2];
    *0x0 = var2;
    *0x20 = 0xb;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5 + 0x4];
    uint256 var4 = var5;
    var5 = var3;
    var3 = var2;
    var6 = timestamp();
    uint256 $tmp = var6;
    var6 = var4;
    var4 = $tmp;
    var5 = (uint256)(var5 + var6 < $tmp);

    if(var5 != 0x0) {
        *0x0 = var2;
        *0x20 = 0xb;
        var5 = keccak256(0x0, 0x40);
        var5 = storage[var5 + 0x2];
        var5 = (uint256)(var4 <= var5);

        if(!var5) {
            *0x0 = var3;
            *0x20 = 0xb;
            var5 = keccak256(0x0, 0x40);
            var5 = storage[var5 + 0x2];
            var5 = (uint256)(var4 > var5);

            if(var5 != 0x0) {
                *0x0 = var3;
                *0x20 = 0xb;
                var5 = keccak256(0x0, 0x40);
                var5 = storage[var5];
                var5 = (uint256)(var5 == 0x0);
            }
        }
    }

    if(var5 != 0x0) {
        *0x0 = var3;
        *0x20 = 0xb;
        var5 = keccak256(0x0, 0x40);
        var5 = storage[var5 + 0x5];
        __impl_potSwap(var1, var5);
    }
    else {
        sub_4620(var1);
    }
}
