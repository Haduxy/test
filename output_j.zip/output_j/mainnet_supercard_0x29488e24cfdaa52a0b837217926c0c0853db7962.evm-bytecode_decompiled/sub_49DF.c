// Decompiled by JEB v3.7.0.201909272058

function sub_49DF(uint256 par0, uint256 par1, uint256 par2, uint256 par3, uint256 par4, uint256 par5) private returns (uint256) {
    // Decompilation error
}
