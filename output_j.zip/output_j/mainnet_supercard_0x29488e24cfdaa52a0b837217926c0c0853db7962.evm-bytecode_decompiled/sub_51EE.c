// Decompiled by JEB v3.7.0.201909272058

function sub_51EE() private pure returns (uint256) {
    uint256* var0 = *0x40;
    *0x40 = var0 + &loc_9;
    *var0 = 0x0;
    uint256* var1 = var0 + 1;
    *var1 = 0x0;
    ++var1;
    *var1 = 0x0;
    ++var1;
    *var1 = 0x0;
    ++var1;
    *var1 = 0x0;
    ++var1;
    *var1 = 0x0;
    ++var1;
    *var1 = 0x0;
    ++var1;
    *var1 = 0x0;
    *(var1 + 1) = 0x0;
    return var0;
}
