// Decompiled by JEB v3.7.0.201909272058

function round_() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    (uint256 var0, var1, uint256 var2, uint256 var3, uint256 var4, uint256 var5, uint256 var6, uint256 var7, uint256 var8, uint256 var9, uint256 var10, uint256 var11, uint256 var12) = __impl_round_(var1);
    uint256 var14 = var1;
    var1 = *0x40;
    *var1 = var14;
    *(var1 + 0x20) = var2;
    *(var1 + 0x40) = var3;
    *(var1 + 0x60) = (uint256)(var4 != 0x0);
    *(var1 + 0x80) = var5;
    *(var1 + 0xa0) = var6;
    *(var1 + 0xc0) = var7;
    *(var1 + 0xe0) = var8;
    *(var1 + 0x100) = var9;
    *(var1 + 0x120) = var10;
    *(var1 + 0x140) = var11;
    *(var1 + 0x160) = var12;
    var2 = var1;
    var1 = *0x40;
    return(var1, var2 - var1 + 0x180);
}
