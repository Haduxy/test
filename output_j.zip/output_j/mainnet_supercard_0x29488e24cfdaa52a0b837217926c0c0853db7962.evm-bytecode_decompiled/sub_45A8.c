// Decompiled by JEB v3.7.0.201909272058

function sub_45A8(uint256 par1) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    sub_4385(0xde0b6b3a7640000, par1);
    sub_4EA4(0x460b, 0x1dca, 0x3b2a1d15167e7c5699bfde00000);
    return 0x2;
}
