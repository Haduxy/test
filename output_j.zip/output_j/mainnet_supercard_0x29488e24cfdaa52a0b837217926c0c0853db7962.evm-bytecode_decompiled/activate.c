// Decompiled by JEB v3.7.0.201909272058

function activate() public /*NON-PAYABLE*/ {
    var1 = storage[0x0];
    var2 = msg.sender;

    if((address(var1)) != msg.sender) {
        var2 = *0x40;
        *var2 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *(var2 + 0x4) = 0x20;
        *(var2 + 0x24) = 0x17;
        *(var2 + 0x44) = 0x6f6e6c792061646d696e2063616e206163746976617465000000000000000000;
        var1 = *0x40;
        revert(var1, var2 - var1 + 0x64);
    }

    var1 = storage[0xf];

    if((var1 & 0xff) != 0x0) {
        var2 = *0x40;
        *var2 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *(var2 + 0x4) = 0x20;
        *(var2 + 0x24) = 0x1b;
        *(var2 + 0x44) = 0x53757065724361726420616c7265616479206163746976617465640000000000;
        var1 = *0x40;
        revert(var1, var2 - var1 + 0x64);
    }

    var2 = storage[0xf];
    g2_0 = 1;
    g1_0 = 0x1;
    var2 = storage[0x2];
    var3 = storage[0x1];
    var1 = var3;
    *0x0 = 0x1;
    *0x20 = 0xb;
    var3 = timestamp();
    int256 $tmp = var2;
    var2 = var3;
    var3 = var1;
    var1 = $tmp;
    $tmp = var2 + var3;
    g4_0 = $tmp - var1;
    g3_0 = $tmp + 0x121d;
}
