// Decompiled by JEB v3.7.0.201909272058

function reLoadXname() public /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    var3 = calldataload(0x44);
    __impl_reLoadXname(var3, var2, var1);
    stop();
}
