// Decompiled by JEB v3.7.0.201909272058

function __impl_fees_(uint256 par1) private view returns (uint256) {
    *0x20 = 0xd;
    *0x0 = par1;
    par1 = keccak256(0x0, 0x40);
    var0 = storage[par1];
    var0 = storage[par1 + 0x1];
    return var0;
}
