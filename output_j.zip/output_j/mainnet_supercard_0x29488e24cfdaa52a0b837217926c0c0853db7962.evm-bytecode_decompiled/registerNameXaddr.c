// Decompiled by JEB v3.7.0.201909272058

function registerNameXaddr() public payable {
    uint256 var12;
    uint256* var13;
    uint256 var1 = *0x40;
    var4 = calldataload(0x4);
    var5 = calldataload(var4 + 0x4);
    *0x40 = (var5 + 0x1f) / 0x20 * 0x20 + var1 + 0x20;
    *var1 = var5;
    var6 = msg.data.length;
    calldatacopy(var1 + 0x20, var4 + 0x24, var5);
    var9 = calldataload(0x24);
    uint256 var2 = address(var9);
    var3 = calldataload(0x44);
    var3 = (uint256)(var3 != 0x0);
    var10 = msg.sender;
    var11 = extcodesize(msg.sender);

    if(var11 != 0x0) {
        var13 = *0x40;
        *var13 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *((uint256*)(((char*)var13) + 0x4)) = 0x20;
        *((uint256*)(((char*)var13) + 0x24)) = 0x11;
        codecopy(0x0, 0x52c8, 0x20);
        *((uint256*)(((char*)var13) + 0x44)) = *0x0;
        var12 = *0x40;
        revert(var12, ((uint256)(((int256)var13) - var12)) + 0x64);
    }

    var12 = __impl_registerNameXID(var1);
    uint256* var14 = *0x40;
    *var14 = 0xaa4d490b00000000000000000000000000000000000000000000000000000000;
    var15 = msg.sender;
    *((uint256*)(((char*)var14) + 0x4)) = msg.sender;
    *((uint256*)(((char*)var14) + 0x24)) = var12;
    *((uint256*)(((char*)var14) + 0x44)) = address(var2);
    *((uint256*)(((char*)var14) + 0x64)) = (uint256)(var3 != 0x0);
    var4 = var12;
    var5 = msg.sender;
    var6 = $msg.value;
    uint256* var17 = *0x40;
    uint256 var18 = ((uint256)(((int256)var14) - ((int256)var17))) + 0x84;
    uint256* var19 = var17, var20 = $msg.value;
    var22 = extcodesize(0xb838c100eb1a1d08b215fbbcc06698e9c181358c);

    if(var22 == 0x0) {
        revert(0x0, 0x0);
    }

    var22 = gasleft();
    var16 = call(var22, 0xb838c100eb1a1d08b215fbbcc06698e9c181358c, var20, var19, var18, var17, 0x40);

    if(var16 == 0x0) {
        var17 = returndatasize();
        returndatacopy(0x0, 0x0, var17);
        var17 = returndatasize();
        revert(0x0, var17);
    }

    var12 = *0x40;
    var13 = returndatasize();

    if(!((unsigned char)(((int256)var13) >= 0x40))) {
        revert(0x0, 0x0);
    }

    var13 = *var12;
    var14 = *(var12 + 0x20);
    *0x0 = address(var5);
    *0x20 = 0x6;
    var19 = keccak256(0x0, 0x40);
    var19 = storage[var19];
    *0x0 = var14;
    *0x20 = 0x8;
    var17 = var19;
    var19 = keccak256(0x0, 0x40);
    var20 = storage[var19];
    uint256* var21 = var19;
    var19 = var20;
    var20 = storage[((uint256)(((char*)var21) + 0x1))];
    var21 = *0x40;
    *var21 = (uint256)(((unsigned char)(((int256)var13) != 0x0)));
    *(var21 + 1) = var14;
    *(var21 + &loc_2) = (uint256)(address(((int256)var19)));
    *(var21 + 3) = var20;
    *(var21 + &loc_4) = var6;
    var18 = timestamp();
    *(var21 + &loc_5) = var18;
    var16 = *0x40;
    emit onNewName(var16, ((uint256)(((int256)var21) - var16)) + 0xc0);
}
