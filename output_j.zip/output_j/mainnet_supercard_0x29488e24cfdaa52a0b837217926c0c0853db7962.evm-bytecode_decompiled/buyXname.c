// Decompiled by JEB v3.7.0.201909272058

function buyXname() public /* State mutability undetermined -> using most permissive */ payable {
    // Decompilation error
}
