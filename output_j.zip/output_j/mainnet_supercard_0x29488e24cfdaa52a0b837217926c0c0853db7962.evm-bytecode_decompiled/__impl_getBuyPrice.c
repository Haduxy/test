// Decompiled by JEB v3.7.0.201909272058

function __impl_getBuyPrice() private view returns (uint256) {
    var0 = storage[0x5];
    var1 = storage[0x2];
    *0x0 = var0;
    *0x20 = 0xb;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3 + 0x4];
    uint256 var2 = var3;
    var3 = var1;
    var1 = var0;
    var4 = timestamp();
    uint256 $tmp = var4;
    var4 = var2;
    var2 = $tmp;
    var3 = (uint256)(var3 + var4 < $tmp);

    if(var3 != 0x0) {
        *0x0 = var0;
        *0x20 = 0xb;
        var3 = keccak256(0x0, 0x40);
        var3 = storage[var3 + 0x2];
        var3 = (uint256)(var2 <= var3);

        if(!var3) {
            *0x0 = var1;
            *0x20 = 0xb;
            var3 = keccak256(0x0, 0x40);
            var3 = storage[var3 + 0x2];
            var3 = (uint256)(var2 > var3);

            if(var3 != 0x0) {
                *0x0 = var1;
                *0x20 = 0xb;
                var3 = keccak256(0x0, 0x40);
                var3 = storage[var3];
                var3 = (uint256)(var3 == 0x0);
            }
        }
    }

    if(var3 != 0x0) {
        *0x0 = var1;
        *0x20 = 0xb;
        var3 = keccak256(0x0, 0x40);
        var3 = storage[var3 + 0x5];
        uint256 var5 = __impl_potSwap(0xde0b6b3a7640000, var3);
        var3 = sub_387D(0xde0b6b3a7640000, var5);
        var0 = var3;
    }
    else {
        var0 = 0x44364c5bb000;
    }

    return var0;
}
