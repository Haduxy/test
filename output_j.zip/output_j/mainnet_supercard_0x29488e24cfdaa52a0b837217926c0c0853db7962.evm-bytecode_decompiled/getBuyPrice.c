// Decompiled by JEB v3.7.0.201909272058

function getBuyPrice() public view /*NON-PAYABLE*/ {
    uint256 var0 = __impl_getBuyPrice();
    uint256 var2 = var0;
    var0 = *0x40;
    *var0 = var2;
    return(var0, 0x20);
}
