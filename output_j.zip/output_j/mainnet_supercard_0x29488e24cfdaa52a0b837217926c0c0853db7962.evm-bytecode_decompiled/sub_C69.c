// Decompiled by JEB v3.7.0.201909272058

function sub_C69(uint256 par0, uint256 par1, uint256 par2, uint256 par3) private /*! STACK DISCREPANCY !*/ {
    // Decompilation error
}
