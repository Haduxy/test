// Decompiled by JEB v3.7.0.201909272058

function getCurrentRoundInfo() public view /*NON-PAYABLE*/ {
    (uint256* var0, uint256* var1, uint256 var2, uint256 var3, uint256 var4, uint256 var5, uint256 var6, uint256 var7, uint256 var8, uint256 var9, uint256 var10, uint256 var11, uint256 var12, uint256 var13) = __impl_getCurrentRoundInfo();
    uint256* var15 = var0;
    var0 = *0x40;
    *var0 = var15;
    *(var0 + 1) = var1;
    *(var0 + &loc_2) = var2;
    *(var0 + 3) = var3;
    *(var0 + &loc_4) = var4;
    *(var0 + &loc_5) = var5;
    *(var0 + 6) = var6;
    *(var0 + &loc_7) = address(var7);
    *(var0 + &loc_8) = var8;
    *(var0 + &loc_9) = var9;
    *(var0 + 10) = var10;
    *(var0 + 11) = var11;
    *(var0 + &loc_C) = var12;
    *(var0 + &loc_D) = var13;
    var1 = var0;
    var0 = *0x40;
    return(var0, ((uint256)(((int256)var1) - ((int256)var0))) + 0x1c0);
}
