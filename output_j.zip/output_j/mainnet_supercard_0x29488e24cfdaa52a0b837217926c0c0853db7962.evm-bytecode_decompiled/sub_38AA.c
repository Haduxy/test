// Decompiled by JEB v3.7.0.201909272058

function sub_38AA(uint256 par1) private pure returns (uint256) {
    uint256 var1 = (uint256)(par1 < 0x0);

    if(!var1) {
        var1 = (uint256)(par1 > 0x3);
    }

    return var1 != 0x0 ? 0x2: par1;
}
