// Decompiled by JEB v3.7.0.201909272058

function plyrRnds_() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    (uint256 var0, var1, var2, uint256 var3, uint256 var4) = __impl_plyrRnds_(var2, var1);
    uint256 var6 = var1;
    var1 = *0x40;
    *var1 = var6;
    *(var1 + 0x20) = var2;
    *(var1 + 0x40) = var3;
    *(var1 + 0x60) = var4;
    var2 = var1;
    var1 = *0x40;
    return(var1, var2 - var1 + 0x80);
}
