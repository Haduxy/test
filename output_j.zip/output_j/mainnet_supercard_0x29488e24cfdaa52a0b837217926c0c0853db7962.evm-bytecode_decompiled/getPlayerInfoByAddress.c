// Decompiled by JEB v3.7.0.201909272058

function getPlayerInfoByAddress() public view /*NON-PAYABLE*/ {
    var2 = calldataload(0x4);
    (uint256* var0, uint256* var1, var2, uint256 var3, uint256 var4, uint256 var5, uint256 var6) = __impl_getPlayerInfoByAddress(address(var2));
    uint256* var8 = var0;
    var0 = *0x40;
    *var0 = var8;
    *(var0 + 1) = var1;
    *(var0 + &loc_2) = var2;
    *(var0 + 3) = var3;
    *(var0 + &loc_4) = var4;
    *(var0 + &loc_5) = var5;
    *(var0 + 6) = var6;
    var1 = var0;
    var0 = *0x40;
    return(var0, ((uint256)(((int256)var1) - ((int256)var0))) + 0xe0);
}
