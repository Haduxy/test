// Decompiled by JEB v3.7.0.201909272058

function sub_4B31(uint256 par1, uint256 par2, uint256 par3, uint256 par4, uint256 par5, uint256 par6) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    sub_51EE();
    *0x0 = par4;
    *0x20 = 0xd;
    var2 = keccak256(0x0, 0x40);
    var2 = storage[var2];
    uint256 var6 = sub_4385(var2, par3);
    uint256 var1 = var6 / 0x64;
    var7 = storage[0x3];
    uint256 var5 = __impl_potSwap(par3 / 0x32, var7);
    g0_0 = var5;
    *0x0 = par4;
    *0x20 = 0xd;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5 + 0x1];
    uint256 var8 = sub_4385(var5, par3);
    var7 = var8 / 0x64;
    uint256 var9 = sub_4385(0x14, par3);
    var6 = __impl_potSwap(var7, var9 / 0x64);
    var5 = __impl_getTimeLeft(var6, par3);
    var5 = __impl_getTimeLeft(var1, var5);
    uint256 var3 = var5;
    var5 = sub_50B5(par5, var1, par2, par1);
    uint256 var4 = var5;

    if(var5 > 0x0) {
        var5 = __impl_getTimeLeft(var4, var1);
        var1 = var5;
    }

    *0x0 = par1;
    *0x20 = 0xb;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5 + 0x7];
    __impl_potSwap(var4, var3);
    *0x0 = par1;
    *0x20 = 0xb;
    var6 = keccak256(0x0, 0x40);
    storage[var6 + 0x7] = 0x4c5e;
    var5 = __impl_potSwap(*(par6 + 0xe0), var1);
    *(par6 + 0xe0) = var5;
    *(par6 + 0x100) = var3;
    return par6;
}
