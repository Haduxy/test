// Decompiled by JEB v3.7.0.201909272058

function pIDxAddr_() public view /*NON-PAYABLE*/ {
    var2 = calldataload(0x4);
    *0x20 = 0x6;
    *0x0 = address(var2);
    var1 = keccak256(0x0, 0x40);
    var1 = storage[var1];
    return;
}
