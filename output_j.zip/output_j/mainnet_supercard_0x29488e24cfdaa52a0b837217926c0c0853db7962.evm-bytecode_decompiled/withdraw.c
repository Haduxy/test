// Decompiled by JEB v3.7.0.201909272058

function withdraw() public /* State mutability undetermined -> using most permissive */ payable /*! STACK DISCREPANCY !*/ {
    // Decompilation error
}
