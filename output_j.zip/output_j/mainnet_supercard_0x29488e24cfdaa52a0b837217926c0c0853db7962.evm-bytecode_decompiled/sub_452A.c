// Decompiled by JEB v3.7.0.201909272058

function sub_452A(uint256 par1, uint256 par2) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    *0x0 = par1;
    *0x20 = 0x9;
    var3 = keccak256(0x0, 0x40);
    *0x0 = par2;
    *0x20 = var3;
    var3 = keccak256(0x0, 0x40);
    var4 = storage[var3 + 0x2];
    uint256 var5 = var3;
    var3 = var4;
    var4 = storage[var5 + 0x1];
    *0x20 = 0xb;
    uint256 var2 = var3;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3 + 0x8];
    var4 = sub_4385(var4, var3);
    __impl_getTimeLeft(var2, var4 / 0xde0b6b3a7640000);
}
