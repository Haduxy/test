// Decompiled by JEB v3.7.0.201909272058

function reLoadXid() public /*NON-PAYABLE*/ {
    uint256* var10;
    uint256 var8, var9;
    int256 var6;
    uint256* var7;
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    var3 = calldataload(0x44);
    uint256 var4 = sub_51EE();
    var5 = storage[0xf];

    if((var5 & 0xff) != 0x0 != -1) {
        var7 = *0x40;
        *var7 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *((uint256*)(((char*)var7) + 0x4)) = 0x20;
        *((uint256*)(((char*)var7) + 0x24)) = 0x29;
        codecopy(0x0, 0x5288, 0x20);
        *((uint256*)(((char*)var7) + 0x44)) = *0x0;
        codecopy(0x0, 0x5248, 0x20);
        *((uint256*)(((char*)var7) + 0x64)) = *0x0;
        var6 = *0x40;
        revert(var6, ((uint256)(((int256)var7) - var6)) + 0x84);
    }

    var6 = msg.sender;
    var7 = extcodesize(msg.sender);

    if(!((unsigned char)(((int256)var7) == 0x0))) {
        var9 = *0x40;
        *var9 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *(var9 + 0x4) = 0x20;
        *(var9 + 0x24) = 0x11;
        codecopy(0x0, 0x52c8, 0x20);
        *(var9 + 0x44) = *0x0;
        var8 = *0x40;
        revert(var8, var9 - var8 + 0x64);
    }

    var8 = var3;

    if(var3 < 0x3b9aca00) {
        var10 = *0x40;
        *var10 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *((uint256*)(((char*)var10) + 0x4)) = 0x20;
        *((uint256*)(((char*)var10) + 0x24)) = 0x21;
        codecopy(0x0, 0x5268, 0x20);
        *((uint256*)(((char*)var10) + 0x44)) = *0x0;
        *((uint256*)(((char*)var10) + 0x64)) = 0x7900000000000000000000000000000000000000000000000000000000000000;
        var9 = *0x40;
        revert(var9, ((uint256)(((int256)var10) - var9)) + 0x84);
    }

    if(var8 > 0x152d02c7e14af6800000) {
        var10 = *0x40;
        *var10 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *((uint256*)(((char*)var10) + 0x4)) = 0x20;
        *((uint256*)(((char*)var10) + 0x24)) = 0xe;
        codecopy(0x0, 0x52a8, 0x20);
        *((uint256*)(((char*)var10) + 0x44)) = *0x0;
        var9 = *0x40;
        revert(var9, ((uint256)(((int256)var10) - var9)) + 0x64);
    }

    var9 = msg.sender;
    *0x0 = msg.sender;
    *0x20 = 0x6;
    var9 = keccak256(0x0, 0x40);
    var9 = storage[var9];
    var5 = var9;
    var9 = (uint256)(var1 == 0x0);

    if(!var9) {
        var9 = (uint256)(var1 == var5);
    }

    *0x0 = var5;
    *0x20 = 0x8;

    if(var9 != 0x0) {
        var9 = keccak256(0x0, 0x40);
        var9 = storage[var9 + 0x6];
        var1 = var9;
    }
    else {
        var9 = keccak256(0x0, 0x40);
        var9 = storage[var9 + 0x6];

        if(var1 != var9) {
            *0x0 = var5;
            *0x20 = 0x8;
            var9 = keccak256(0x0, 0x40);
            storage[var9 + 0x6] = var1;
        }
    }

    var9 = sub_38AA(var2);
    sub_38CF(var4, var3, var9, var1, var5);
}
