// Decompiled by JEB v3.7.0.201909272058

function sub_9B5(uint256* par1) private returns (uint256) {
    sub_51EE();
    var1 = msg.sender;
    *0x0 = msg.sender;
    *0x20 = 0x6;
    var2 = keccak256(0x0, 0x40);
    var2 = storage[var2];

    if(!((unsigned char)(((int256)var2) != 0x0))) {
        int256 var5 = *0x40;
        *var5 = 0xe56556a900000000000000000000000000000000000000000000000000000000;
        var6 = msg.sender;
        *(var5 + 0x4) = msg.sender;
        uint256 var8 = *0x40;
        uint256 var9 = var5 - var8 + 0x24;
        uint256 var10 = var8;
        var13 = extcodesize(0xb838c100eb1a1d08b215fbbcc06698e9c181358c);

        if(var13 == 0x0) {
            revert(0x0, 0x0);
        }

        var13 = gasleft();
        var7 = call(var13, 0xb838c100eb1a1d08b215fbbcc06698e9c181358c, 0x0, var10, var9, var8, 0x20);

        if(var7 == 0x0) {
            var8 = returndatasize();
            returndatacopy(0x0, 0x0, var8);
            var8 = returndatasize();
            revert(0x0, var8);
        }

        uint256* var4 = *0x40;
        var5 = returndatasize();

        if(((uint256)var5) < 0x20) {
            revert(0x0, 0x0);
        }

        var4 = *var4;
        var6 = *0x40;
        *var6 = 0x82e37b2c00000000000000000000000000000000000000000000000000000000;
        *(var6 + 0x4) = var4;
        var1 = var4;
        var8 = *0x40;
        var9 = var6 - var8 + 0x24;
        var10 = var8;
        var13 = extcodesize(0xb838c100eb1a1d08b215fbbcc06698e9c181358c);

        if(var13 == 0x0) {
            revert(0x0, 0x0);
        }

        var13 = gasleft();
        var7 = call(var13, 0xb838c100eb1a1d08b215fbbcc06698e9c181358c, 0x0, var10, var9, var8, 0x20);

        if(var7 == 0x0) {
            var8 = returndatasize();
            returndatacopy(0x0, 0x0, var8);
            var8 = returndatasize();
            revert(0x0, var8);
        }

        var4 = *0x40;
        var5 = returndatasize();

        if(((uint256)var5) < 0x20) {
            revert(0x0, 0x0);
        }

        var4 = *var4;
        var6 = *0x40;
        *var6 = 0xe3c08adf00000000000000000000000000000000000000000000000000000000;
        *(var6 + 0x4) = var1;
        var2 = var4;
        var8 = *0x40;
        var9 = var6 - var8 + 0x24;
        var10 = var8;
        var13 = extcodesize(0xb838c100eb1a1d08b215fbbcc06698e9c181358c);

        if(var13 == 0x0) {
            revert(0x0, 0x0);
        }

        var13 = gasleft();
        var7 = call(var13, 0xb838c100eb1a1d08b215fbbcc06698e9c181358c, 0x0, var10, var9, var8, 0x20);

        if(var7 == 0x0) {
            var8 = returndatasize();
            returndatacopy(0x0, 0x0, var8);
            var8 = returndatasize();
            revert(0x0, var8);
        }

        var4 = *0x40;
        var5 = returndatasize();

        if(((uint256)var5) < 0x20) {
            revert(0x0, 0x0);
        }

        var4 = *var4;
        var5 = msg.sender;
        *0x0 = msg.sender;
        *0x20 = 0x6;
        var9 = keccak256(0x0, 0x40);
        storage[var9] = var1;
        *0x0 = var1;
        *0x20 = 0x8;
        var6 = keccak256(0x0, 0x40);
        var7 = storage[var6];
        storage[var6] = (var7 & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000) | var5;
        uint256* var3 = var4;

        if(!((unsigned char)(((int256)var2) == 0x0))) {
            *0x0 = var2;
            *0x20 = 0x7;
            var7 = keccak256(0x0, 0x40);
            storage[var7] = var1;
            *0x0 = var1;
            *0x20 = 0x8;
            var7 = keccak256(0x0, 0x40);
            storage[var7 + 0x1] = var2;
            *0x20 = 0xa;
            var8 = keccak256(0x0, 0x40);
            *0x0 = var2;
            *0x20 = var8;
            var5 = keccak256(0x0, 0x40);
            var6 = storage[var5];
            storage[var5] = (var6 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00) | 0x1;
        }

        var4 = ((unsigned char)(((int256)var3) == 0x0)) ? ((uint256)(((unsigned char)(((int256)var3) != 0x0)))): ((uint256)(((unsigned char)(((int256)var1) != ((int256)var3)))));

        if(!((unsigned char)(((int256)var4) == 0x0))) {
            *0x0 = var1;
            *0x20 = 0x8;
            var4 = keccak256(0x0, 0x40);
            storage[((uint256)(((char*)var4) + 0x6))] = var3;
        }

        *par1 = *par1 + 0x1;
    }

    return par1;
}
