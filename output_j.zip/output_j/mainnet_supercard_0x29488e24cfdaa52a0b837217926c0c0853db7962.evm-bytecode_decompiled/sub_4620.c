// Decompiled by JEB v3.7.0.201909272058

function sub_4620(uint256 par1) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    sub_4EF7(0xde0b6b3a7640000);
    uint256 var5 = sub_4385(0xde0b6b3a7640000, par1);
    sub_4385(var5, 0x886c8f673070);
    var5 = sub_4EF7(par1);
    sub_4385(var5, 0x4a817c8);
}
