// Decompiled by JEB v3.7.0.201909272058

function potSplit_() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    *0x20 = 0xe;
    *0x0 = var1;
    var1 = keccak256(0x0, 0x40);
    var2 = storage[var1];
    var2 = storage[var1 + 0x1];
    return;
}
