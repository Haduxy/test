// Decompiled by JEB v3.7.0.201909272058

function sub_43FC(uint256 par1, uint256 par2) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    *0x0 = par1;
    *0x20 = 0x9;
    var3 = keccak256(0x0, 0x40);
    *0x0 = par2;
    *0x20 = var3;
    var3 = keccak256(0x0, 0x40);
    var4 = storage[var3 + 0x1];
    *0x20 = 0xb;
    var6 = keccak256(0x0, 0x40);
    var7 = storage[var6 + 0x5];
    var3 = var7;
    var7 = storage[var6 + 0x1];
    *0x0 = var7;
    *0x20 = 0xe;
    uint256 var2 = var6;
    var6 = keccak256(0x0, 0x40);
    var6 = storage[var6];
    *0x0 = par2;
    *0x20 = 0xb;
    uint256 var5 = var2;
    var2 = var4;
    var4 = storage[var5 + 0x7];
    var5 = var6;
    var6 = var3;
    var3 = var2;
    var7 = var5;
    var5 = var6;
    uint256 var9 = sub_4385(var7, var4);
    var6 = sub_4385(0xde0b6b3a7640000, var9 / 0x64);

    if(var5 == 0x0) {
        invalid();
    }

    *0x0 = par2;
    *0x20 = 0xb;
    var7 = keccak256(0x0, 0x40);
    var7 = storage[var7 + 0x8];
    var4 = __impl_potSwap(var6 / var5, var7);
    var2 = sub_4385(var3, var4);
    return var2 / 0xde0b6b3a7640000;
}
