// Decompiled by JEB v3.7.0.201909272058

function receivePlayerInfo() public /*NON-PAYABLE*/ {
    uint256* var6;
    var1 = calldataload(0x4);
    var3 = calldataload(0x24);
    uint256 var2 = address(var3);
    var3 = calldataload(0x44);
    var4 = calldataload(0x64);
    var5 = msg.sender;

    if(msg.sender != 0xb838c100eb1a1d08b215fbbcc06698e9c181358c) {
        var6 = *0x40;
        *var6 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *((uint256*)(((char*)var6) + 0x4)) = 0x20;
        *((uint256*)(((char*)var6) + 0x24)) = 0x27;
        *((uint256*)(((char*)var6) + 0x44)) = 0x796f7572206e6f7420706c617965724e616d657320636f6e74726163742e2e2e;
        *((uint256*)(((char*)var6) + 0x64)) = 0x20686d6d6d2e2e00000000000000000000000000000000000000000000000000;
        var5 = *0x40;
        revert(var5, ((uint256)(((int256)var6) - var5)) + 0x84);
    }

    *0x0 = address(var2);
    *0x20 = 0x6;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5];

    if(var1 != var5) {
        *0x0 = address(var2);
        *0x20 = 0x6;
        var5 = keccak256(0x0, 0x40);
        storage[var5] = var1;
    }

    *0x0 = var3;
    *0x20 = 0x7;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5];

    if(var1 != var5) {
        *0x0 = var3;
        *0x20 = 0x7;
        var5 = keccak256(0x0, 0x40);
        storage[var5] = var1;
    }

    *0x0 = var1;
    *0x20 = 0x8;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5];

    if((address(var2)) != (address(var5))) {
        *0x0 = var1;
        *0x20 = 0x8;
        var5 = keccak256(0x0, 0x40);
        var6 = storage[var5];
        storage[var5] = (address(var2)) | ((uint256)(((int256)var6) & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000));
    }

    *0x0 = var1;
    *0x20 = 0x8;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5 + 0x1];

    if(var3 != var5) {
        *0x0 = var1;
        *0x20 = 0x8;
        var5 = keccak256(0x0, 0x40);
        storage[var5 + 0x1] = var3;
    }

    *0x0 = var1;
    *0x20 = 0x8;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5 + 0x6];

    if(var4 != var5) {
        *0x0 = var1;
        *0x20 = 0x8;
        var5 = keccak256(0x0, 0x40);
        storage[var5 + 0x6] = var4;
    }

    *0x0 = var1;
    *0x20 = 0xa;
    var8 = keccak256(0x0, 0x40);
    *0x0 = var3;
    *0x20 = var8;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5];

    if((var5 & 0xff) == 0x0) {
        *0x0 = var1;
        *0x20 = 0xa;
        var8 = keccak256(0x0, 0x40);
        *0x0 = var3;
        *0x20 = var8;
        var5 = keccak256(0x0, 0x40);
        var6 = storage[var5];
        storage[var5] = ((uint256)(((int256)var6) & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00)) | 0x1;
    }
}
