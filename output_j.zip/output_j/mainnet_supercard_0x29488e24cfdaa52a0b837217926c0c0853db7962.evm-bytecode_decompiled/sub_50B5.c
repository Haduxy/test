// Decompiled by JEB v3.7.0.201909272058

function sub_50B5(uint256 par1, uint256 par2, uint256 par3, uint256 par4) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    *0x0 = par1;
    *0x20 = 0xb;
    var1 = keccak256(0x0, 0x40);
    var1 = storage[var1 + 0x5];
    uint256 var3 = var1;
    uint256 var4 = sub_4385(0xde0b6b3a7640000, par3);

    if(var1 == 0x0) {
        invalid();
    }

    *0x0 = par1;
    *0x20 = 0xb;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5 + 0x8];
    var1 = var4 / var3;
    var3 = __impl_potSwap(var5, var1);
    *0x0 = par1;
    *0x20 = 0xb;
    var4 = keccak256(0x0, 0x40);
    storage[var4 + 0x8] = var3;
    sub_4385(par4, var1);
    *0x0 = par2;
    *0x20 = 0x9;
    var8 = keccak256(0x0, 0x40);
    *0x0 = par1;
    *0x20 = var8;
    var8 = keccak256(0x0, 0x40);
    var8 = storage[var8 + 0x2];
    *0x20 = 0xb;
    var6 = keccak256(0x0, 0x40);
    var6 = storage[var6 + 0x8];
    sub_4385(par4, var6);
    *0x0 = par2;
    *0x20 = 0x9;
    var7 = keccak256(0x0, 0x40);
    *0x0 = par1;
    *0x20 = var7;
    var7 = keccak256(0x0, 0x40);
    storage[var7 + 0x2] = 0x519b;
    *0x20 = 0xb;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3 + 0x5];
    sub_4385(var3, var1);
    return 0x51e3;
}
