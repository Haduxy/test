// Decompiled by JEB v3.7.0.201909272058

function potSwap() public payable {
    var1 = storage[0x5];
    ++var1;
    *0x0 = var1;
    *0x20 = 0xb;
    var2 = keccak256(0x0, 0x40);
    var2 = storage[var2 + 0x7];
    var2 = __impl_potSwap($msg.value, var2);
    *0x0 = var1;
    *0x20 = 0xb;
    var5 = keccak256(0x0, 0x40);
    storage[var5 + 0x7] = var2;
    uint256* var4 = *0x40;
    *var4 = var1;
    *(var4 + 1) = $msg.value;
    emit onPotSwapDeposit(*0x40, ((uint256)(((int256)var4) - *0x40)) + 0x40);
}
