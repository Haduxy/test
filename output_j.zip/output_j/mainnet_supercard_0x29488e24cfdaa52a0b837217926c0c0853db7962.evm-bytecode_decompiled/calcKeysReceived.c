// Decompiled by JEB v3.7.0.201909272058

function calcKeysReceived() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    var3 = storage[0x2];
    *0x0 = var1;
    *0x20 = 0xb;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5 + 0x4];
    var6 = timestamp();
    uint256 var4 = var6;
    var5 = (uint256)(var3 + var5 < var6);

    if(var5 != 0x0) {
        *0x0 = var1;
        *0x20 = 0xb;
        var5 = keccak256(0x0, 0x40);
        var5 = storage[var5 + 0x2];
        var5 = (uint256)(var4 <= var5);

        if(!var5) {
            *0x0 = var1;
            *0x20 = 0xb;
            var5 = keccak256(0x0, 0x40);
            var5 = storage[var5 + 0x2];
            var5 = (uint256)(var4 > var5);

            if(var5 != 0x0) {
                *0x0 = var1;
                *0x20 = 0xb;
                var5 = keccak256(0x0, 0x40);
                var5 = storage[var5];
                var5 = (uint256)(var5 == 0x0);
            }
        }
    }

    if(var5 != 0x0) {
        *0x0 = var1;
        *0x20 = 0xb;
        var5 = keccak256(0x0, 0x40);
        var5 = storage[var5 + 0x6];
        sub_4587(var2, var5);
    }
    else {
        sub_45A8(var2);
    }
}
