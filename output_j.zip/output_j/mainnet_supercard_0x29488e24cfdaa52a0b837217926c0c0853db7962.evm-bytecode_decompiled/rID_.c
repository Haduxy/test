// Decompiled by JEB v3.7.0.201909272058

function rID_() public view /*NON-PAYABLE*/ {
    var1 = storage[0x5];
    return;
}
