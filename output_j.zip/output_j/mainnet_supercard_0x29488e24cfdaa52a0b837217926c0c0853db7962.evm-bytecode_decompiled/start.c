// Decompiled by JEB v3.7.0.201909272058

function start() {
    int256 var6;
    uint256 var4, var5;
    int256 var2;
    uint256* var3;
    uint256 var0;
    *0x40 = 0x80;
    var1 = msg.data.length;

    if(var1 >= 0x4) {
        var0 = (uint256)$msg.sig;

        if(var0 == 0x18a25e8) {
            getBuyPrice();
        }

        if(var0 == 0x6fdde03) {
            symbol();
        }

        if(var0 == 0x79ce327) {
            reLoadXname();
        }

        if(var0 == 0xf15f4c0) {
            activate();
        }

        if(var0 == 0x10f01eba) {
            pIDxAddr_();
        }

        if(var0 == 0x11a09ae7) {
            airDropTracker_();
        }

        if(var0 == 0x24c33d33) {
            round_();
        }

        if(var0 == 0x2660316e) {
            plyrNames_();
        }

        if(var0 == 0x2ce21999) {
            fees_();
        }

        if(var0 == 0x2e19ebdc) {
            pIDxName_();
        }

        if(var0 == 0x349cdcac) {
            reLoadXid();
        }

        if(var0 == 0x3ccfd60b) {
            withdraw();
        }

        if(var0 == 0x3ddd4698) {
            registerNameXaddr();
        }

        if(var0 == 0x49cc635d) {
            receivePlayerInfo();
        }

        if(var0 == 0x5893d481) {
            rndTmEth_();
        }

        if(var0 == 0x624ae5c0) {
            rID_();
        }

        if(var0 == 0x63066434) {
            getPlayerVaults();
        }

        if(var0 == 0x685ffd83) {
            registerNameXname();
        }

        if(var0 == 0x747dff42) {
            getCurrentRoundInfo();
        }

        if(var0 == 0x82bfc739) {
            reLoadXaddr();
        }

        if(var0 == 0x8f38f309) {
            buyXid();
        }

        if(var0 == 0x8f7140ea) {
            receivePlayerNameList();
        }

        if(var0 == 0x921dec21) {
            registerNameXID();
        }

        if(var0 == 0x95d89b41) {
            symbol();
        }

        if(var0 == 0x98a0871d) {
            buyXaddr();
        }

        if(var0 == 0xa2bccae9) {
            plyrRnds_();
        }

        if(var0 == 0xa65b37a1) {
            buyXname();
        }

        if(var0 == 0xc519500e) {
            potSplit_();
        }

        if(var0 == 0xc7e284b8) {
            getTimeLeft();
        }

        if(var0 == 0xce89c80c) {
            calcKeysReceived();
        }

        if(var0 == 0xcf808000) {
            iWantXKeys();
        }

        if(var0 == 0xd53b2679) {
            activated_();
        }

        if(var0 == 0xd87574e0) {
            airDropPot_();
        }

        if(var0 == 0xde7874f3) {
            plyr_();
        }

        if(var0 == 0xed78cf4a) {
            potSwap();
        }

        if(var0 == 0xee0b5d8b) {
            getPlayerInfoByAddress();
        }
    }

    var0 = sub_51EE();
    var1 = storage[0xf];

    if((var1 & 0xff) != 0x0 != -1) {
        var3 = *0x40;
        *var3 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *((uint256*)(((char*)var3) + 0x4)) = 0x20;
        *((uint256*)(((char*)var3) + 0x24)) = 0x29;
        codecopy(0x0, 0x5288, 0x20);
        *((uint256*)(((char*)var3) + 0x44)) = *0x0;
        codecopy(0x0, 0x5248, 0x20);
        *((uint256*)(((char*)var3) + 0x64)) = *0x0;
        var2 = *0x40;
        revert(var2, ((uint256)(((int256)var3) - var2)) + 0x84);
    }

    var2 = msg.sender;
    var3 = extcodesize(msg.sender);

    if(!((unsigned char)(((int256)var3) == 0x0))) {
        var5 = *0x40;
        *var5 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *(var5 + 0x4) = 0x20;
        *(var5 + 0x24) = 0x11;
        codecopy(0x0, 0x52c8, 0x20);
        *(var5 + 0x44) = *0x0;
        var4 = *0x40;
        revert(var4, var5 - var4 + 0x64);
    }

    var4 = $msg.value;

    if($msg.value < 0x3b9aca00) {
        var6 = *0x40;
        *var6 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *(var6 + 0x4) = 0x20;
        *(var6 + 0x24) = 0x21;
        codecopy(0x0, 0x5268, 0x20);
        *(var6 + 0x44) = *0x0;
        *(var6 + 0x64) = 0x7900000000000000000000000000000000000000000000000000000000000000;
        var5 = *0x40;
        revert(var5, var6 - var5 + 0x84);
    }

    if(var4 > 0x152d02c7e14af6800000) {
        var6 = *0x40;
        *var6 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *(var6 + 0x4) = 0x20;
        *(var6 + 0x24) = 0xe;
        codecopy(0x0, 0x52a8, 0x20);
        *(var6 + 0x44) = *0x0;
        var5 = *0x40;
        revert(var5, var6 - var5 + 0x64);
    }

    var5 = sub_9B5(var0);
    var6 = msg.sender;
    *0x0 = msg.sender;
    *0x20 = 0x6;
    var10 = keccak256(0x0, 0x40);
    var10 = storage[var10];
    *0x0 = var10;
    *0x20 = 0x8;
    var8 = keccak256(0x0, 0x40);
    var7 = storage[var8 + 0x6];
    sub_C69(var5, 0x2, var7, var10);
    stop();
}
