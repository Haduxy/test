// Decompiled by JEB v3.7.0.201909272058

function receivePlayerNameList() public /*NON-PAYABLE*/ {
    uint256* var4;
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    var3 = msg.sender;

    if(msg.sender != 0xb838c100eb1a1d08b215fbbcc06698e9c181358c) {
        var4 = *0x40;
        *var4 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *((uint256*)(((char*)var4) + 0x4)) = 0x20;
        *((uint256*)(((char*)var4) + 0x24)) = 0x27;
        *((uint256*)(((char*)var4) + 0x44)) = 0x796f7572206e6f7420706c617965724e616d657320636f6e74726163742e2e2e;
        *((uint256*)(((char*)var4) + 0x64)) = 0x20686d6d6d2e2e00000000000000000000000000000000000000000000000000;
        var3 = *0x40;
        revert(var3, ((uint256)(((int256)var4) - var3)) + 0x84);
    }

    *0x0 = var1;
    *0x20 = 0xa;
    var6 = keccak256(0x0, 0x40);
    *0x0 = var2;
    *0x20 = var6;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3];

    if((var3 & 0xff) == 0x0) {
        *0x0 = var1;
        *0x20 = 0xa;
        var6 = keccak256(0x0, 0x40);
        *0x0 = var2;
        *0x20 = var6;
        var3 = keccak256(0x0, 0x40);
        var4 = storage[var3];
        storage[var3] = ((uint256)(((int256)var4) & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00)) | 0x1;
    }
}
