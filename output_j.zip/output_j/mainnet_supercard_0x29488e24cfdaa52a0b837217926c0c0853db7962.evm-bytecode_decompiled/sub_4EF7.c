// Decompiled by JEB v3.7.0.201909272058

function sub_4EF7(uint256 par1) private pure returns (uint256) {
    sub_4385(par1, par1);
}
