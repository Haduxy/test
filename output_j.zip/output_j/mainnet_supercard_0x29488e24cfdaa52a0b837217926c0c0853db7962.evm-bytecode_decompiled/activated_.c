// Decompiled by JEB v3.7.0.201909272058

function activated_() public view /*NON-PAYABLE*/ {
    var1 = storage[0xf];
    return;
}
