// Decompiled by JEB v3.7.0.201909272058

function buyXaddr() public payable {
    uint256 var5, var10, var8, var9;
    int256 var6;
    uint256* var7;
    var2 = calldataload(0x4);
    uint256 var1 = address(var2);
    var2 = calldataload(0x24);
    uint256 var3 = sub_51EE();
    var4 = storage[0xf];

    if((var4 & 0xff) != 0x0 != -1) {
        var7 = *0x40;
        *var7 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *((uint256*)(((char*)var7) + 0x4)) = 0x20;
        *((uint256*)(((char*)var7) + 0x24)) = 0x29;
        codecopy(0x0, 0x5288, 0x20);
        *((uint256*)(((char*)var7) + 0x44)) = *0x0;
        codecopy(0x0, 0x5248, 0x20);
        *((uint256*)(((char*)var7) + 0x64)) = *0x0;
        var6 = *0x40;
        revert(var6, ((uint256)(((int256)var7) - var6)) + 0x84);
    }

    var6 = msg.sender;
    var7 = extcodesize(msg.sender);

    if(!((unsigned char)(((int256)var7) == 0x0))) {
        var9 = *0x40;
        *var9 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *(var9 + 0x4) = 0x20;
        *(var9 + 0x24) = 0x11;
        codecopy(0x0, 0x52c8, 0x20);
        *(var9 + 0x44) = *0x0;
        var8 = *0x40;
        revert(var8, var9 - var8 + 0x64);
    }

    var8 = $msg.value;

    if($msg.value < 0x3b9aca00) {
        var10 = *0x40;
        *var10 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *(var10 + 0x4) = 0x20;
        *(var10 + 0x24) = 0x21;
        codecopy(0x0, 0x5268, 0x20);
        *(var10 + 0x44) = *0x0;
        *(var10 + 0x64) = 0x7900000000000000000000000000000000000000000000000000000000000000;
        var9 = *0x40;
        revert(var9, var10 - var9 + 0x84);
    }

    if(var8 > 0x152d02c7e14af6800000) {
        var10 = *0x40;
        *var10 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
        *(var10 + 0x4) = 0x20;
        *(var10 + 0x24) = 0xe;
        codecopy(0x0, 0x52a8, 0x20);
        *(var10 + 0x44) = *0x0;
        var9 = *0x40;
        revert(var9, var10 - var9 + 0x64);
    }

    var9 = sub_9B5(var3);
    var10 = msg.sender;
    *0x0 = msg.sender;
    *0x20 = 0x6;
    var10 = keccak256(0x0, 0x40);
    var10 = storage[var10];
    var3 = var9;
    var4 = var10;
    var9 = (uint256)((address(var1)) == 0x0);

    if(!var9) {
        var10 = msg.sender;
        var9 = (uint256)((address(var1)) == msg.sender);
    }

    if(var9 != 0x0) {
        *0x0 = var4;
        *0x20 = 0x8;
        var9 = keccak256(0x0, 0x40);
        var9 = storage[var9 + 0x6];
        var5 = var9;
    }
    else {
        *0x0 = address(var1);
        *0x20 = 0x6;
        var13 = keccak256(0x0, 0x40);
        var13 = storage[var13];
        *0x0 = var4;
        *0x20 = 0x8;
        var11 = keccak256(0x0, 0x40);
        var10 = storage[var11 + 0x6];
        var5 = var13;

        if(var13 != var10) {
            *0x0 = var4;
            *0x20 = 0x8;
            var9 = keccak256(0x0, 0x40);
            storage[var9 + 0x6] = var5;
        }
    }

    var9 = sub_38AA(var2);
    sub_C69(var3, var9, var5, var4);
}
