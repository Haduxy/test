// Decompiled by JEB v3.7.0.201909272058

function getPlayerVaults() public /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    (uint256 var0, var1, uint256 var2) = __impl_getPlayerVaults(var1);
    uint256 var4 = var0;
    var0 = *0x40;
    *var0 = var4;
    *(var0 + 0x20) = var1;
    *(var0 + 0x40) = var2;
    var1 = var0;
    var0 = *0x40;
    return(var0, var1 - var0 + 0x60);
}
