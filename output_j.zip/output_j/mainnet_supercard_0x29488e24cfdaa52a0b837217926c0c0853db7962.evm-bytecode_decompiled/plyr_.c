// Decompiled by JEB v3.7.0.201909272058

function plyr_() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    (uint256 var0, var1, uint256 var2, uint256 var3, uint256 var4, uint256 var5, uint256 var6, uint256 var7) = __impl_plyr_(var1);
    uint256 var10 = var1;
    var1 = *0x40;
    *var1 = address(var10);
    *(var1 + 0x20) = var2;
    *(var1 + 0x40) = var3;
    *(var1 + 0x60) = var4;
    *(var1 + 0x80) = var5;
    *(var1 + 0xa0) = var6;
    *(var1 + 0xc0) = var7;
    var2 = var1;
    var1 = *0x40;
    return(var1, var2 - var1 + 0xe0);
}
