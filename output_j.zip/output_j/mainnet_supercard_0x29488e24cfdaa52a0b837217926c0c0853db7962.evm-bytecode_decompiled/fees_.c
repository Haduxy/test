// Decompiled by JEB v3.7.0.201909272058

function fees_() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    (uint256 var0, var1, uint256 var2) = __impl_fees_(var1);
    uint256 var4 = var1;
    var1 = *0x40;
    *var1 = var4;
    *(var1 + 0x20) = var2;
    uint256 var3 = var1;
    var1 = *0x40;
    return(var1, var3 - var1 + 0x40);
}
