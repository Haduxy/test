// Decompiled by JEB v3.7.0.201909272058

function sub_4EA4(uint256 par1, uint256 par2, uint256 par3) private pure returns (uint256) {
    uint256 var3 = __impl_potSwap(0x1, par3);
    uint256 var1 = var3 / 0x2;
    uint256 var0 = par3;

    while(var0 > var1) {
        var0 = var1;
        uint256 var4 = var1, var5 = par3;

        if(var1 == 0x0) {
            invalid();
        }

        var3 = __impl_potSwap(var1, var5 / var4);
        var1 = var3 / 0x2;
    }

    return var0;
}
