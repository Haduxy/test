// Decompiled by JEB v3.7.0.201909272058

function __impl_getPlayerInfoByAddress(uint256 par1) private view returns (uint256) {
    var9 = storage[0x5];
    uint256 var7 = var9;
    *0x0 = address(par1);
    *0x20 = 0x6;
    var11 = keccak256(0x0, 0x40);
    var11 = storage[var11];
    *0x0 = var11;
    *0x20 = 0x8;
    var13 = keccak256(0x0, 0x40);
    var15 = storage[var13 + 0x1];
    *0x20 = 0x9;
    var16 = keccak256(0x0, 0x40);
    *0x0 = var7;
    *0x20 = var16;
    var15 = keccak256(0x0, 0x40);
    var14 = storage[var15 + 0x1];
    *0x0 = var11;
    *0x20 = 0x8;
    var12 = storage[var13 + 0x2];
    var12 = storage[var13 + 0x5];
    uint256 var8 = var11;
    var14 = sub_452A(var12, var11);
    *0x0 = var11;
    *0x20 = 0x8;
    var15 = keccak256(0x0, 0x40);
    var15 = storage[var15 + 0x3];
    __impl_potSwap(var14, var15);
    *0x0 = var8;
    *0x20 = 0x8;
    var16 = keccak256(0x0, 0x40);
    var16 = storage[var16 + 0x4];
    *0x20 = 0x9;
    var17 = keccak256(0x0, 0x40);
    *0x0 = var7;
    *0x20 = var17;
    var13 = keccak256(0x0, 0x40);
    var13 = storage[var13];
    return var13;
}
