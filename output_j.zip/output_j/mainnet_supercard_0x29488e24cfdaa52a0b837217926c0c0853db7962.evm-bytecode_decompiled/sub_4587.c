// Decompiled by JEB v3.7.0.201909272058

function sub_4587(uint256 par1, uint256 par2) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    sub_45A8(par1);
    __impl_potSwap(par2, par1);
}
