// Decompiled by JEB v3.7.0.201909272058

function sub_4385(int256 par1, int256 par2) private pure returns (uint256) {
    uint256 var0;

    if(par1 == 0x0) {
        var0 = 0x0;
    }
    else {
        var0 = par1 * par2;
        int256 var1 = par2, var2 = par1;
        uint256 var3 = var0;

        if(par1 == 0x0) {
            invalid();
        }

        if(var3 / ((uint256)var2) != var1) {
            var2 = *0x40;
            *var2 = 0x8c379a000000000000000000000000000000000000000000000000000000000;
            *(var2 + 0x4) = 0x20;
            *(var2 + 0x24) = 0x13;
            *(var2 + 0x44) = 0x536166654d617468206d756c206661696c656400000000000000000000000000;
            var1 = *0x40;
            revert(var1, var2 - var1 + 0x64);
        }
    }

    return var0;
}
