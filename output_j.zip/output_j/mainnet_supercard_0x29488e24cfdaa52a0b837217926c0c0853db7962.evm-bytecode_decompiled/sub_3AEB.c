// Decompiled by JEB v3.7.0.201909272058

function sub_3AEB(uint256 par1) private /*! STACK DISCREPANCY !*/ returns (uint256) {
    *0x0 = par1;
    *0x20 = 0x8;
    var1 = keccak256(0x0, 0x40);
    var1 = storage[var1 + 0x5];
    sub_4E0D(var1, par1);
    *0x0 = par1;
    *0x20 = 0x8;
    var2 = keccak256(0x0, 0x40);
    var3 = storage[var2 + 0x4];
    var4 = storage[var2 + 0x3];
    uint256 var5 = var2;
    var2 = var4;
    var4 = storage[var5 + 0x2];
    __impl_potSwap(var2, var4);
    *0x0 = par1;
    *0x20 = 0x8;
    var3 = keccak256(0x0, 0x40);
    storage[var3 + 0x2] = 0x0;
    storage[var3 + 0x3] = 0x0;
    storage[var3 + 0x4] = 0x0;
    return 0x3b3c;
}
