// Decompiled by JEB v3.7.0.201909272058

function sub_4E0D(uint256 par1, uint256 par2) private {
    uint256 var1 = sub_452A(par2, par1);
    uint256 var0 = var1;

    if(var1 > 0x0) {
        *0x0 = par1;
        *0x20 = 0x8;
        var1 = keccak256(0x0, 0x40);
        var1 = storage[var1 + 0x3];
        var1 = __impl_potSwap(var1, var0);
        *0x0 = par1;
        *0x20 = 0x8;
        var5 = keccak256(0x0, 0x40);
        storage[var5 + 0x3] = var1;
        *0x20 = 0x9;
        var4 = keccak256(0x0, 0x40);
        *0x0 = par2;
        *0x20 = var4;
        var1 = keccak256(0x0, 0x40);
        var1 = storage[var1 + 0x2];
        var1 = __impl_potSwap(var1, var0);
        *0x0 = par1;
        *0x20 = 0x9;
        var5 = keccak256(0x0, 0x40);
        *0x0 = par2;
        *0x20 = var5;
        var2 = keccak256(0x0, 0x40);
        storage[var2 + 0x2] = var1;
    }
}
