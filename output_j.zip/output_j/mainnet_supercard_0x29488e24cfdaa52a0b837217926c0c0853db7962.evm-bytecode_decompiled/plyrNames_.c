// Decompiled by JEB v3.7.0.201909272058

function plyrNames_() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    (uint256 var0, var1) = __impl_plyrNames_(var2, var1);
    uint256 var3 = var1;
    var1 = *0x40;
    *var1 = (uint256)(var3 != 0x0);
    return(var1, 0x20);
}
