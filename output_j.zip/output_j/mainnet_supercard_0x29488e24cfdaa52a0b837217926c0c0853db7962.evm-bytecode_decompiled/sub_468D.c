// Decompiled by JEB v3.7.0.201909272058

function sub_468D(uint256 par1, uint256* par2) private returns (uint256) {
    sub_51EE();
    *0x0 = par1;
    *0x20 = 0x8;
    var1 = keccak256(0x0, 0x40);
    var1 = storage[var1 + 0x5];

    if(var1 != 0x0) {
        *0x0 = par1;
        *0x20 = 0x8;
        var1 = keccak256(0x0, 0x40);
        var1 = storage[var1 + 0x5];
        sub_4E0D(var1, par1);
    }

    var1 = storage[0x5];
    *0x0 = par1;
    *0x20 = 0x8;
    par1 = var1;
    var1 = keccak256(0x0, 0x40);
    storage[var1 + 0x5] = par1;
    *par2 = *par2 + 0xa;
    return par2;
}
