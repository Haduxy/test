// Decompiled by JEB v3.7.0.201909272058

function rndTmEth_() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    *0x20 = 0xc;
    *0x0 = var1;
    var5 = keccak256(0x0, 0x40);
    *0x20 = var5;
    *0x0 = var2;
    var1 = keccak256(0x0, 0x40);
    var1 = storage[var1];
    return;
}
