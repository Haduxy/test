// Decompiled by JEB v3.7.0.201909272058

function batchTransfer() public /*NON-PAYABLE*/ {
    var3 = calldataload(0x4);
    var3 = var3 + 0x4;
    var4 = calldataload(var3);
    uint256 var6 = *0x40;
    *0x40 = var4 * 0x20 + var6 + 0x20;
    *var6 = var4;
    calldatacopy(var6 + 0x20, var3 + 0x20, var4 * 0x20);
    var4 = calldataload(0x24);
    uint256 var0 = __impl_batchTransfer(var4, var6);
    uint256* var2 = *0x40;
    *var2 = (uint256)(var0 != 0x0);
    return(*0x40, var2 + 1 - *0x40);
}
