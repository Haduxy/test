// Decompiled by JEB v3.7.0.201909272058

function start() {
    *0x40 = 0x60;
    var1 = msg.data.length;

    if(var1 >= 0x4) {
        uint256 var0 = (uint256)$msg.sig;

        if(var0 == 0x6fdde03) {
            name();
        }

        if(var0 == 0x95ea7b3) {
            approve();
        }

        if(var0 == 0x18160ddd) {
            totalSupply();
        }

        if(var0 == 0x23b872dd) {
            transferFrom();
        }

        if(var0 == 0x313ce567) {
            decimals();
        }

        if(var0 == 0x3f4ba83a) {
            unpause();
        }

        if(var0 == 0x54fd4d50) {
            version();
        }

        if(var0 == 0x5c975abb) {
            paused();
        }

        if(var0 == 0x70a08231) {
            balanceOf();
        }

        if(var0 == 0x83f12fec) {
            batchTransfer();
        }

        if(var0 == 0x8456cb59) {
            pause();
        }

        if(var0 == 0x8da5cb5b) {
            owner();
        }

        if(var0 == 0x95d89b41) {
            symbol();
        }

        if(var0 == 0xa9059cbb) {
            transfer();
        }

        if(var0 == 0xdd62ed3e) {
            allowance();
        }

        if(var0 == 0xf2fde38b) {
            transferOwnership();
        }
    }

    if($msg.value != 0x0) {
        revert(0x0, 0x0);
    }

    revert(0x0, 0x0);
}
