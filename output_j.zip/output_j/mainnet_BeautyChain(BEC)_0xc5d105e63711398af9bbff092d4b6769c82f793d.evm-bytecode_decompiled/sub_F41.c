// Decompiled by JEB v3.7.0.201909272058

function sub_F41(uint256 par1, uint256 par2) private returns (uint256) {
    var4 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = 0x2;
    var2 = keccak256(0x0, 0x40);
    *0x0 = address(par1);
    *0x20 = var2;
    var2 = keccak256(0x0, 0x40);
    storage[var2] = par2;
    var2 = msg.sender;
    uint256* var6 = *0x40;
    *var6 = par2;
    emit Approval(*0x40, var6 + 1 - *0x40);
    return 0x1;
}
