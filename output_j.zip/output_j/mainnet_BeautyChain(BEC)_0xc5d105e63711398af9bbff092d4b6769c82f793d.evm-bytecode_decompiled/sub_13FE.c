// Decompiled by JEB v3.7.0.201909272058

function sub_13FE(uint256 par1, uint256 par2) private pure returns (uint256) {

    if(par1 < par2) {
        invalid();
    }

    return par1 - par2;
}
