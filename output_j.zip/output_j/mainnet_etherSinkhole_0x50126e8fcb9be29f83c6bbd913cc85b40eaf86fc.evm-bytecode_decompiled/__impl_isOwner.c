// Decompiled by JEB v3.7.0.201909272058

function __impl_isOwner(uint256 par1) private returns (uint256) {
    var3 = msg.data.length;
    *(*0x40 + 0x20) = 0x0;
    uint256 var5 = *0x40;
    calldatacopy(var5, 0x0, var3);
    uint256 var4 = *0x40;
    var9 = gasleft();
    var3 = delegatecall(var9 - 0x32, 0xa657491c1e7f16adb39b9b60e87bbb8d93988bc3, var4, var3 + var5 - var4, var4, 0x20);

    if(var3 == 0x0) {
        invalid();
    }

    return **0x40;
}
