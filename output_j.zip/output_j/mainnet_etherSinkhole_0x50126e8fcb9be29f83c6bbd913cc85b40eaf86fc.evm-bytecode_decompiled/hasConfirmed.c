// Decompiled by JEB v3.7.0.201909272058

function hasConfirmed() public /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var3 = calldataload(0x24);
    var6 = msg.data.length;
    *(*0x40 + 0x20) = 0x0;
    uint256 var8 = *0x40;
    calldatacopy(var8, 0x0, var6);
    uint256 var7 = *0x40;
    var12 = gasleft();
    var6 = delegatecall(var12 - 0x32, 0xa657491c1e7f16adb39b9b60e87bbb8d93988bc3, var7, var6 + var8 - var7, var7, 0x20);

    if(var6 == 0x0) {
        invalid();
    }
}
