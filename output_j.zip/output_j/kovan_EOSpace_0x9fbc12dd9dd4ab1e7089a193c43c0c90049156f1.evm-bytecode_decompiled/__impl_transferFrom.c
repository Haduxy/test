// Decompiled by JEB v3.7.0.201909272058

function __impl_transferFrom(uint256 par1, uint256 par2, uint256 par3) private returns (uint256) {
    var4 = msg.data.length;

    if(var4 < 0x64) {
        invalid();
    }

    if((address(par2)) == 0x0) {
        revert(0x0, 0x0);
    }

    *0x0 = address(par1);
    *0x20 = 0x3;
    var2 = keccak256(0x0, 0x40);
    var2 = storage[var2];

    if(par3 > var2) {
        revert(0x0, 0x0);
    }

    *0x0 = address(par1);
    *0x20 = 0x4;
    var2 = keccak256(0x0, 0x40);
    var4 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = var2;
    var2 = keccak256(0x0, 0x40);
    var2 = storage[var2];

    if(par3 > var2) {
        revert(0x0, 0x0);
    }

    *0x0 = address(par1);
    *0x20 = 0x3;
    var4 = keccak256(0x0, 0x40);
    var4 = storage[var4];
    var2 = sub_2464(par3, var4);
    *0x0 = address(par1);
    *0x20 = 0x3;
    var3 = keccak256(0x0, 0x40);
    storage[var3] = var2;
    *0x0 = address(par1);
    *0x20 = 0x4;
    var4 = keccak256(0x0, 0x40);
    var6 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = var4;
    var4 = keccak256(0x0, 0x40);
    var4 = storage[var4];
    var2 = sub_2464(par3, var4);
    *0x0 = address(par1);
    *0x20 = 0x4;
    var3 = keccak256(0x0, 0x40);
    var5 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = var3;
    var3 = keccak256(0x0, 0x40);
    storage[var3] = var2;
    *0x0 = address(par2);
    *0x20 = 0x3;
    var4 = keccak256(0x0, 0x40);
    var4 = storage[var4];
    var2 = sub_247D(par3, var4);
    *0x0 = address(par2);
    *0x20 = 0x3;
    var3 = keccak256(0x0, 0x40);
    storage[var3] = var2;
    uint256* var7 = *0x40;
    *var7 = par3;
    emit Transfer(*0x40, var7 + 1 - *0x40);
    return 0x1;
}
