// Decompiled by JEB v3.7.0.201909272058

function burn() public /*NON-PAYABLE*/ {
    var3 = msg.data.length;
    var4 = calldataload(0x4);
    __impl_burn(var4);
    stop();
}
