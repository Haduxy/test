// Decompiled by JEB v3.7.0.201909272058

function __impl_approve(uint256 par1, uint256 par2) private returns (uint256) {
    uint256 var0;
    uint256 var1 = (uint256)(par2 != 0x0);

    if(var1 != 0x0) {
        var4 = msg.sender;
        *0x0 = address(msg.sender);
        *0x20 = 0x4;
        var2 = keccak256(0x0, 0x40);
        *0x0 = address(par1);
        *0x20 = var2;
        var2 = keccak256(0x0, 0x40);
        var2 = storage[var2];
        var1 = (uint256)(var2 != 0x0);
    }

    if(var1 != 0x0) {
        var0 = 0x0;
    }
    else {
        var4 = msg.sender;
        *0x0 = address(msg.sender);
        *0x20 = 0x4;
        var2 = keccak256(0x0, 0x40);
        *0x0 = address(par1);
        *0x20 = var2;
        var2 = keccak256(0x0, 0x40);
        storage[var2] = par2;
        var2 = msg.sender;
        uint256* var6 = *0x40;
        *var6 = par2;
        emit Approval(*0x40, var6 + 1 - *0x40);
        var0 = 0x1;
    }

    return var0;
}
