// Decompiled by JEB v3.7.0.201909272058

function withdraw() public /*NON-PAYABLE*/ {
    __impl_withdraw();
    stop();
}
