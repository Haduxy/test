// Decompiled by JEB v3.7.0.201909272058

function __impl_withdraw() private {
    var2 = storage[0x1];
    int256 var1 = var2;
    var2 = msg.sender;

    if((address(var1)) != (address(msg.sender))) {
        revert(0x0, 0x0);
    }

    var1 = address(this);
    var1 = balance(address(var1));
    var2 = storage[0x1];
    transfer(address(var2), var1);
}
