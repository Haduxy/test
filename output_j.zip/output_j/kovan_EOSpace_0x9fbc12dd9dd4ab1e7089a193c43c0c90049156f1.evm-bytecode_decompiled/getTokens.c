// Decompiled by JEB v3.7.0.201909272058

function getTokens() public payable {
    __impl_getTokens();
    stop();
}
