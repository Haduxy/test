// Decompiled by JEB v3.7.0.201909272058

function distributionFinished() public view /*NON-PAYABLE*/ {
    (uint256 var0, uint256 var1) = __impl_distributionFinished();
    uint256* var3 = *0x40;
    *var3 = (uint256)(var1 != 0x0);
    return(*0x40, var3 + 1 - *0x40);
}
