// Decompiled by JEB v3.7.0.201909272058

function blacklist() public view /*NON-PAYABLE*/ {
    var3 = msg.data.length;
    var4 = calldataload(0x4);
    (uint256 var0, uint256 var1) = __impl_blacklist(address(var4));
    var3 = *0x40;
    *var3 = (uint256)(var1 != 0x0);
    return(*0x40, var3 + 1 - *0x40);
}
