// Decompiled by JEB v3.7.0.201909272058

function __impl_airdrop(uint256 par1) private {
    var2 = storage[0x1];
    uint256 var1 = var2;
    var2 = msg.sender;

    if((address(var1)) != (address(msg.sender))) {
        revert(0x0, 0x0);
    }

    var2 = storage[0xa];

    if((var2 & 0xff) != 0x0) {
        revert(0x0, 0x0);
    }

    if(*par1 > 0xff) {
        revert(0x0, 0x0);
    }

    var1 = storage[0x8];
    var2 = storage[0x9];

    if(var1 < var2) {
        revert(0x0, 0x0);
    }

    for(uint256 var0 = 0x0; var0 < *par1; ++var0) {
        var1 = storage[0x8];
        var2 = storage[0x9];

        if(var1 < var2) {
            revert(0x0, 0x0);
        }

        var2 = par1;
        uint256 var3 = var0;

        if(*par1 <= var0) {
            invalid();
        }

        uint256 $tmp = var3;
        var3 = var2;
        var2 = $tmp;
        $tmp = var3 + 0x20;
        var3 = storage[0x9];
        sub_226F(var3, *(var2 * 0x20 + $tmp));
    }

    var1 = storage[0x6];
    var2 = storage[0x7];

    if(var1 <= var2) {
        var4 = storage[0xa];
        storage[0xa] = (var4 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00) | 0xffffffffffffffff;
    }
}
