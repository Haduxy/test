// Decompiled by JEB v3.7.0.201909272058

function start() {
    *0x40 = 0x80;
    var1 = msg.data.length;

    if(var1 >= 0x4) {
        uint256 var0 = (uint256)$msg.sig;

        if(var0 == 0x6fdde03) {
            name();
        }

        if(var0 == 0x95ea7b3) {
            approve();
        }

        if(var0 == 0x18160ddd) {
            totalSupply();
        }

        if(var0 == 0x23b872dd) {
            transferFrom();
        }

        if(var0 == 0x313ce567) {
            decimals();
        }

        if(var0 == 0x3ccfd60b) {
            withdraw();
        }

        if(var0 == 0x3fa4f245) {
            value();
        }

        if(var0 == 0x42966c68) {
            burn();
        }

        if(var0 == 0x502dadb0) {
            disableWhitelist();
        }

        if(var0 == 0x70a08231) {
            balanceOf();
        }

        if(var0 == 0x729ad39e) {
            airdrop();
        }

        if(var0 == 0x95d89b41) {
            symbol();
        }

        if(var0 == 0x9b1cbccc) {
            finishDistribution();
        }

        if(var0 == 0x9c09c835) {
            enableWhitelist();
        }

        if(var0 == 0xa8c310d5) {
            distributeAmounts();
        }

        if(var0 == 0xa9059cbb) {
            transfer();
        }

        if(var0 == 0xaa6ca808) {
            getTokens();
        }

        if(var0 == 0xc108d542) {
            distributionFinished();
        }

        if(var0 == 0xc489744b) {
            getTokenBalance();
        }

        if(var0 == 0xd8a54360) {
            totalRemaining();
        }

        if(var0 == 0xdd62ed3e) {
            allowance();
        }

        if(var0 == 0xe58fc54c) {
            withdrawForeignTokens();
        }

        if(var0 == 0xefca2eed) {
            totalDistributed();
        }

        if(var0 == 0xf2fde38b) {
            transferOwnership();
        }

        if(var0 == 0xf3e4877c) {
            distribution();
        }

        if(var0 == 0xf9f92be4) {
            blacklist();
        }
    }

    __impl_getTokens();
    stop();
}
