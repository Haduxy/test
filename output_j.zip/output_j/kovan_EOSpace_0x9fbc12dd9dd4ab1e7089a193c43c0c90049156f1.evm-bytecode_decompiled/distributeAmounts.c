// Decompiled by JEB v3.7.0.201909272058

function distributeAmounts() public /*NON-PAYABLE*/ {
    var3 = msg.data.length;
    var4 = calldataload(0x4);
    var4 = var4 + 0x4;
    var5 = calldataload(var4);
    uint256 var7 = *0x40;
    *0x40 = var5 * 0x20 + var7 + 0x20;
    *var7 = var5;
    calldatacopy(var7 + 0x20, var4 + 0x20, var5 * 0x20);
    var5 = calldataload(0x24);
    var5 = var5 + 0x4;
    var6 = calldataload(var5);
    uint256 var8 = *0x40;
    *0x40 = var6 * 0x20 + var8 + 0x20;
    *var8 = var6;
    calldatacopy(var8 + 0x20, var5 + 0x20, var6 * 0x20);
    __impl_distributeAmounts(var8, var7);
    stop();
}
