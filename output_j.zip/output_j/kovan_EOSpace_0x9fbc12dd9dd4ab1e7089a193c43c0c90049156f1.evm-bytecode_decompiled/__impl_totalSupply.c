// Decompiled by JEB v3.7.0.201909272058

function __impl_totalSupply() private view returns (uint256) {
    var0 = storage[0x6];
    return var0;
}
