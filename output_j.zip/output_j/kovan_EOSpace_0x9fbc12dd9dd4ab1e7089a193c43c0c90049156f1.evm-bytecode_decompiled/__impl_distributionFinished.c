// Decompiled by JEB v3.7.0.201909272058

function __impl_distributionFinished() private view returns (uint256) {
    var1 = storage[0xa];
    return var1 & 0xff;
}
