// Decompiled by JEB v3.7.0.201909272058

function __impl_transferOwnership(uint256 par1) private {
    var1 = storage[0x1];
    int256 var0 = var1;
    var1 = msg.sender;

    if((address(var0)) != (address(msg.sender))) {
        revert(0x0, 0x0);
    }

    if((address(par1)) != 0x0) {
        var3 = storage[0x1];
        g0_0 = par1 & -1;
    }
}
