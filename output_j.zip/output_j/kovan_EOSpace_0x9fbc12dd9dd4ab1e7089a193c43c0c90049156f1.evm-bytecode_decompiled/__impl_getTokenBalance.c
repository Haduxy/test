// Decompiled by JEB v3.7.0.201909272058

function __impl_getTokenBalance(uint256 par1, uint256 par2) private returns (uint256) {
    uint256* var6 = *0x40;
    *var6 = 0x70a0823100000000000000000000000000000000000000000000000000000000;
    uint256* var7 = (uint256*)(((char*)var6) + 0x4);
    *var7 = address(par2);
    uint256 var5 = var7 + 1;
    var7 = *0x40;
    uint256 var8 = (uint256)(var5 - ((int256)var7));
    uint256* var9 = var7;
    int256 var11 = address(par1);
    var12 = extcodesize(var11);

    if(var12 == 0x0) {
        revert(0x0, 0x0);
    }

    var12 = gasleft();
    var6 = call(var12, var11, 0x0, var9, var8, var7, 0x20);

    if(!((unsigned char)(((int256)var6) != 0x0))) {
        var7 = returndatasize();
        returndatacopy(0x0, 0x0, var7);
        var7 = returndatasize();
        revert(0x0, var7);
    }

    uint256* var3 = *0x40;
    var4 = returndatasize();

    if(var4 < 0x20) {
        revert(0x0, 0x0);
    }

    return *var3;
}
