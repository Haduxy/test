// Decompiled by JEB v3.7.0.201909272058

function __impl_withdrawForeignTokens(uint256 par1) private returns (uint256) {
    var4 = storage[0x1];
    int256 var3 = var4;
    var4 = msg.sender;

    if((address(var3)) != (address(msg.sender))) {
        revert(0x0, 0x0);
    }

    uint256 var1 = par1;
    uint256* var6 = *0x40;
    *var6 = 0x70a0823100000000000000000000000000000000000000000000000000000000;
    uint256* var7 = (uint256*)(((char*)var6) + 0x4);
    *var7 = address(address(this));
    var5 = var7 + 1;
    var7 = *0x40;
    uint256* var8 = (uint256*)(var5 - ((int256)var7));
    uint256* var9 = var7;
    int256 var11 = address(par1);
    var12 = extcodesize(var11);

    if(var12 == 0x0) {
        revert(0x0, 0x0);
    }

    var12 = gasleft();
    var6 = call(var12, var11, 0x0, var9, var8, var7, 0x20);

    if(!((unsigned char)(((int256)var6) != 0x0))) {
        var7 = returndatasize();
        returndatacopy(0x0, 0x0, var7);
        var7 = returndatasize();
        revert(0x0, var7);
    }

    var3 = *0x40;
    var4 = returndatasize();

    if(((uint256)var4) < 0x20) {
        revert(0x0, 0x0);
    }

    uint256 var2 = *var3;
    var6 = storage[0x1];
    var7 = *0x40;
    *var7 = 0xa9059cbb00000000000000000000000000000000000000000000000000000000;
    var8 = (uint256*)(((char*)var7) + 0x4);
    *var8 = (uint256)(address(((int256)var6)));
    ++var8;
    *var8 = var2;
    var7 = *0x40;
    var8 = (uint256*)(var8 + 1 - ((int256)var7));
    var9 = var7;
    var11 = address(var1);
    var12 = extcodesize(var11);

    if(var12 == 0x0) {
        revert(0x0, 0x0);
    }

    var12 = gasleft();
    var6 = call(var12, var11, 0x0, var9, var8, var7, 0x20);

    if(!((unsigned char)(((int256)var6) != 0x0))) {
        var7 = returndatasize();
        returndatacopy(0x0, 0x0, var7);
        var7 = returndatasize();
        revert(0x0, var7);
    }

    var3 = *0x40;
    var4 = returndatasize();

    if(((uint256)var4) < 0x20) {
        revert(0x0, 0x0);
    }

    return *var3;
}
