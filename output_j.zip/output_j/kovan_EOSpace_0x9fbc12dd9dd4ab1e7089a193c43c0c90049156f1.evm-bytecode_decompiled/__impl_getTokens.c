// Decompiled by JEB v3.7.0.201909272058

function __impl_getTokens() private {
    var4 = storage[0xa];

    if((var4 & 0xff) != 0x0) {
        revert(0x0, 0x0);
    }

    var6 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = 0x5;
    var4 = keccak256(0x0, 0x40);
    var5 = storage[var4];

    if((var5 & 0xff) != 0x0) {
        revert(0x0, 0x0);
    }

    var3 = storage[0x8];
    var4 = storage[0x9];

    if(var3 < var4) {
        var3 = storage[0x8];
        g4_0 = var3;
    }

    var3 = storage[0x8];
    var4 = storage[0x9];

    if(var3 < var4) {
        revert(0x0, 0x0);
    }

    var3 = msg.sender;
    uint256 var0 = msg.sender;
    var4 = storage[0x2];
    var6 = *0x40;
    *var6 = 0x70a0823100000000000000000000000000000000000000000000000000000000;
    uint256 var7 = var6 + 0x4;
    *var7 = address(var0);
    var5 = var7 + 0x20;
    var7 = *0x40;
    uint256 var8 = var5 - var7;
    uint256 var9 = var7;
    int256 var11 = address(var4);
    var12 = extcodesize(var11);

    if(var12 == 0x0) {
        revert(0x0, 0x0);
    }

    var12 = gasleft();
    var6 = call(var12, var11, 0x0, var9, var8, var7, 0x20);

    if(var6 == 0x0) {
        var7 = returndatasize();
        returndatacopy(0x0, 0x0, var7);
        var7 = returndatasize();
        revert(0x0, var7);
    }

    var3 = *0x40;
    var4 = returndatasize();

    if(var4 < 0x20) {
        revert(0x0, 0x0);
    }

    uint256 var2 = *var3;
    var3 = storage[0x8];

    if(var2 > var3) {
        revert(0x0, 0x0);
    }

    sub_226F(var2, var0);

    if(var2 > 0x0) {
        *0x0 = address(var0);
        *0x20 = 0x5;
        var4 = keccak256(0x0, 0x40);
        var6 = storage[var4];
        storage[var4] = (var6 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00) | 0xffffffffffffffff;
    }

    var3 = storage[0x6];
    var4 = storage[0x7];

    if(var3 <= var4) {
        var6 = storage[0xa];
        storage[0xa] = (var6 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00) | 0xffffffffffffffff;
    }

    var7 = storage[0x9];
    var5 = sub_2416(0x186a0, var7);
    var3 = sub_2431(0x1869f, var5);
    g4_0 = var3;
}
