// Decompiled by JEB v3.7.0.201909272058

function __impl_symbol() private pure returns (uint256) {
    uint256* var0 = *0x40;
    *0x40 = var0 + &loc_2;
    *var0 = 0x3;
    *(var0 + 1) = 0x454f500000000000000000000000000000000000000000000000000000000000;
    return var0;
}
