// Decompiled by JEB v3.7.0.201909272058

function sub_226F(uint256 par1, uint256 par2) private returns (uint256) {
    var2 = storage[0xa];

    if((var2 & 0xff) != 0x0) {
        revert(0x0, 0x0);
    }

    var3 = storage[0x7];
    uint256 var1 = sub_247D(par2, var3);
    g2_0 = var1;
    var3 = storage[0x8];
    var1 = sub_2464(par2, var3);
    g3_0 = var1;
    *0x0 = address(par1);
    *0x20 = 0x3;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3];
    var1 = sub_247D(par2, var3);
    *0x0 = address(par1);
    *0x20 = 0x3;
    var2 = keccak256(0x0, 0x40);
    storage[var2] = var1;
    uint256* var5 = *0x40;
    *var5 = par2;
    emit Distr(*0x40, var5 + 1 - *0x40);
    uint256* var6 = *0x40;
    *var6 = par2;
    emit Transfer(*0x40, var6 + 1 - *0x40);
    return 0x1;
}
