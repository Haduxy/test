// Decompiled by JEB v3.7.0.201909272058

function __impl_blacklist(uint256 par1) private view returns (uint256) {
    *0x20 = 0x5;
    *0x0 = par1;
    var0 = keccak256(0x0, 0x40);
    var0 = storage[var0];
    return var0 & 0xff;
}
