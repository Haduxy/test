// Decompiled by JEB v3.7.0.201909272058

function sub_2431(int256 par1, int256 par2) private pure returns (uint256) {
    uint256 var1 = par1 * par2;
    int256 var2 = (uint256)(par1 == 0x0);

    if(!var2) {
        var2 = par2;
        int256 var3 = par1;
        uint256 var4 = var1;

        if(par1 == 0x0) {
            invalid();
        }

        var2 = (uint256)(var4 / ((uint256)var3) == var2);
    }

    if(var2 == 0x0) {
        invalid();
    }

    return var1;
}
