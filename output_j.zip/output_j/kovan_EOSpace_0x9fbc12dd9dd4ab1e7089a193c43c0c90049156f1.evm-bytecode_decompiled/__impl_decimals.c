// Decompiled by JEB v3.7.0.201909272058

function __impl_decimals() private pure returns (uint256) {
    return 0x12;
}
