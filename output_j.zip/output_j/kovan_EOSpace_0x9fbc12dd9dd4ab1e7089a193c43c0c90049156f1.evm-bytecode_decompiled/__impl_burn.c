// Decompiled by JEB v3.7.0.201909272058

function __impl_burn(uint256 par1) private {
    var2 = storage[0x1];
    uint256 var1 = var2;
    var2 = msg.sender;

    if((address(var1)) != (address(msg.sender))) {
        revert(0x0, 0x0);
    }

    var3 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = 0x3;
    var1 = keccak256(0x0, 0x40);
    var1 = storage[var1];

    if(par1 > var1) {
        revert(0x0, 0x0);
    }

    var1 = msg.sender;
    uint256 var0 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = 0x3;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3];
    var1 = sub_2464(par1, var3);
    *0x0 = address(var0);
    *0x20 = 0x3;
    var2 = keccak256(0x0, 0x40);
    storage[var2] = var1;
    var3 = storage[0x6];
    var1 = sub_2464(par1, var3);
    g1_0 = var1;
    var3 = storage[0x7];
    var1 = sub_2464(par1, var3);
    g2_0 = var1;
    uint256* var5 = *0x40;
    *var5 = par1;
    emit Burn(*0x40, var5 + 1 - *0x40);
}
