// Decompiled by JEB v3.7.0.201909272058

function disableWhitelist() public /*NON-PAYABLE*/ {
    var3 = msg.data.length;
    var4 = calldataload(0x4);
    var4 = var4 + 0x4;
    var5 = calldataload(var4);
    uint256 var7 = *0x40;
    *0x40 = var5 * 0x20 + var7 + 0x20;
    *var7 = var5;
    calldatacopy(var7 + 0x20, var4 + 0x20, var5 * 0x20);
    __impl_disableWhitelist(var7);
    stop();
}
