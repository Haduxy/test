// Decompiled by JEB v3.7.0.201909272058

function sub_2416(uint256 par1, uint256 par2) private pure returns (uint256) {
    uint256 var2 = par2, var3 = par1;

    if(par2 == 0x0) {
        invalid();
    }

    return var3 / var2;
}
