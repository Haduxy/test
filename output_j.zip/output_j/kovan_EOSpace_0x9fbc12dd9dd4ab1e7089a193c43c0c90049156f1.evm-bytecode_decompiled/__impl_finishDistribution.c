// Decompiled by JEB v3.7.0.201909272058

function __impl_finishDistribution() private returns (uint256) {
    var2 = storage[0x1];
    int256 var1 = var2;
    var2 = msg.sender;

    if((address(var1)) != (address(msg.sender))) {
        revert(0x0, 0x0);
    }

    var2 = storage[0xa];

    if((var2 & 0xff) != 0x0) {
        revert(0x0, 0x0);
    }

    var4 = storage[0xa];
    storage[0xa] = (var4 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00) | 0xffffffffffffffff;
    emit DistrFinished(*0x40, 0x0);
    return 0x1;
}
