// Decompiled by JEB v3.7.0.201909272058

function __impl_totalRemaining() private view returns (uint256) {
    var0 = storage[0x8];
    return var0;
}
