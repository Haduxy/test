// Decompiled by JEB v3.7.0.201909272058

function __impl_enableWhitelist(uint256* par1) private {
    var2 = storage[0x1];
    int256 var1 = var2;
    var2 = msg.sender;

    if((address(var1)) != (address(msg.sender))) {
        revert(0x0, 0x0);
    }

    for(uint256 var0 = 0x0; var0 < *par1; ++var0) {
        uint256* var4 = par1;
        uint256 var5 = var0;

        if(*par1 <= var0) {
            invalid();
        }

        *0x0 = address(*(((uint256)(((int256)var5) * 0x20 + ((int256)var4))) + 0x20));
        *0x20 = 0x5;
        var2 = keccak256(0x0, 0x40);
        var4 = storage[var2];
        storage[var2] = ((uint256)(((int256)var4) & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00));
    }
}
