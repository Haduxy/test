// Decompiled by JEB v3.7.0.201909272058

function m_required() public view /*NON-PAYABLE*/ {
    var1 = storage[0x0];
    return;
}
