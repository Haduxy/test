// Decompiled by JEB v3.7.0.201909272058

function changeRequirement() public /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var3 = msg.data.length;
    uint256 var5 = *0x40;
    calldatacopy(var5, 0x0, var3);
    var2 = keccak256(*0x40, var3 + var5 - *0x40);
    var3 = __impl_kill(var2);

    if(var3 != 0x0) {
        var3 = storage[0x1];

        if(var1 <= var3) {
            g0_0 = var1;
            sub_1296();
            uint256* var4 = *0x40;
            *var4 = var1;
            emit RequirementChanged(var4, 0x20);
        }
    }
}
