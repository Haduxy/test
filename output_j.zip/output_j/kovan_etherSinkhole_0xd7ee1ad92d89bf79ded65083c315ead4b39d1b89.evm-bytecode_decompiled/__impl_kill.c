// Decompiled by JEB v3.7.0.201909272058

function __impl_kill(uint256* par1) private returns (uint256) {
    uint256* $tmp, var7;
    var1 = msg.sender;
    uint256 var0 = 0x0;
    *0x0 = address(msg.sender);
    *0x20 = 0x105;
    var1 = keccak256(0x0, 0x40);
    var1 = storage[var1];

    if(var1 != 0x0) {
        *0x0 = par1;
        *0x20 = 0x106;
        var4 = keccak256(0x0, 0x40);
        var5 = storage[var4];
        uint256* var2 = var4;

        if(!((unsigned char)(((int256)var5) != 0x0))) {
            var5 = storage[0x0];
            storage[var2] = var5;
            storage[((uint256)(((char*)var2) + 0x1))] = 0x0;
            var6 = storage[0x107];
            var4 = var6;
            sub_161E(((uint256)(((char*)var4) + 0x1)), 0x107);
            storage[((uint256)(((char*)var2) + 0x2))] = var4;
            var6 = storage[0x107];
            var7 = var4;
            var4 = par1;
            $tmp = var7;
            var7 = var6;
            var6 = $tmp;

            if(!((unsigned char)(((int256)$tmp) < ((int256)var7)))) {
                invalid();
            }

            $tmp = var6;
            *0x0 = 0x107;
            var6 = keccak256(0x0, 0x20);
            storage[((uint256)(((int256)$tmp) + ((int256)var6)))] = var4;
        }

        uint256 var3 = 0x2 ** var1;
        var5 = storage[((uint256)(((char*)var2) + 0x1))];

        if(((uint256)(var3 & ((int256)var5))) == 0x0) {
            var5 = *0x40;
            var7 = msg.sender;
            *var5 = (uint256)(address(((int256)msg.sender)));
            *(var5 + 1) = par1;
            emit Confirmation(*0x40, ((uint256)(((int256)var5) - *0x40)) + 0x40);
            var4 = storage[var2];

            if(!((unsigned char)(((int256)var4) > 0x1))) {
                *0x0 = par1;
                *0x20 = 0x106;
                var4 = keccak256(0x0, 0x40);
                var4 = storage[((uint256)(((char*)var4) + 0x2))];
                var6 = storage[0x107];
                var5 = var4;

                if(!((unsigned char)(((int256)var4) < ((int256)var6)))) {
                    invalid();
                }

                $tmp = var5;
                *0x0 = 0x107;
                var5 = keccak256(0x0, 0x20);
                storage[((uint256)(((int256)$tmp) + ((int256)var5)))] = 0x0;
                *0x0 = par1;
                *0x20 = 0x106;
                var5 = keccak256(0x0, 0x40);
                storage[var5] = 0x0;
                storage[((uint256)(((char*)var5) + 0x1))] = 0x0;
                storage[((uint256)(((char*)var5) + 0x2))] = 0x0;
                var0 = 0x1;
            }
            else {
                var4 = storage[var2];
                storage[var2] = ((uint256)(((char*)var4) + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff));
                var4 = (uint256*)(((char*)var2) + 0x1);
                var5 = storage[var4];
                storage[var4] = ((uint256)(var3 | ((int256)var5)));
            }
        }
    }

    return var0;
}
