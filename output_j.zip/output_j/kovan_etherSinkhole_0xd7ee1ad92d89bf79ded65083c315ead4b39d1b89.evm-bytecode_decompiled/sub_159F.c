// Decompiled by JEB v3.7.0.201909272058

function sub_159F(uint256 par1, uint256 par2, uint256 par3) private returns (uint256) {
    var1 = storage[par1];
    uint256 var0 = ((((uint256)((var1 & 0x1) == 0x0)) * 0x100 - 0x1) & var1) / 0x2;
    *0x0 = par1;
    var1 = keccak256(0x0, 0x20);
    uint256 $tmp = var1;
    var1 = var0;
    var0 = $tmp;
    $tmp = (var1 + 0x1f) / 0x20 + var0;
    var1 = par2;
    par2 = $tmp;

    if(par3 <= 0x1f) {
        var4 = calldataload(var1);
        storage[par1] = (par3 * 0x2) | (var4 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00);
    }
    else {
        storage[par1] = par3 * 0x2 + 0x1;

        if(par3 != 0x0) {
            $tmp = var1;
            var1 = par3;
            par3 = $tmp;
            var1 += $tmp;

            while(par3 < var1) {
                var2 = calldataload(par3);
                storage[var0] = var2;
                par3 += 0x20;
                ++var0;
            }
        }
    }

    sub_166A(var0, par2);
    return par1;
}
