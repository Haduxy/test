// Decompiled by JEB v3.7.0.201909272058

function revoke() public /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var3 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = 0x105;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3];
    int256 var2 = var3;

    if(var3 != 0x0) {
        *0x0 = var1;
        *0x20 = 0x106;
        var4 = keccak256(0x0, 0x40);
        var5 = storage[var4 + 0x1];
        var3 = 0x2 ** var2;

        if((var3 & var5) > 0x0) {
            var5 = storage[var4];
            storage[var4] = var5 + 0x1;
            var5 = var4 + 0x1;
            var6 = storage[var5];
            storage[var5] = ((uint256)(((int256)var6) - var3));
            var6 = *0x40;
            var8 = msg.sender;
            *var6 = address(msg.sender);
            *(var6 + 1) = var1;
            emit Revoke(*0x40, ((uint256)(((int256)var6) - *0x40)) + 0x40);
        }
    }
}
