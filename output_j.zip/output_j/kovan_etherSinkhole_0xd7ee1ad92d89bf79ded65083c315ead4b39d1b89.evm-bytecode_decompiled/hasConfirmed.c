// Decompiled by JEB v3.7.0.201909272058

function hasConfirmed() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var3 = calldataload(0x24);
    *0x0 = var1;
    *0x20 = 0x106;
    var6 = keccak256(0x0, 0x40);
    *0x0 = address(var3);
    uint256 var4 = var6;
    *0x20 = 0x105;
    var5 = keccak256(0x0, 0x40);
    var5 = storage[var5];

    if(var5 != 0x0) {
        var8 = storage[var4 + 0x1];
    }
}
