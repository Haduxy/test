// Decompiled by JEB v3.7.0.201909272058

function confirm() public /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    jump 0x6dd;
}
