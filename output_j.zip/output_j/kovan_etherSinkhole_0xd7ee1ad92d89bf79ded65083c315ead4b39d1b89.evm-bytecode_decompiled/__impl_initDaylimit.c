// Decompiled by JEB v3.7.0.201909272058

function __impl_initDaylimit() private view returns (uint256) {
    var2 = timestamp();
    return var2 / 0x15180;
}
