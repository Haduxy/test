// Decompiled by JEB v3.7.0.201909272058

function sub_14EB(uint256 par1) private returns (uint256) {
    uint256 var0 = 0x0;
    var2 = msg.sender;
    uint256 var1 = __impl_isOwner(msg.sender);

    if(var1 != 0x0) {
        var1 = storage[0x4];
        var2 = __impl_initDaylimit();

        if(var1 < var2) {
            g3_0 = 0x0;
            var1 = __impl_initDaylimit();
            g4_0 = var1;
        }

        var1 = storage[0x3];
        var1 = (uint256)(par1 + var1 < var1);
        var2 = var1;
        var1 = (uint256)(var1 == 0x0);

        if(!var2) {
            var1 = storage[0x2];
            var3 = storage[0x3];
            var1 = (uint256)(par1 + var3 <= var1);
        }

        if(var1 != 0x0) {
            var1 = storage[0x3];
            g3_0 = par1 + var1;
            return 0x1;
        }
        else {
            return 0x0;
        }
    }
    else {
        return 0x0;
    }
}
