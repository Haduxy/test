// Decompiled by JEB v3.7.0.201909272058

function resetSpentToday() public /*NON-PAYABLE*/ {
    var2 = msg.data.length;
    uint256 var4 = *0x40;
    calldatacopy(var4, 0x0, var2);
    var1 = keccak256(*0x40, var2 + var4 - *0x40);
    var2 = __impl_kill(var1);

    if(var2 != 0x0) {
        g3_0 = 0x0;
    }
}
