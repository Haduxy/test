// Decompiled by JEB v3.7.0.201909272058

function execute() public /*NON-PAYABLE*/ {
    uint256* var19, var16;
    uint256 var11, var12;
    var2 = calldataload(0x4);
    uint256 var1 = address(var2);
    var4 = calldataload(0x24);
    var2 = var4;
    var5 = calldataload(0x44);
    uint256 var3 = var5 + 0x24;
    var4 = calldataload(var5 + 0x4);
    uint256 var6 = 0x0;
    var8 = msg.sender;
    uint256 var7 = __impl_isOwner(msg.sender);

    if(var7 != 0x0) {
        var7 = (uint256)(var4 == 0x0);

        if(var7 != 0x0) {
            var7 = sub_14EB(var2);
        }

        if(!var7) {
            var7 = storage[0x0];
            var7 = (uint256)(var7 == 0x1);
        }

        if(var7 != 0x0) {

            if((address(var1)) == 0x0) {
                var12 = *0x40;
                *0x40 = (var4 + 0x1f) / 0x20 * 0x20 + var12 + 0x20;
                *var12 = var4;
                calldatacopy(var12 + 0x20, var3, var4);
                var7 = sub_14C2(var12, var2);
                var6 = var7;
            }
            else {
                var12 = *0x40;
                calldatacopy(var12, var3, var4);
                var11 = *0x40;
                var17 = gasleft();
                var10 = call(var17 - 0x8502, address(var1), var2, var11, var4 + var12 - var11, var11, 0x0);

                if(var10 == 0x0) {
                    throw();
                }
            }

            var8 = msg.sender;
            uint256* var14 = *0x40;
            *var14 = address(msg.sender);
            uint256* var15 = var14 + 1;
            *var15 = var2;
            ++var15;
            *var15 = address(var1);
            ++var15;
            var16 = var15 + 1;
            *var16 = address(var6);
            ++var16;
            *var15 = (uint256)(((int256)var16) - ((int256)var14));
            *var16 = var4;
            ++var16;
            calldatacopy(var16, var3, var4);
            var19 = var16;
            var16 = *0x40;
            emit SingleTransact(var16, ((uint256)(((uint256)(var4 + ((int256)var19))) - ((int256)var16))));
        }
        else {
            var8 = msg.data.length;
            var9 = number();
            var11 = *0x40;
            calldatacopy(var11, 0x0, var8);
            var12 = var9;
            var9 = var8 + var11;
            *var9 = var12;
            var11 = *0x40;
            var11 = keccak256(var11, var9 - var11 + 0x20);
            *0x0 = var11;
            *0x20 = 0x108;
            var10 = keccak256(0x0, 0x40);
            var10 = storage[var10];
            var5 = var11;
            var7 = (uint256)((address(var10)) == 0x0);

            if(var7 != 0x0) {
                *0x0 = var11;
                *0x20 = 0x108;
                var7 = keccak256(0x0, 0x40);
                var7 = storage[var7 + 0x1];
                var7 = (uint256)(var7 == 0x0);
            }

            if(var7 != 0x0) {
                *0x0 = var5;
                *0x20 = 0x108;
                var7 = keccak256(0x0, 0x40);
                var8 = storage[var7 + 0x2];
                var7 = (uint256)(((((uint256)((var8 & 0x1) == 0x0)) * 0x100 + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff) & var8) / 0x2 == 0x0);
            }

            if(var7 != 0x0) {
                *0x0 = var5;
                *0x20 = 0x108;
                var7 = keccak256(0x0, 0x40);
                var8 = storage[var7];
                storage[var7] = (address(var1)) | (var8 & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000);
                storage[var7 + 0x1] = var2;
                sub_159F(var4, var3, var7 + 0x2);
            }

            var7 = sub_6DD(var5);

            if(var7 == 0x0) {
                var8 = *0x40;
                *var8 = var5;
                var10 = msg.sender;
                *(var8 + 0x20) = address(msg.sender);
                *(var8 + 0x40) = var2;
                *(var8 + 0x60) = address(var1);
                *(var8 + 0x80) = 0xa0;
                *(var8 + 0xa0) = var4;
                var16 = var8 + 0xc0;
                calldatacopy(var16, var3, var4);
                var19 = var16;
                var16 = *0x40;
                emit ConfirmationNeeded(var16, ((uint256)(((uint256)(var4 + ((int256)var19))) - ((int256)var16))));
            }
        }
    }
}
