// Decompiled by JEB v3.7.0.201909272058

function sub_1557(uint256 par1, uint256 par2) private {
    par2 = storage[par1];
    storage[par1] = 0x0;

    if(((((uint256)((par2 & 0x1) == 0x0)) * 0x100 - 0x1) & par2) / 0x2 <= 0x1f) {
        return;
    }
    else {
        *0x0 = par1;
        par2 = keccak256(0x0, 0x20);
        jump 0x166a;
    }
}
