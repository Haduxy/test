// Decompiled by JEB v3.7.0.201909272058

function __impl_isOwner(uint256 par1) private view returns (uint256) {
    *0x0 = address(par1);
    *0x20 = 0x105;
    var1 = keccak256(0x0, 0x40);
    var1 = storage[var1];
    return (uint256)(var1 > 0x0);
}
