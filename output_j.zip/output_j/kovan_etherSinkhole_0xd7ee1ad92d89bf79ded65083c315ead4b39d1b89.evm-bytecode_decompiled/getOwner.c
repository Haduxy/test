// Decompiled by JEB v3.7.0.201909272058

function getOwner() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    uint256 var0 = __impl_getOwner(var1);
    uint256 var3 = var0;
    var0 = *0x40;
    *var0 = address(var3);
    return(var0, 0x20);
}
