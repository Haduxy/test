// Decompiled by JEB v3.7.0.201909272058

function __impl_getOwner(uint256 par1) private view returns (uint256) {
    uint256 var2 = par1 + 0x1;

    if(var2 >= 0x100) {
        invalid();
    }

    var1 = storage[var2 + 0x5];
    return var1;
}
