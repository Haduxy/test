// Decompiled by JEB v3.7.0.201909272058

function initMultiowned() public /*NON-PAYABLE*/ {
    var3 = calldataload(0x4);
    var3 += 0x4;
    var4 = calldataload(var3);
    int256 var6 = *0x40;
    *0x40 = var4 * 0x20 + var6 + 0x20;
    *var6 = var4;
    calldatacopy(var6 + 0x20, var3 + 0x20, var4 * 0x20);
    int256 var1 = var6;
    var6 = calldataload(0x24);
    int256 var2 = var6;
    g1_0 = *var1 + 0x1;
    var6 = msg.sender;
    g5_0 = address(msg.sender);
    var4 = msg.sender;
    var3 = 0x0;
    *0x0 = address(msg.sender);
    *0x20 = 0x105;
    var4 = keccak256(0x0, 0x40);
    storage[var4] = 0x1;

    while(*var1 > var3) {
        var4 = var1;
        uint256 var5 = var3;

        if(*var1 <= var3) {
            invalid();
        }

        var4 = address(*(((int256)var5) * 0x20 + var4 + 0x20));
        var6 = var3 + 0x2;

        if(((uint256)var6) >= 0x100) {
            invalid();
        }

        storage[var6 + 0x5] = var4;
        var4 = var3 + 0x2;
        int256 var7 = var1;
        uint256 var8 = var3;

        if(*var1 <= var3) {
            invalid();
        }

        *0x0 = address(*(((int256)var8) * 0x20 + var7 + 0x20));
        *0x20 = 0x105;
        var5 = keccak256(0x0, 0x40);
        storage[var5] = var4;
        ++var3;
    }

    g0_0 = var2;
}
