// Decompiled by JEB v3.7.0.201909272058

function sub_1386() private {
    uint256 var2, var0 = 0x1;

    while(1) {
        var1 = storage[0x1];

        if(var0 >= var1) {
            return;
        }
        else {

            while(1) {
                var1 = storage[0x1];
                var1 = (uint256)(var0 < var1);

                if(var1 != 0x0) {
                    var2 = var0;

                    if(var0 >= 0x100) {
                        invalid();
                    }

                    var1 = storage[var2 + 0x5];
                    var1 = (uint256)(var1 != 0x0);
                }

                if(var1 == 0x0) {
                    break;
                }
                else {
                    ++var0;
                }
            }

            while(1) {
                var2 = storage[0x1];
                var1 = (uint256)(var2 > 0x1);

                if(var1 != 0x0) {
                    var1 = storage[0x1];
                    var2 = var1;

                    if(var1 >= 0x100) {
                        invalid();
                    }

                    var1 = storage[var2 + 0x5];
                    var1 = (uint256)(var1 == 0x0);
                }

                if(var1 == 0x0) {
                    break;
                }
                else {
                    var2 = storage[0x1];
                    g1_0 = var2 + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff;
                }
            }

            var1 = storage[0x1];
            var1 = (uint256)(var0 < var1);

            if(var1 != 0x0) {
                var1 = storage[0x1];
                var2 = var1;

                if(var1 >= 0x100) {
                    invalid();
                }

                var1 = storage[var2 + 0x5];
                var1 = (uint256)(var1 != 0x0);
            }

            if(var1 != 0x0) {
                var2 = var0;

                if(var0 >= 0x100) {
                    invalid();
                }

                var1 = storage[var2 + 0x5];
                var1 = (uint256)(var1 == 0x0);
            }

            if(var1 != 0x0) {
                var1 = storage[0x1];
                var2 = var1;

                if(var1 >= 0x100) {
                    invalid();
                }

                var1 = storage[var2 + 0x5];
                uint256 var3 = var0;

                if(var0 >= 0x100) {
                    invalid();
                }

                storage[var3 + 0x5] = var1;
                var1 = var0;
                uint256 var5 = var0;

                if(var0 >= 0x100) {
                    invalid();
                }

                var4 = storage[var5 + 0x5];
                *0x0 = var4;
                *0x20 = 0x105;
                var2 = keccak256(0x0, 0x40);
                storage[var2] = var1;
                var3 = storage[0x1];

                if(var3 >= 0x100) {
                    invalid();
                }

                storage[var3 + 0x5] = 0x0;
            }
        }
    }
}
