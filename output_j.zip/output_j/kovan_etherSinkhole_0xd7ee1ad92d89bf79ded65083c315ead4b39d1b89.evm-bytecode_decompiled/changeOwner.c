// Decompiled by JEB v3.7.0.201909272058

function changeOwner() public /*NON-PAYABLE*/ {
    var2 = calldataload(0x4);
    uint256 var1 = address(var2);
    var3 = calldataload(0x24);
    var2 = address(var3);
    var5 = msg.data.length;
    uint256 var7 = *0x40;
    calldatacopy(var7, 0x0, var5);
    var4 = keccak256(*0x40, var5 + var7 - *0x40);
    var5 = __impl_kill(var4);

    if(var5 != 0x0) {
        var5 = __impl_isOwner(var2);

        if(var5 == 0x0) {
            *0x0 = address(var1);
            *0x20 = 0x105;
            var5 = keccak256(0x0, 0x40);
            var5 = storage[var5];
            var3 = var5;

            if(var5 != 0x0) {
                sub_1296();
                var5 = address(var2);
                var7 = var3;

                if(var3 >= 0x100) {
                    invalid();
                }

                storage[var7 + 0x5] = var5;
                *0x0 = address(var1);
                *0x20 = 0x105;
                var10 = keccak256(0x0, 0x40);
                storage[var10] = 0x0;
                *0x0 = address(var2);
                var9 = keccak256(0x0, 0x40);
                storage[var9] = var3;
                uint256* var6 = *0x40;
                *var6 = address(var1);
                *(var6 + 1) = address(var2);
                emit OwnerChanged(*0x40, ((uint256)(((int256)var6) - *0x40)) + 0x40);
                return;
            }
        }
    }
}
