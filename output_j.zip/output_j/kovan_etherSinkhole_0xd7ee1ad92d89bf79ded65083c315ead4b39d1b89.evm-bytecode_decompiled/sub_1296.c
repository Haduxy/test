// Decompiled by JEB v3.7.0.201909272058

function sub_1296() private {
    var0 = storage[0x107];

    for(uint256 var1 = 0x0; var1 < var0; ++var1) {
        uint256 var5 = var1;
        var6 = storage[0x107];

        if(var5 >= var6) {
            invalid();
        }

        uint256 $tmp = var5;
        *0x0 = 0x107;
        var5 = keccak256(0x0, 0x20);
        var4 = storage[$tmp + var5];
        *0x0 = var4;
        *0x20 = 0x108;
        var3 = keccak256(0x0, 0x40);
        var4 = storage[var3];
        storage[var3] = var4 & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000;
        storage[var3 + 0x1] = 0x0;
        sub_1557(0x0, var3 + 0x2);
        var3 = storage[0x107];
        var4 = var3;
        var3 = var1;

        if(var1 >= var4) {
            invalid();
        }

        $tmp = var3;
        *0x0 = 0x107;
        var3 = keccak256(0x0, 0x20);
        var2 = storage[$tmp + var3];

        if(var2 != 0x0) {
            var5 = var1;
            var6 = storage[0x107];

            if(var5 >= var6) {
                invalid();
            }

            $tmp = var5;
            *0x0 = 0x107;
            var5 = keccak256(0x0, 0x20);
            var4 = storage[$tmp + var5];
            *0x0 = var4;
            *0x20 = 0x106;
            var3 = keccak256(0x0, 0x40);
            storage[var3] = 0x0;
            storage[var3 + 0x1] = 0x0;
            storage[var3 + 0x2] = 0x0;
        }
    }

    var4 = storage[0x107];
    g6_0 = 0x0;
    *0x0 = 0x107;
    var4 = keccak256(0x0, 0x20);
    jump 0x166a;
}
