// Decompiled by JEB v3.7.0.201909272058

function m_dailyLimit() public view /*NON-PAYABLE*/ {
    var1 = storage[0x2];
    return;
}
