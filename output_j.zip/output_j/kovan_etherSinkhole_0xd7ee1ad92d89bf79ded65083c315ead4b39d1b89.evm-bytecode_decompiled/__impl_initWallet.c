// Decompiled by JEB v3.7.0.201909272058

function __impl_initWallet(uint256 par1) private {
    g2_0 = par1;
    uint256 var0 = __impl_initDaylimit();
    g4_0 = var0;
}
