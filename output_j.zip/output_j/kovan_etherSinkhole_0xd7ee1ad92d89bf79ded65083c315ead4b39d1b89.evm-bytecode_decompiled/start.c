// Decompiled by JEB v3.7.0.201909272058

function start() {
    *0x40 = 0x60;
    var0 = msg.data.length;

    if(var0 != 0x0) {
        var0 = (uint256)$msg.sig;

        if(var0 == 0x173825d9) {
            removeOwner();
        }

        if(var0 == 0x2f54bf6e) {
            isOwner();
        }

        if(var0 == 0x4123cb6b) {
            m_numOwners();
        }

        if(var0 == 0x52375093) {
            m_lastDay();
        }

        if(var0 == 0x5c52c2f5) {
            resetSpentToday();
        }

        if(var0 == 0x659010e7) {
            m_spentToday();
        }

        if(var0 == 0x7065cb48) {
            addOwner();
        }

        if(var0 == 0x746c9171) {
            m_required();
        }

        if(var0 == 0x797af627) {
            confirm();
        }

        if(var0 == 0x9da5e0eb) {
            initDaylimit();
        }

        if(var0 == 0xb20d30a9) {
            setDailyLimit();
        }

        if(var0 == 0xb61d27f6) {
            execute();
        }

        if(var0 == 0xb75c7dc6) {
            revoke();
        }

        if(var0 == 0xba51a6df) {
            changeRequirement();
        }

        if(var0 == 0xc2cf7326) {
            hasConfirmed();
        }

        if(var0 == 0xc41a360a) {
            getOwner();
        }

        if(var0 == 0xc57c5f60) {
            initMultiowned();
        }

        if(var0 == 0xcbf0b0c0) {
            kill();
        }

        if(var0 == 0xe46dcfeb) {
            initWallet();
        }

        if(var0 == 0xf00d4b5d) {
            changeOwner();
        }

        if(var0 == 0xf1736d86) {
            m_dailyLimit();
        }
    }

    if($msg.value > 0x0) {
        uint256* var2 = *0x40;
        var4 = msg.sender;
        *var2 = address(msg.sender);
        *(var2 + 1) = $msg.value;
        emit Deposit(*0x40, ((uint256)(((int256)var2) - *0x40)) + 0x40);
    }

    stop();
}
