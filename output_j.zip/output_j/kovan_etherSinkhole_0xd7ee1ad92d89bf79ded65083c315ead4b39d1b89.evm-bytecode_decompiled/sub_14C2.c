// Decompiled by JEB v3.7.0.201909272058

function sub_14C2(uint256 par1, uint256 par2) private returns (uint256) {
    var1 = create(par1, par2 + 0x20, *par2);
    int256 var0 = var1;
    var1 = extcodesize(var0);

    if(var1 == 0x0) {
        throw();
    }

    return var0;
}
