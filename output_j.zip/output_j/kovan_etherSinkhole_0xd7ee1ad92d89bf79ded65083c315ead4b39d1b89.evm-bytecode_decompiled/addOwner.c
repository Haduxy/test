// Decompiled by JEB v3.7.0.201909272058

function addOwner() public /*NON-PAYABLE*/ {
    var2 = calldataload(0x4);
    uint256 var1 = address(var2);
    var3 = msg.data.length;
    uint256 var5 = *0x40;
    calldatacopy(var5, 0x0, var3);
    var2 = keccak256(*0x40, var3 + var5 - *0x40);
    var3 = __impl_kill(var2);

    if(var3 != 0x0) {
        var3 = __impl_isOwner(var1);

        if(var3 == 0x0) {
            sub_1296();
            var3 = storage[0x1];

            if(var3 >= 0xfa) {
                sub_1386();
            }

            var3 = storage[0x1];

            if(var3 < 0xfa) {
                var4 = storage[0x1];
                var3 = var4 + 0x1;
                g1_0 = var3;
                var4 = var3;
                var3 = address(var1);
                var5 = var4;

                if(var4 >= 0x100) {
                    invalid();
                }

                storage[var5 + 0x5] = var3;
                var3 = storage[0x1];
                *0x0 = address(var1);
                *0x20 = 0x105;
                var7 = keccak256(0x0, 0x40);
                storage[var7] = var3;
                var4 = *0x40;
                *var4 = address(var1);
                emit OwnerAdded(*0x40, var4 - *0x40 + 0x20);
            }
        }
    }
}
