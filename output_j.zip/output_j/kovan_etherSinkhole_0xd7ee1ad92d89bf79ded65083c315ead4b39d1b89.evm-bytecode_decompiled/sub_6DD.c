// Decompiled by JEB v3.7.0.201909272058

function sub_6DD(uint256 par1) private returns (uint256) {
    uint256 var10, $tmp, var6, var8, var0 = 0x0, var1 = 0x0;
    uint256 var3 = __impl_kill(par1);

    if(var3 != 0x0) {
        *0x0 = par1;
        *0x20 = 0x108;
        var3 = keccak256(0x0, 0x40);
        var3 = storage[var3];
        var3 = (uint256)((address(var3)) != 0x0);

        if(!var3) {
            *0x0 = par1;
            *0x20 = 0x108;
            var3 = keccak256(0x0, 0x40);
            var3 = storage[var3 + 0x1];
            var3 = (uint256)(var3 != 0x0);
        }

        if(!var3) {
            *0x0 = par1;
            *0x20 = 0x108;
            var3 = keccak256(0x0, 0x40);
            var4 = storage[var3 + 0x2];
            var3 = (uint256)(((((uint256)((var4 & 0x1) == 0x0)) * 0x100 + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff) & var4) / 0x2 != 0x0);
        }

        if(var3 != 0x0) {
            *0x0 = par1;
            *0x20 = 0x108;
            var3 = keccak256(0x0, 0x40);
            var3 = storage[var3];
            *0x0 = par1;
            *0x20 = 0x108;

            if((address(var3)) == 0x0) {
                var5 = keccak256(0x0, 0x40);
                var7 = storage[var5 + 0x1];
                var8 = var5 + 0x2;
                var9 = storage[var8];
                var6 = *0x40;
                var5 = var8;
                var8 = ((((uint256)((var9 & 0x1) == 0x0)) * 0x100 + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff) & var9) / 0x2;
                *0x40 = (var8 + 0x1f) / 0x20 * 0x20 + var6 + 0x20;
                *var6 = var8;
                $tmp = var8;
                var8 = var7;
                var7 = $tmp;
                var4 = var8;
                var8 = var5;
                var5 = var6;
                $tmp = var8;
                var8 = var6 + 0x20;
                var9 = $tmp;
                var10 = var7;

                if(var7 != 0x0 && var7 <= 0x1f) {
                    var13 = storage[var9];
                    *var8 = var13 / 0x100 * 0x100;
                }
                else if(var7 != 0x0) {
                    $tmp = var8;
                    var8 += var7;
                    var10 = var9;
                    var9 = $tmp;
                    *0x0 = var10;
                    var10 = keccak256(0x0, 0x20);
                    $tmp = var10;
                    var10 = var9;
                    var9 = $tmp;

                    do {
                        var11 = storage[var9];
                        *var10 = var11;
                        ++var9;
                        var10 += 0x20;
                    }
                    while(var8 > var10);
                }

                var3 = sub_14C2(var5, var4);
                var1 = var3;
            }
            else {
                var4 = keccak256(0x0, 0x40);
                var5 = storage[var4];
                var7 = storage[var4 + 0x1];
                var8 = var4 + 0x2;
                var9 = storage[var8];
                var3 = address(var5);
                var4 = var7;
                var7 = *0x40;
                var9 = ((((uint256)((var9 & 0x1) == 0x0)) * 0x100 + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff) & var9) / 0x2;

                if(var9 != 0x0 && var9 <= 0x1f) {
                    var12 = storage[var8];
                    *var7 = var12 / 0x100 * 0x100;
                    var7 += 0x20;
                }
                else if(var9 != 0x0) {
                    $tmp = var7;
                    var7 += var9;
                    var9 = var8;
                    var8 = $tmp;
                    *0x0 = var9;
                    var9 = keccak256(0x0, 0x20);
                    $tmp = var9;
                    var9 = var8;
                    var8 = $tmp;

                    do {
                        var10 = storage[var8];
                        *var9 = var10;
                        ++var8;
                        var9 += 0x20;
                    }
                    while(var7 > var9);

                    var7 += (var9 - var7) & 0x1f;
                }

                var5 = var7;
                var7 = *0x40;
                var13 = gasleft();
                var6 = call(var13 - 0x8502, var3, var4, var7, var5 - var7, var7, 0x0);

                if(var6 == 0x0) {
                    throw();
                }
            }

            *0x0 = par1;
            *0x20 = 0x108;
            var5 = keccak256(0x0, 0x40);
            var7 = storage[var5 + 0x1];
            var8 = storage[var5];
            var9 = *0x40;
            var11 = msg.sender;
            *var9 = address(msg.sender);
            *(var9 + 0x20) = par1;
            *(var9 + 0x40) = var7;
            $tmp = var9;
            *(var9 + 0x60) = address(var8);
            *(var9 + 0xa0) = address(var1);
            *(var9 + 0x80) = 0xc0;
            var11 = var5 + 0x2;
            var12 = storage[var11];
            var9 = ((((uint256)((var12 & 0x1) == 0x0)) * 0x100 + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff) & var12) / 0x2;
            *($tmp + 0xc0) = ((((uint256)((var12 & 0x1) == 0x0)) * 0x100 + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff) & var12) / 0x2;
            var12 = $tmp + 0xe0;
            uint256 var14 = var9;
            var13 = var11;

            if(var9 != 0x0 && var9 <= 0x1f) {
                var17 = storage[var13];
                *var12 = var17 / 0x100 * 0x100;
                var12 += 0x20;
            }
            else if(var9 != 0x0) {
                $tmp = var12;
                var12 += var9;
                var14 = var11;
                var13 = $tmp;
                *0x0 = var11;
                var14 = keccak256(0x0, 0x20);
                $tmp = var14;
                var14 = var13;
                var13 = $tmp;

                do {
                    var15 = storage[var13];
                    *var14 = var15;
                    ++var13;
                    var14 += 0x20;
                }
                while(var12 > var14);

                var12 += (var14 - var12) & 0x1f;
            }

            emit MultiTransact(*0x40, var12 - *0x40);
            *0x0 = par1;
            *0x20 = 0x108;
            var4 = keccak256(0x0, 0x40);
            var5 = storage[var4];
            storage[var4] = var5 & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000;
            storage[var4 + 0x1] = 0x0;
            sub_1557(0x0, var4 + 0x2);
            var0 = 0x1;
        }
    }

    return var0;
}
