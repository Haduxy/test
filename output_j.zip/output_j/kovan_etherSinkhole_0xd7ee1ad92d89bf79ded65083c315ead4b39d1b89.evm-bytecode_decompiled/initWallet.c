// Decompiled by JEB v3.7.0.201909272058

function initWallet() public /*NON-PAYABLE*/ {
    var3 = calldataload(0x4);
    var3 += 0x4;
    var4 = calldataload(var3);
    uint256 var6 = *0x40;
    *0x40 = var4 * 0x20 + var6 + 0x20;
    *var6 = var4;
    calldatacopy(var6 + 0x20, var3 + 0x20, var4 * 0x20);
    uint256 var1 = var6;
    var7 = calldataload(0x24);
    uint256 var2 = var7;
    var7 = calldataload(0x44);
    var3 = var7;
    __impl_initWallet(var3);
    uint256 var5 = var1;
    var6 = var2;
    g1_0 = *var1 + 0x1;
    var10 = msg.sender;
    g5_0 = address(msg.sender);
    var8 = msg.sender;
    var7 = 0x0;
    *0x0 = address(msg.sender);
    *0x20 = 0x105;
    var8 = keccak256(0x0, 0x40);
    storage[var8] = 0x1;

    while(*var5 > var7) {
        var8 = var5;
        uint256 var9 = var7;

        if(*var5 <= var7) {
            invalid();
        }

        var8 = address(*(var9 * 0x20 + var8 + 0x20));
        var10 = var7 + 0x2;

        if(((uint256)var10) >= 0x100) {
            invalid();
        }

        storage[var10 + 0x5] = var8;
        var8 = var7 + 0x2;
        uint256 var11 = var5, var12 = var7;

        if(*var5 <= var7) {
            invalid();
        }

        *0x0 = address(*(var12 * 0x20 + var11 + 0x20));
        *0x20 = 0x105;
        var9 = keccak256(0x0, 0x40);
        storage[var9] = var8;
        ++var7;
    }

    g0_0 = var6;
}
