// Decompiled by JEB v3.7.0.201909272058

function sub_166A(uint256 par1, uint256 par2) private returns (uint256) {
    uint256 var0 = par2;
    par2 = par1;

    while(par2 > var0) {
        storage[var0] = 0x0;
        ++var0;
    }

    return par2;
}
