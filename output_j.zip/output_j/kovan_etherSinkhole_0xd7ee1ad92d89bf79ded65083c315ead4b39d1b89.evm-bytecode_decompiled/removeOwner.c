// Decompiled by JEB v3.7.0.201909272058

function removeOwner() public /*NON-PAYABLE*/ {
    var2 = calldataload(0x4);
    uint256 var1 = address(var2);
    var4 = msg.data.length;
    uint256 var6 = *0x40;
    calldatacopy(var6, 0x0, var4);
    var3 = keccak256(*0x40, var4 + var6 - *0x40);
    var4 = __impl_kill(var3);

    if(var4 != 0x0) {
        *0x0 = address(var1);
        *0x20 = 0x105;
        var4 = keccak256(0x0, 0x40);
        var4 = storage[var4];
        var2 = var4;

        if(var4 != 0x0) {
            var5 = storage[0x1];
            var4 = var5 - 0x1;
            var5 = storage[0x0];

            if(var4 >= var5) {
                var6 = var2;

                if(var2 >= 0x100) {
                    invalid();
                }

                storage[var6 + 0x5] = 0x0;
                *0x0 = address(var1);
                *0x20 = 0x105;
                var5 = keccak256(0x0, 0x40);
                storage[var5] = 0x0;
                sub_1296();
                sub_1386();
                var5 = *0x40;
                *var5 = address(var1);
                emit OwnerRemoved(var5, 0x20);
            }
        }
    }
}
