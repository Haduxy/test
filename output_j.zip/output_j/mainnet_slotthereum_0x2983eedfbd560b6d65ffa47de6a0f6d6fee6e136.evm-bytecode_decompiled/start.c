// Decompiled by JEB v3.7.0.201909272058

function start() {
    *0x40 = 0x60;
    var1 = msg.data.length;

    if(var1 >= 0x4) {
        uint256 var0 = (uint256)$msg.sig;

        if(var0 == 0x117a5b90) {
            games();
        }

        if(var0 == 0x188b81b4) {
            getGameEnd();
        }

        if(var0 == 0x1d6b867c) {
            getGamePlayer();
        }

        if(var0 == 0x29a86dde) {
            getGameWin();
        }

        if(var0 == 0x2e1a7d4d) {
            withdraw();
        }

        if(var0 == 0x41c0e1b5) {
            kill();
        }

        if(var0 == 0x4e72ec91) {
            setPointer();
        }

        if(var0 == 0x550ed1f0) {
            getMaxBetAmount();
        }

        if(var0 == 0x6c188593) {
            setMinBetAmount();
        }

        if(var0 == 0x7cfbc7a5) {
            setMaxBetAmount();
        }

        if(var0 == 0x82a5285d) {
            getMinBetAmount();
        }

        if(var0 == 0x9439060f) {
            getGameNumber();
        }

        if(var0 == 0x9f668bba) {
            getGameIds();
        }

        if(var0 == 0xa648567b) {
            placeBet();
        }

        if(var0 == 0xc20547b3) {
            getGameAmount();
        }

        if(var0 == 0xc235a5c7) {
            getGameStart();
        }

        if(var0 == 0xd1988b6a) {
            getGameHash();
        }

        if(var0 == 0xead2bfdc) {
            getGamePrize();
        }

        if(var0 == 0xf6928070) {
            numberOfGames();
        }
    }

    stop();
}
