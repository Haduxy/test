// Decompiled by JEB v3.7.0.201909272058

function __impl_games(uint256 par1) private view returns (uint256) {
    var1 = storage[0x1];
    uint256 var2 = var1;
    var1 = par1;

    if(par1 >= var2) {
        invalid();
    }

    *0x0 = 0x1;
    uint256 var0 = var1;
    var1 = keccak256(0x0, 0x20);
    var0 = ((int256)var0) * 0x7 + var1;
    var1 = storage[var0];
    var2 = storage[var0 + 0x1];
    var3 = storage[var0 + 0x2];
    var4 = storage[var0 + 0x3];
    var5 = storage[var0 + 0x4];
    var6 = storage[var0 + 0x5];
    var6 = storage[var0 + 0x6];
    return var6;
}
