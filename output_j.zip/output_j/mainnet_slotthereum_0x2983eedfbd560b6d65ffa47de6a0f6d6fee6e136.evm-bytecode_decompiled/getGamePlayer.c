// Decompiled by JEB v3.7.0.201909272058

function getGamePlayer() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    uint256 var0 = __impl_getGamePlayer(var1);
    uint256 var2 = var0;
    var0 = *0x40;
    *var0 = address(var2);
    return(*0x40, var0 + 0x20 - *0x40);
}
