// Decompiled by JEB v3.7.0.201909272058

function sub_D8D(uint256 par1, uint256 par2, uint256 par3, uint256 par4, uint256 par5, uint256 par6, uint256 par7, uint256 par8) private {
    uint256* var8;

    if(par8 != 0x0) {
        var8 = *0x40;
        *var8 = par3 & 0xff;
        *(var8 + 1) = par4 & 0xff;
        *(var8 + &loc_2) = par5 & 0xff;
        *(var8 + 3) = par6;
        *(var8 + &loc_4) = par7;
        emit GameWin(*0x40, var8 + &loc_5 - *0x40);
    }
    else {
        var8 = *0x40;
        *var8 = par3 & 0xff;
        *(var8 + 1) = par4 & 0xff;
        *(var8 + &loc_2) = par5 & 0xff;
        *(var8 + 3) = par6;
        *(var8 + &loc_4) = par7;
        emit GameLoose(*0x40, var8 + &loc_5 - *0x40);
    }
}
