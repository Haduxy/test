// Decompiled by JEB v3.7.0.201909272058

function getGameEnd() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    uint256 var0 = __impl_getGameEnd(var1);
    uint256 var2 = var0;
    var0 = *0x40;
    *var0 = var2 & 0xff;
    return(*0x40, var0 + 0x20 - *0x40);
}
