// Decompiled by JEB v3.7.0.201909272058

function __impl_getGamePlayer(uint256 par1) private view returns (uint256) {
    uint256 var2 = par1;
    var3 = storage[0x1];

    if(var2 >= var3) {
        invalid();
    }

    *0x0 = 0x1;
    uint256 var1 = var2;
    var2 = keccak256(0x0, 0x20);
    var1 = storage[((int256)var1) * 0x7 + var2];
    return address(var1);
}
