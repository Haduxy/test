// Decompiled by JEB v3.7.0.201909272058

function getGameWin() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    uint256 var0 = __impl_getGameWin(var1);
    var1 = var0;
    var0 = *0x40;
    *var0 = (uint256)(var1 != 0x0);
    return(*0x40, var0 + 0x20 - *0x40);
}
