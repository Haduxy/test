// Decompiled by JEB v3.7.0.201909272058

function getGameStart() public view /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    uint256 var4 = var1;
    var5 = storage[0x1];

    if(var4 >= var5) {
        invalid();
    }

    *0x0 = 0x1;
    uint256 var3 = var4;
    var4 = keccak256(0x0, 0x20);
    var3 = storage[((int256)var3) * 0x7 + var4 + 0x3];
}
