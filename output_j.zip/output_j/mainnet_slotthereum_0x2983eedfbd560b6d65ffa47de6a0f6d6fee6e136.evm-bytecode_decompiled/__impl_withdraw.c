// Decompiled by JEB v3.7.0.201909272058

function __impl_withdraw(uint256 par1) private returns (uint256) {
    uint256 var0 = 0x0;
    var1 = storage[0x0];
    var2 = msg.sender;

    if((address(var1)) == (address(msg.sender))) {
        var2 = address(this);
        var1 = balance(address(address(this)));

        if(par1 <= var1) {
            var2 = msg.sender;
            var5 = send(address(msg.sender), par1);

            if(var5 == 0x0) {
                revert(0x0, 0x0);
            }

            return par1;
        }
        else {
            return 0x0;
        }
    }
    else {
        return var0;
    }
}
