// Decompiled by JEB v3.7.0.201909272058

function kill() public /*NON-PAYABLE*/ {
    var1 = storage[0x0];
    var2 = msg.sender;

    if((address(var1)) == (address(msg.sender))) {
        var1 = storage[0x0];
        suicide(address(var1));
    }
}
