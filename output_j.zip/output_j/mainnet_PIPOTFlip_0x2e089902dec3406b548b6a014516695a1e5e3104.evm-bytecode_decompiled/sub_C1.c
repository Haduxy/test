// Decompiled by JEB v3.7.0.201909272058

function sub_C1() public view /*NON-PAYABLE*/ {
    var1 = storage[0x4];
    return;
}
