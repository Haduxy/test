// Decompiled by JEB v3.7.0.201909272058

function claimEther() public /*NON-PAYABLE*/ {
    var2 = storage[0x0];
    var3 = msg.sender;

    if((address(var2)) != msg.sender) {
        revert(0x0, 0x0);
    }

    var1 = storage[0x7];
    var3 = address(this);
    var3 = balance(var3);
    transfer(address(var1), var3);
}
