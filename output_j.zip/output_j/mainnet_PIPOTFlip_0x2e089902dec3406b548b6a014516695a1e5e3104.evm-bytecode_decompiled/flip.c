// Decompiled by JEB v3.7.0.201909272058

function flip() public payable {
    var1 = calldataload(0x4);
    var1 = (uint256)(var1 != 0x0);
    var2 = storage[0x4];
    var4 = number();
    var3 = blockhash(var4 + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
    int256 $tmp = var3;
    var3 = var2;
    var2 = $tmp;

    if($msg.value < ((uint256)var3)) {
        revert(0x0, 0x0);
    }

    var10 = storage[0x1];

    if(var2 == var10) {
        revert(0x0, 0x0);
    }

    var9 = storage[0x3];
    var10 = msg.sender;
    var3 = msg.sender;
    var4 = ((int256)$msg.value) * var9 / 0x64;
    uint256 var5 = $msg.value - var4;
    uint256 var6 = 0x0;
    var9 = storage[0x4];
    var9 = (uint256)($msg.value >= ((uint256)var9));

    if(var9 != 0x0) {
        var9 = storage[0x5];
        var9 = (uint256)($msg.value < ((uint256)var9));
    }

    if(var9 != 0x0) {
        var6 = ((int256)$msg.value) * 0xc2 / 0x64;
    }

    var9 = storage[0x5];
    var9 = (uint256)($msg.value >= ((uint256)var9));

    if(var9 != 0x0) {
        var9 = storage[0x6];
        var9 = (uint256)($msg.value < ((uint256)var9));
    }

    if(var9 != 0x0) {
        var6 = ((int256)$msg.value) * 0xc5 / 0x64;
    }

    var9 = storage[0x6];

    if($msg.value >= ((uint256)var9)) {
        var6 = ((int256)$msg.value) * 0xc6 / 0x64;
    }

    var9 = storage[0x7];
    transfer(address(var9), var4);
    g0_0 = var2;
    var9 = storage[0x2];
    var10 = var2;

    if(var9 == 0x0) {
        invalid();
    }

    var9 = ((uint256)var10) / ((uint256)var9) != 0x1 ? 0x0: 0x1;
    int256 var8 = var9;

    if(((uint256)(var1 != 0x0)) == ((uint256)(var9 != 0x0))) {
        transfer(address(var3), var6);
        var10 = *0x40;
        *var10 = (uint256)(var1 != 0x0);
        *(var10 + 0x20) = var6;
        var11 = msg.sender;
        *(var10 + 0x40) = msg.sender;
        *(var10 + 0x60) = (uint256)(var8 != 0x0);
        var9 = var10;
        var10 = *0x40;
        log1(var10, var9 - var10 + 0x80, 0xb393619abc45ab912044ba6355294a533649d0d7c31f7320b9e54662d2bcfcc1);
    }
    else {
        var9 = storage[0x7];
        transfer(address(var9), var5);
        var10 = *0x40;
        *var10 = (uint256)(var1 != 0x0);
        *(var10 + 0x20) = $msg.value;
        var11 = msg.sender;
        *(var10 + 0x40) = msg.sender;
        *(var10 + 0x60) = (uint256)(var8 != 0x0);
        var9 = var10;
        var10 = *0x40;
        log1(var10, var9 - var10 + 0x80, 0x905dbca88f959ed646d20dc0ca816e65d2ed3528965f683ca108b44bab521701);
    }
}
