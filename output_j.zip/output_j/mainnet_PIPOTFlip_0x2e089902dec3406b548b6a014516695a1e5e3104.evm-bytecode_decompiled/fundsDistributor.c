// Decompiled by JEB v3.7.0.201909272058

function fundsDistributor() public view /*NON-PAYABLE*/ {
    (uint256 var0, uint256* var1) = __impl_fundsDistributor();
    uint256* var4 = var1;
    var1 = *0x40;
    *var1 = (uint256)(address(((int256)var4)));
    return(var1, 0x20);
}
