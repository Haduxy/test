// Decompiled by JEB v3.7.0.201909272058

function sub_189() private view returns (uint256) {
    var0 = storage[0x5];
    return var0;
}
