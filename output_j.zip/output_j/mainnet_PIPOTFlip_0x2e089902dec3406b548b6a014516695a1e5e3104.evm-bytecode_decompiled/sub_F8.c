// Decompiled by JEB v3.7.0.201909272058

function sub_F8() public view /*NON-PAYABLE*/ {
    var1 = storage[0x6];
    return;
}
