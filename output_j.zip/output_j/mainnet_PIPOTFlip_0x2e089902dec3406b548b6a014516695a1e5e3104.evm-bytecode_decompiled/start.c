// Decompiled by JEB v3.7.0.201909272058

function start() {
    *0x40 = 0x80;
    var1 = msg.data.length;

    if(var1 >= 0x4) {
        uint256 var0 = (uint256)$msg.sig;

        if(var0 == 0x58b7b7e) {
            sub_9A();
        }

        if(var0 == 0x172e2b09) {
            sub_C1();
        }

        if(var0 == 0x1d263f67) {
            flip();
        }

        if(var0 == 0x55291dbd) {
            claimEther();
        }

        if(var0 == 0x6eaefee1) {
            sub_F8();
        }

        if(var0 == 0x74cb55fb) {
            fundsDistributor();
        }

        if(var0 == 0x8da5cb5b) {
            owner();
        }

        if(var0 == 0xa6f9dae1) {
            changeOwner();
        }

        if(var0 == 0xddca3f43) {
            fee();
        }
    }

    stop();
}
