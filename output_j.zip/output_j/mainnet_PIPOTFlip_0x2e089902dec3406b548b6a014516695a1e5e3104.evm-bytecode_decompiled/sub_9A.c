// Decompiled by JEB v3.7.0.201909272058

function sub_9A() public view /*NON-PAYABLE*/ {
    (uint256 var0, uint256* var1) = sub_189();
    uint256* var3 = var1;
    var1 = *0x40;
    *var1 = var3;
    return(var1, 0x20);
}
