// Decompiled by JEB v3.7.0.201909272058

function changeOwner() public /*NON-PAYABLE*/ {
    var2 = calldataload(0x4);
    uint256 var1 = address(var2);
    var2 = storage[0x0];
    var3 = msg.sender;

    if((address(var2)) != msg.sender) {
        revert(0x0, 0x0);
    }

    if((address(var1)) == 0x0) {
        revert(0x0, 0x0);
    }

    var3 = storage[0x0];
    storage[0x0] = (address(var1)) | (var3 & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000);
}
