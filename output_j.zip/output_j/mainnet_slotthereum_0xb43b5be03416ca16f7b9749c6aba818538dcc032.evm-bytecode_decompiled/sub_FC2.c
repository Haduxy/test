// Decompiled by JEB v3.7.0.201909272058

function sub_FC2() private pure returns (uint256) {
    uint256* var0 = *0x40;
    *0x40 = var0 + 1;
    *var0 = 0x0;
    return var0;
}
