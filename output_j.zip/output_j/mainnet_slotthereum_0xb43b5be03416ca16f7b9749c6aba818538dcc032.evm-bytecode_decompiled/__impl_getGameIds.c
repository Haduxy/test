// Decompiled by JEB v3.7.0.201909272058

function __impl_getGameIds() private view returns (uint256) {
    sub_FC2();
    sub_FC2();
    var2 = storage[0x1];
    uint256 var3 = var2;
    uint256 var4 = *0x40;
    var6 = msize();

    if(var4 <= var6) {
        var4 = msize();
    }

    *var4 = var2;
    *0x40 = var2 * 0x20 + var4 + 0x20;
    uint256 var1 = var4;
    var2 = 0x0;

    while(1) {
        var3 = storage[0x1];

        if(var2 >= var3) {
            return var1;
        }
        else {
            var4 = storage[0x1];
            uint256 var5 = var4;
            var4 = var2;

            if(var2 >= var5) {
                invalid();
            }

            uint256 $tmp = var4;
            *0x0 = 0x1;
            var4 = keccak256(0x0, 0x20);
            var3 = storage[$tmp * 0x7 + var4 + 0x1];
            var4 = var1;
            var5 = var2;

            if(*var1 <= var2) {
                invalid();
            }

            *(var5 * 0x20 + var4 + 0x20) = var3;
            ++var2;
        }
    }

    return var1;
}
