// Decompiled by JEB v3.7.0.201909272058

function sub_E41(uint256 par1) private view returns (uint256) {
    var0 = storage[0x5];
    uint256 var1 = var0 & 0xff;
    uint256 var2 = 0x1f;

    while(var2 >= 0x1) {
        uint256 var4 = par1, var5 = var2;

        if(var2 >= 0x20) {
            invalid();
        }

        uint256 var3 = (uint256)((((var5 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0 ? 0x0: (var4 >>> (0x100 - (((uint256)(0)) | (((uint256)(((uint256)(var5 + 0x1)))) << 3)))) & 0xff) * 0x100000000000000000000000000000000000000000000000000000000000000 / 0x100000000000000000000000000000000000000000000000000000000000000) & 0xff) >= 0x30);

        if(var3 != 0x0) {
            var4 = par1;
            var5 = var2;

            if(var2 >= 0x20) {
                invalid();
            }

            var3 = (uint256)((((var5 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0 ? 0x0: (var4 >>> (0x100 - (((uint256)(0)) | (((uint256)(((uint256)(var5 + 0x1)))) << 3)))) & 0xff) * 0x100000000000000000000000000000000000000000000000000000000000000 / 0x100000000000000000000000000000000000000000000000000000000000000) & 0xff) <= 0x39);
        }

        if(var3 != 0x0) {
            var4 = par1;
            var5 = var2;

            if(var2 >= 0x20) {
                invalid();
            }

            return (var5 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0 ? 0x0: (var4 >>> (0x100 - (((uint256)(0)) | (((uint256)(((uint256)(var5 + 0x1)))) << 3)))) & 0xff) * 0x100000000000000000000000000000000000000000000000000000000000000 / 0x100000000000000000000000000000000000000000000000000000000000000 - 0x30;
        }
        else {
            --var2;
        }
    }

    return var1;
}
