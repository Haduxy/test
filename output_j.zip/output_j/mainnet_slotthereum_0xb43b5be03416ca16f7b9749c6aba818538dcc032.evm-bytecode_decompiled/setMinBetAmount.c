// Decompiled by JEB v3.7.0.201909272058

function setMinBetAmount() public /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var3 = storage[0x0];
    var4 = msg.sender;

    if((address(var3)) == (address(msg.sender))) {
        g1_0 = var1;
        var4 = *0x40;
        *var4 = var1;
        emit MinBetAmountChanged(*0x40, var4 + 0x20 - *0x40);
        var2 = storage[0x3];
    }
}
