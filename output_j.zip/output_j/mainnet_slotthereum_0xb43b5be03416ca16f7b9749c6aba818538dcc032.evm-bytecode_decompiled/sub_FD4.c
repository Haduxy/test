// Decompiled by JEB v3.7.0.201909272058

function sub_FD4(uint256 par1, uint256 par2) private {
    var0 = storage[par1];
    storage[par1] = par2;

    if(((uint256)(var0 == 0x0)) <= par2) {
        *0x0 = par1;
        var2 = keccak256(0x0, 0x20);
        sub_1006(((int256)par2) * 0x7 + var2, var0 * 0x7 + var2);
    }
}
