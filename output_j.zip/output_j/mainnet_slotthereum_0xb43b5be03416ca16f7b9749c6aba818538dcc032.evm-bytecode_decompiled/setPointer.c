// Decompiled by JEB v3.7.0.201909272058

function setPointer() public /*NON-PAYABLE*/ {
    var2 = calldataload(0x4);
    uint256 var1 = var2 & 0xff;
    var3 = storage[0x0];
    var4 = msg.sender;

    if((address(var3)) == (address(msg.sender))) {
        var4 = storage[0x5];
        var3 = (var1 & 0xff) | (var4 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00);
        g3_0 = var3;
        var4 = *0x40;
        *var4 = var3 & 0xff;
        emit PointerChanged(*0x40, var4 + 0x20 - *0x40);
        var2 = storage[0x5];
    }
}
