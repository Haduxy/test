// Decompiled by JEB v3.7.0.201909272058

function placeBet() public payable {
    var2 = calldataload(0x4);
    uint256 var1 = var2 & 0xff;
    var3 = calldataload(0x24);
    var2 = var3 & 0xff;
    var8 = storage[0x3];

    if($msg.value >= var8) {
        var8 = storage[0x4];

        if($msg.value <= var8) {
            uint256 var4 = var2 - var1 + 0x1;

            if((var4 & 0xff) <= 0x7 && (var4 & 0xff) >= 0x1) {
                var9 = storage[0x1];
                uint256 var5 = var9;
                sub_FD4(var5 + 0x1, 0x1);
                var9 = storage[0x2];
                g0_0 = var9 + 0x1;
                var10 = msg.sender;
                uint256 var14 = *0x40;
                *var14 = var1 & 0xff;
                *(var14 + 0x20) = var2 & 0xff;
                *(var14 + 0x40) = $msg.value;
                emit GameRoll(*0x40, var14 + 0x60 - *0x40);
                var8 = var5;
                var10 = var5;
                var11 = storage[0x1];

                if(var10 >= var11) {
                    invalid();
                }

                uint256 $tmp = var10;
                *0x0 = 0x1;
                var10 = keccak256(0x0, 0x20);
                storage[$tmp * 0x7 + var10 + 0x1] = var8;
                var8 = msg.sender;
                var10 = var5;
                var11 = storage[0x1];

                if(var10 >= var11) {
                    invalid();
                }

                $tmp = var10;
                *0x0 = 0x1;
                var10 = keccak256(0x0, 0x20);
                var9 = $tmp * 0x7 + var10;
                var10 = storage[var9];
                storage[var9] = (address(var8)) | (var10 & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000);
                var9 = storage[0x1];
                var8 = $msg.value;
                var10 = var5;

                if(var9 <= var5) {
                    invalid();
                }

                $tmp = var10;
                *0x0 = 0x1;
                var10 = keccak256(0x0, 0x20);
                storage[$tmp * 0x7 + var10 + 0x2] = var8;
                var9 = storage[0x1];
                var8 = var1;
                var10 = var5;

                if(var9 <= var5) {
                    invalid();
                }

                $tmp = var10;
                *0x0 = 0x1;
                var10 = keccak256(0x0, 0x20);
                var9 = $tmp * 0x7 + var10 + 0x3;
                var10 = storage[var9];
                storage[var9] = (var8 & 0xff) | (var10 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00);
                var9 = storage[0x1];
                var8 = var2;
                var10 = var5;

                if(var9 <= var5) {
                    invalid();
                }

                $tmp = var10;
                *0x0 = 0x1;
                var10 = keccak256(0x0, 0x20);
                var9 = $tmp * 0x7 + var10 + 0x3;
                var10 = storage[var9];
                storage[var9] = ((var8 & 0xff) * 0x100) | (var10 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ff);
                var9 = storage[0x5];
                var8 = sub_E19(var9 & 0xff);
                var10 = storage[0x1];
                var11 = var10;
                var10 = var5;

                if(var5 >= var11) {
                    invalid();
                }

                $tmp = var10;
                *0x0 = 0x1;
                var10 = keccak256(0x0, 0x20);
                storage[$tmp * 0x7 + var10 + 0x4] = var8;
                var9 = storage[0x1];
                var10 = var5;

                if(var9 <= var5) {
                    invalid();
                }

                $tmp = var10;
                *0x0 = 0x1;
                var10 = keccak256(0x0, 0x20);
                var9 = storage[$tmp * 0x7 + var10 + 0x4];
                var8 = sub_E41(var9);
                var10 = storage[0x1];
                var11 = var10;
                var10 = var5;

                if(var5 >= var11) {
                    invalid();
                }

                $tmp = var10;
                *0x0 = 0x1;
                var10 = keccak256(0x0, 0x20);
                var9 = $tmp * 0x7 + var10 + 0x5;
                var10 = storage[var9];
                storage[var9] = (var8 & 0xff) | (var10 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00);
                var9 = storage[0x1];
                var10 = var9;
                var9 = var5;

                if(var5 >= var10) {
                    invalid();
                }

                $tmp = var9;
                *0x0 = 0x1;
                var9 = keccak256(0x0, 0x20);
                var9 = storage[$tmp * 0x7 + var9 + 0x5];
                var8 = var9;
                var9 = storage[0x5];

                if((var8 & 0xff) == (var9 & 0xff)) {
                    var8 = storage[0x5];

                    if((var8 & 0xff) <= 0x4) {
                        var9 = storage[0x5];
                        storage[0x5] = (((var9 & 0xff) + 0x1) & 0xff) | (var9 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00);
                    }
                    else {
                        var9 = storage[0x5];
                        storage[0x5] = (((var9 & 0xff) + 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff) & 0xff) | (var9 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00);
                    }
                }
                else {
                    var9 = storage[0x1];
                    var10 = var9;
                    var9 = var5;

                    if(var5 >= var10) {
                        invalid();
                    }

                    $tmp = var9;
                    *0x0 = 0x1;
                    var9 = keccak256(0x0, 0x20);
                    var9 = storage[$tmp * 0x7 + var9 + 0x5];
                    var10 = storage[0x5];
                    storage[0x5] = (var9 & 0xff) | (var10 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00);
                }

                var8 = var1 & 0xff;
                var10 = var5;
                var11 = storage[0x1];

                if(var10 >= var11) {
                    invalid();
                }

                $tmp = var10;
                *0x0 = 0x1;
                var10 = keccak256(0x0, 0x20);
                var9 = storage[$tmp * 0x7 + var10 + 0x5];
                var8 = (uint256)((var9 & 0xff) < var8);
                var9 = var8;
                var8 = (uint256)(var8 == 0x0);

                if(!var9) {
                    var8 = var2 & 0xff;
                    var10 = var5;
                    var11 = storage[0x1];

                    if(var10 >= var11) {
                        invalid();
                    }

                    $tmp = var10;
                    *0x0 = 0x1;
                    var10 = keccak256(0x0, 0x20);
                    var9 = storage[$tmp * 0x7 + var10 + 0x5];
                    var8 = (uint256)((var9 & 0xff) <= var8);
                }

                var10 = var5;

                if(var8 != 0x0) {
                    var11 = storage[0x1];

                    if(var10 >= var11) {
                        invalid();
                    }

                    $tmp = var10;
                    *0x0 = 0x1;
                    var10 = keccak256(0x0, 0x20);
                    var9 = $tmp * 0x7 + var10 + 0x5;
                    var10 = storage[var9];
                    storage[var9] = (var10 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ff) | 0xffffffffffffffff00;
                    var8 = $msg.value / 0xa * ((0xa - var4) & 0xff) + $msg.value;
                    var10 = var5;
                    var11 = storage[0x1];

                    if(var10 >= var11) {
                        invalid();
                    }

                    $tmp = var10;
                    *0x0 = 0x1;
                    var10 = keccak256(0x0, 0x20);
                    storage[$tmp * 0x7 + var10 + 0x6] = var8;
                }
                else {
                    var11 = storage[0x1];

                    if(var10 >= var11) {
                        invalid();
                    }

                    $tmp = var10;
                    *0x0 = 0x1;
                    var10 = keccak256(0x0, 0x20);
                    storage[$tmp * 0x7 + var10 + 0x6] = 0x1;
                }

                var8 = msg.sender;
                var8 &= 0xffffffffffffffffffffffffffffffffffffffff;
                var11 = var5;
                var12 = storage[0x1];

                if(var11 >= var12) {
                    invalid();
                }

                $tmp = var11;
                *0x0 = 0x1;
                var11 = keccak256(0x0, 0x20);
                var10 = storage[$tmp * 0x7 + var11 + 0x6];
                var12 = send(var8, var10);

                if(var12 == 0x0) {
                    revert(0x0, 0x0);
                }

                var9 = msg.sender;
                var10 = var5;
                var11 = var1;
                var12 = var2;
                var14 = var5;
                var15 = storage[0x1];

                if(var14 >= var15) {
                    invalid();
                }

                $tmp = var14;
                *0x0 = 0x1;
                var14 = keccak256(0x0, 0x20);
                var13 = storage[$tmp * 0x7 + var14 + 0x5];
                var15 = storage[0x1];
                var13 &= 0xff;
                var14 = $msg.value;
                uint256 var16 = var5;

                if(var15 <= var5) {
                    invalid();
                }

                $tmp = var16;
                *0x0 = 0x1;
                var16 = keccak256(0x0, 0x20);
                var15 = storage[$tmp * 0x7 + var16 + 0x6];
                var17 = storage[0x1];
                uint256 var18 = var17;
                var17 = var5;

                if(var5 >= var18) {
                    invalid();
                }

                $tmp = var17;
                *0x0 = 0x1;
                var17 = keccak256(0x0, 0x20);
                var16 = storage[$tmp * 0x7 + var17 + 0x5];
                sub_EDD((var16 / 0x100) & 0xff, var15, var14, var13, var12, var11, var10, var9);
            }
        }
    }
}
