// Decompiled by JEB v3.7.0.201909272058

function __impl_decimals() private view returns (uint256) {
    var1 = storage[0x7];
    return var1 & 0xff;
}
