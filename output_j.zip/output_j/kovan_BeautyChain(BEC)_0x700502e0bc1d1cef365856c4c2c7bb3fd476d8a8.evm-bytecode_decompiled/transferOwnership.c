// Decompiled by JEB v3.7.0.201909272058

function transferOwnership() public /*NON-PAYABLE*/ {
    var3 = msg.data.length;
    var4 = calldataload(0x4);
    __impl_transferOwnership(address(var4));
    stop();
}
