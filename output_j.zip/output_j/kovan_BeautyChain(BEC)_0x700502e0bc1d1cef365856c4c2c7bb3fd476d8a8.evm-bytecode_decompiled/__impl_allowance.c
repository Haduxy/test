// Decompiled by JEB v3.7.0.201909272058

function __impl_allowance(uint256 par1, uint256 par2) private view returns (uint256) {
    *0x0 = address(par1);
    *0x20 = 0x2;
    var1 = keccak256(0x0, 0x40);
    *0x0 = address(par2);
    *0x20 = var1;
    var1 = keccak256(0x0, 0x40);
    var1 = storage[var1];
    return var1;
}
