// Decompiled by JEB v3.7.0.201909272058

function transferFrom() public /*NON-PAYABLE*/ {
    var3 = msg.data.length;
    var4 = calldataload(0x4);
    var5 = calldataload(0x24);
    var6 = calldataload(0x44);
    uint256 var0 = __impl_transferFrom(var6, address(var5), address(var4));
    uint256* var2 = *0x40;
    *var2 = (uint256)(var0 != 0x0);
    return(*0x40, var2 + 1 - *0x40);
}
