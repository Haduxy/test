// Decompiled by JEB v3.7.0.201909272058

function __impl_pause() private {
    var1 = storage[0x3];
    int256 var0 = var1;
    var1 = msg.sender;

    if((address(var0)) != (address(msg.sender))) {
        revert(0x0, 0x0);
    }

    var1 = storage[0x3];

    if(((((uint256)var1) / 0x10000000000000000000000000000000000000000) & 0xff) != 0x0) {
        revert(0x0, 0x0);
    }

    var3 = storage[0x3];
    storage[0x3] = (var3 & 0xffffffffffffffffffffff00ffffffffffffffffffffffffffffffffffffffff) | 0xffffffffffffffff0000000000000000000000000000000000000000;
    emit Pause(*0x40, 0x0);
}
