// Decompiled by JEB v3.7.0.201909272058

function pause() public /*NON-PAYABLE*/ {
    __impl_pause();
    stop();
}
