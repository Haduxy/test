// Decompiled by JEB v3.7.0.201909272058

function owner() public view /*NON-PAYABLE*/ {
    (uint256 var0, uint256 var1) = __impl_owner();
    uint256* var3 = *0x40;
    *var3 = address(var1);
    return(*0x40, var3 + 1 - *0x40);
}
