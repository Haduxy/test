// Decompiled by JEB v3.7.0.201909272058

function sub_1479(uint256 par1, uint256 par2) private pure returns (uint256) {
    uint256 var1 = par1 + par2;

    if(par1 > var1) {
        invalid();
    }

    return var1;
}
