// Decompiled by JEB v3.7.0.201909272058

function __impl_name() private view returns (uint256) {
    var1 = storage[0x4];
    var1 = ((((uint256)((var1 & 0x1) == 0x0)) * 0x100 - 0x1) & var1) / 0x2;
    uint256* var2 = *0x40;
    *0x40 = ((uint256)((var1 + 0x1f) / 0x20 * 0x20 + ((int256)var2))) + 0x20;
    uint256* var0 = var2;
    *var2 = var1;
    uint256* var3 = var2 + 1;
    var5 = storage[0x4];
    var5 = ((uint256)((((uint256)(((uint256)(((int256)var5) & 0x1)) == 0x0)) * 0x100 - 0x1) & ((int256)var5))) / 0x2;

    if(!((unsigned char)(((int256)var5) == 0x0))) {

        if(!((unsigned char)(((int256)var5) > 0x1f))) {
            var8 = storage[0x4];
            *var3 = var8 / 0x100 * 0x100;
        }
        else {
            uint256* $tmp = var3;
            var3 = (uint256*)(((int256)var3) + ((int256)var5));
            uint256* var4 = $tmp;
            *0x0 = 0x4;
            var5 = keccak256(0x0, 0x20);
            $tmp = var5;
            var5 = var4;
            var4 = $tmp;

            do {
                var6 = storage[var4];
                *var5 = var6;
                var4 = (uint256*)(((char*)var4) + 0x1);
                ++var5;
            }
            while(((unsigned char)(((int256)var3) > ((int256)var5))));
        }
    }

    return var0;
}
