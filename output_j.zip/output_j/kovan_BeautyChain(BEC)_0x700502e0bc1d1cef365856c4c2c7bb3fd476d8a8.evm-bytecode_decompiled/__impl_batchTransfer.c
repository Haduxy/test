// Decompiled by JEB v3.7.0.201909272058

function __impl_batchTransfer(uint256 par1, uint256 par2) private returns (uint256) {
    var5 = storage[0x3];

    if(((var5 / 0x10000000000000000000000000000000000000000) & 0xff) != 0x0) {
        revert(0x0, 0x0);
    }

    int256 var1 = *par1;
    uint256 var2 = par2 * var1;
    uint256 var4 = (uint256)(((uint256)var1) > 0x0);

    if(var4 != 0x0) {
        var4 = (uint256)(((uint256)var1) <= 0x14);
    }

    if(var4 == 0x0) {
        revert(0x0, 0x0);
    }

    var4 = (uint256)(par2 > 0x0);

    if(var4 != 0x0) {
        var7 = msg.sender;
        *0x0 = address(msg.sender);
        *0x20 = 0x1;
        var5 = keccak256(0x0, 0x40);
        var5 = storage[var5];
        var4 = (uint256)(var2 <= var5);
    }

    if(var4 == 0x0) {
        revert(0x0, 0x0);
    }

    var8 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = 0x1;
    var6 = keccak256(0x0, 0x40);
    var6 = storage[var6];
    var4 = sub_1460(var2, var6);
    var7 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = 0x1;
    var5 = keccak256(0x0, 0x40);
    storage[var5] = var4;

    for(uint256 var3 = 0x0; var3 < ((uint256)var1); ++var3) {
        var5 = par2;
        var8 = par1;
        uint256 var9 = var3;

        if(*par1 <= var3) {
            invalid();
        }

        *0x0 = address(*(var9 * 0x20 + var8 + 0x20));
        *0x20 = 0x1;
        var6 = keccak256(0x0, 0x40);
        var6 = storage[var6];
        var4 = sub_1479(var5, var6);
        var7 = par1;
        var8 = var3;

        if(*par1 <= var3) {
            invalid();
        }

        *0x0 = address(*(var8 * 0x20 + var7 + 0x20));
        *0x20 = 0x1;
        var5 = keccak256(0x0, 0x40);
        storage[var5] = var4;
        var4 = par1;
        var5 = var3;

        if(*par1 <= var3) {
            invalid();
        }

        var4 = *(var5 * 0x20 + var4 + 0x20);
        var5 = msg.sender;
        var9 = *0x40;
        *var9 = par2;
        emit Transfer(*0x40, var9 + 0x20 - *0x40);
    }

    return 0x1;
}
