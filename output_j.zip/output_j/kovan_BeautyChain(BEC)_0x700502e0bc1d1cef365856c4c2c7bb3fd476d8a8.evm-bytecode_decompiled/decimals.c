// Decompiled by JEB v3.7.0.201909272058

function decimals() public view /*NON-PAYABLE*/ {
    (uint256 var0, uint256 var1) = __impl_decimals();
    uint256* var3 = *0x40;
    *var3 = var1 & 0xff;
    return(*0x40, var3 + 1 - *0x40);
}
