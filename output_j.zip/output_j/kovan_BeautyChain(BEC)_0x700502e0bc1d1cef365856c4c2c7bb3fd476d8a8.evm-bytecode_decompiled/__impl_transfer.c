// Decompiled by JEB v3.7.0.201909272058

function __impl_transfer(uint256 par1, uint256 par2) private returns (uint256) {
    var2 = storage[0x3];

    if(((var2 / 0x10000000000000000000000000000000000000000) & 0xff) != 0x0) {
        revert(0x0, 0x0);
    }

    return sub_1497(par2, par1);
}
