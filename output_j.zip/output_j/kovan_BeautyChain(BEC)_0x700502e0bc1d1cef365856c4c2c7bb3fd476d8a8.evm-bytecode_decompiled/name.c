// Decompiled by JEB v3.7.0.201909272058

function name() public view /*NON-PAYABLE*/ {
    (uint256 var0, uint256* var1) = __impl_name();
    uint256* var2 = *0x40;
    uint256* var4 = var2 + 1;
    *var2 = (uint256)(((int256)var4) - ((int256)var2));
    *var4 = *var1;
    ++var4;
    uint256* var6 = *var1;
    uint256 var7 = *var1;
    uint256* var8 = var4;
    uint256 var9 = var1 + 1;

    for(uint256 var10 = 0x0; var10 < var7; var10 += 0x20) {
        *((uint256*)(((int256)var8) + var10)) = *(var9 + var10);
    }

    var4 = (uint256*)(((int256)var4) + ((int256)var6));
    uint256 var5 = (uint256)(((int256)var6) & 0x1f);

    if(var5 != 0x0) {
        var6 = (uint256*)(((int256)var4) - var5);
        *var6 = ~(0x100 ** 0x20 - var5 - 0x1) & *var6;
        var4 = var6 + 1;
    }

    return(*0x40, ((uint256)(((int256)var4) - *0x40)));
}
