// Decompiled by JEB v3.7.0.201909272058

function __impl_transferOwnership(uint256 par1) private {
    var1 = storage[0x3];
    int256 var0 = var1;
    var1 = msg.sender;

    if((address(var0)) != (address(msg.sender))) {
        revert(0x0, 0x0);
    }

    if((address(par1)) == 0x0) {
        revert(0x0, 0x0);
    }

    var2 = storage[0x3];
    emit OwnershipTransferred(*0x40, 0x0);
    var3 = storage[0x3];
    storage[0x3] = ((address(par1)) * 0x1) | (var3 & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000);
}
