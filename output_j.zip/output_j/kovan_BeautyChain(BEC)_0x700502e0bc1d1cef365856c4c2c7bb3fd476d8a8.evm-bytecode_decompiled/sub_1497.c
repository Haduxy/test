// Decompiled by JEB v3.7.0.201909272058

function sub_1497(uint256 par1, uint256 par2) private returns (uint256) {

    if((address(par1)) == 0x0) {
        revert(0x0, 0x0);
    }

    uint256 var1 = (uint256)(par2 > 0x0);

    if(var1 != 0x0) {
        var3 = msg.sender;
        *0x0 = address(msg.sender);
        *0x20 = 0x1;
        var1 = keccak256(0x0, 0x40);
        var1 = storage[var1];
        var1 = (uint256)(par2 <= var1);
    }

    if(var1 == 0x0) {
        revert(0x0, 0x0);
    }

    var5 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = 0x1;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3];
    var1 = sub_1460(par2, var3);
    var4 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = 0x1;
    var2 = keccak256(0x0, 0x40);
    storage[var2] = var1;
    *0x0 = address(par1);
    *0x20 = 0x1;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3];
    var1 = sub_1479(par2, var3);
    *0x0 = address(par1);
    *0x20 = 0x1;
    var2 = keccak256(0x0, 0x40);
    storage[var2] = var1;
    var2 = msg.sender;
    uint256* var6 = *0x40;
    *var6 = par2;
    emit Transfer(*0x40, var6 + 1 - *0x40);
    return 0x1;
}
