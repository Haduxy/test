// Decompiled by JEB v3.7.0.201909272058

function __impl_paused() private view returns (uint256) {
    var1 = storage[0x3];
    return (var1 / 0x10000000000000000000000000000000000000000) & 0xff;
}
