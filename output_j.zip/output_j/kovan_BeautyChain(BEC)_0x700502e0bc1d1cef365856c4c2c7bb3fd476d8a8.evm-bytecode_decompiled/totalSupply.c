// Decompiled by JEB v3.7.0.201909272058

function totalSupply() public view /*NON-PAYABLE*/ {
    (uint256 var0, uint256 var1) = __impl_totalSupply();
    uint256* var3 = *0x40;
    *var3 = var1;
    return(*0x40, var3 + 1 - *0x40);
}
