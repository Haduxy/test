// Decompiled by JEB v3.7.0.201909272058

function hasConfirmed() public /*NON-PAYABLE*/ {
    var1 = calldataload(0x4);
    var3 = calldataload(0x24);
    var6 = msg.data.length;
    *(*0x40 + 0x20) = 0x0;
    uint256 var8 = *0x40;
    calldatacopy(var8, 0x0, var6);
    uint256 var7 = *0x40;
    var12 = gasleft();
    var6 = delegatecall(var12 - 0x32, 0xd7ee1ad92d89bf79ded65083c315ead4b39d1b89, var7, var6 + var8 - var7, var7, 0x20);

    if(var6 == 0x0) {
        invalid();
    }
}
