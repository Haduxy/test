// Decompiled by JEB v3.7.0.201909272058

function __impl_isOwner(uint256 par1) private returns (uint256) {
    var3 = msg.data.length;
    *(*0x40 + 0x20) = 0x0;
    uint256 var5 = *0x40;
    calldatacopy(var5, 0x0, var3);
    uint256 var4 = *0x40;
    var9 = gasleft();
    var3 = delegatecall(var9 - 0x32, 0xd7ee1ad92d89bf79ded65083c315ead4b39d1b89, var4, var3 + var5 - var4, var4, 0x20);

    if(var3 == 0x0) {
        invalid();
    }

    return **0x40;
}
