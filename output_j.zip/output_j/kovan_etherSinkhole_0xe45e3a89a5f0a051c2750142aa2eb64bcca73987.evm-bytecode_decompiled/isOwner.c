// Decompiled by JEB v3.7.0.201909272058

function isOwner() public /*NON-PAYABLE*/ {
    var2 = calldataload(0x4);
    uint256 var0 = __impl_isOwner(address(var2));
    var2 = var0;
    var0 = *0x40;
    *var0 = (uint256)(var2 != 0x0);
    return(var0, 0x20);
}
