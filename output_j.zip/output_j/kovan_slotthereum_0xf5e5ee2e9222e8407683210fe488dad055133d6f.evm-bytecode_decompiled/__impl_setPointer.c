// Decompiled by JEB v3.7.0.201909272058

function __impl_setPointer(uint256 par1) private returns (uint256) {
    uint256 var0 = 0x0;
    var2 = storage[0x0];
    int256 var1 = var2;
    var2 = msg.sender;

    if((address(var1)) == (address(msg.sender))) {
        var4 = storage[0x5];
        g3_0 = (unsigned char)par1;
        var3 = storage[0x5];
        var4 = *0x40;
        *var4 = var3 & 0xff;
        emit PointerChanged(*0x40, var4 + 1 - *0x40);
        var2 = storage[0x5];
        var0 = var2 & 0xff;
    }

    return var0;
}
