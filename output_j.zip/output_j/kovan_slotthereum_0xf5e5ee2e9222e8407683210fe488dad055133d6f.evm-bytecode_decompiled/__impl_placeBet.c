// Decompiled by JEB v3.7.0.201909272058

function __impl_placeBet(uint256 par1, uint256 par2) private returns (uint256) {
    uint256 var0;
    var5 = storage[0x3];

    if($msg.value < var5) {
        var0 = 0x0;
    }
    else {
        var5 = storage[0x4];

        if($msg.value > var5) {
            var0 = 0x0;
        }
        else {
            uint256 var1 = par2 - par1 + 0x1;

            if((var1 & 0xff) > 0x9) {
                var0 = 0x0;
            }
            else if((var1 & 0xff) < 0x1) {
                var0 = 0x0;
            }
            else {
                var6 = storage[0x1];
                uint256 var2 = var6;
                var6 = storage[0x1];
                sub_134B(var6 + 0x1, 0x1);
                var7 = storage[0x2];
                g0_0 = var7 + 0x1;
                var6 = msg.sender;
                uint256 var12 = *0x40;
                *var12 = par1 & 0xff;
                var12 += 0x20;
                *var12 = par2 & 0xff;
                var12 += 0x20;
                *var12 = $msg.value;
                emit GameRoll(*0x40, var12 + 0x20 - *0x40);
                var5 = var2;
                var7 = var2;
                var8 = storage[0x1];

                if(var7 >= var8) {
                    invalid();
                }

                uint256 $tmp = var7;
                *0x0 = 0x1;
                var7 = keccak256(0x0, 0x20);
                storage[$tmp * 0x7 + var7 + 0x1] = var5;
                var5 = msg.sender;
                var7 = var2;
                var8 = storage[0x1];

                if(var7 >= var8) {
                    invalid();
                }

                $tmp = var7;
                *0x0 = 0x1;
                var7 = keccak256(0x0, 0x20);
                var6 = $tmp * 0x7 + var7;
                var8 = storage[var6];
                storage[var6] = ((address(var5)) * 0x1) | (var8 & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000);
                var5 = $msg.value;
                var7 = var2;
                var8 = storage[0x1];

                if(var7 >= var8) {
                    invalid();
                }

                $tmp = var7;
                *0x0 = 0x1;
                var7 = keccak256(0x0, 0x20);
                storage[$tmp * 0x7 + var7 + 0x2] = var5;
                var5 = par1;
                var7 = var2;
                var8 = storage[0x1];

                if(var7 >= var8) {
                    invalid();
                }

                $tmp = var7;
                *0x0 = 0x1;
                var7 = keccak256(0x0, 0x20);
                var6 = $tmp * 0x7 + var7 + 0x3;
                var8 = storage[var6];
                storage[var6] = ((var5 & 0xff) * 0x1) | (var8 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00);
                var5 = par2;
                var7 = var2;
                var8 = storage[0x1];

                if(var7 >= var8) {
                    invalid();
                }

                $tmp = var7;
                *0x0 = 0x1;
                var7 = keccak256(0x0, 0x20);
                var6 = $tmp * 0x7 + var7 + 0x3;
                var8 = storage[var6];
                storage[var6] = ((var5 & 0xff) * 0x100) | (var8 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ff);
                var7 = storage[0x5];
                var5 = sub_10A2(var7 & 0xff);
                var7 = var2;
                var8 = storage[0x1];

                if(var7 >= var8) {
                    invalid();
                }

                $tmp = var7;
                *0x0 = 0x1;
                var7 = keccak256(0x0, 0x20);
                storage[$tmp * 0x7 + var7 + 0x4] = var5;
                var7 = var2;
                var8 = storage[0x1];

                if(var7 >= var8) {
                    invalid();
                }

                $tmp = var7;
                *0x0 = 0x1;
                var7 = keccak256(0x0, 0x20);
                var6 = storage[$tmp * 0x7 + var7 + 0x4];
                var5 = sub_10CC(var6);
                var7 = var2;
                var8 = storage[0x1];

                if(var7 >= var8) {
                    invalid();
                }

                $tmp = var7;
                *0x0 = 0x1;
                var7 = keccak256(0x0, 0x20);
                var6 = $tmp * 0x7 + var7 + 0x5;
                var8 = storage[var6];
                storage[var6] = ((var5 & 0xff) * 0x1) | (var8 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00);
                var5 = par1 & 0xff;
                var7 = var2;
                var8 = storage[0x1];

                if(var7 >= var8) {
                    invalid();
                }

                $tmp = var7;
                *0x0 = 0x1;
                var7 = keccak256(0x0, 0x20);
                var7 = storage[$tmp * 0x7 + var7 + 0x5];
                var5 = (uint256)((var7 & 0xff) >= var5);

                if(var5 != 0x0) {
                    var5 = par2 & 0xff;
                    var7 = var2;
                    var8 = storage[0x1];

                    if(var7 >= var8) {
                        invalid();
                    }

                    $tmp = var7;
                    *0x0 = 0x1;
                    var7 = keccak256(0x0, 0x20);
                    var7 = storage[$tmp * 0x7 + var7 + 0x5];
                    var5 = (uint256)((var7 & 0xff) <= var5);
                }

                var7 = var2;

                if(var5 != 0x0) {
                    var8 = storage[0x1];

                    if(var7 >= var8) {
                        invalid();
                    }

                    $tmp = var7;
                    *0x0 = 0x1;
                    var7 = keccak256(0x0, 0x20);
                    var6 = $tmp * 0x7 + var7 + 0x5;
                    var8 = storage[var6];
                    storage[var6] = (var8 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ff) | 0xffffffffffffffff00;
                    var6 = $msg.value;
                    var5 = $msg.value / 0xa * ((0xa - var1) & 0xff) + $msg.value;
                    var7 = var2;
                    var8 = storage[0x1];

                    if(var7 >= var8) {
                        invalid();
                    }

                    $tmp = var7;
                    *0x0 = 0x1;
                    var7 = keccak256(0x0, 0x20);
                    storage[$tmp * 0x7 + var7 + 0x6] = var5;
                }
                else {
                    var8 = storage[0x1];

                    if(var7 >= var8) {
                        invalid();
                    }

                    $tmp = var7;
                    *0x0 = 0x1;
                    var7 = keccak256(0x0, 0x20);
                    storage[$tmp * 0x7 + var7 + 0x6] = 0x1;
                }

                var5 = msg.sender;
                var5 &= 0xffffffffffffffffffffffffffffffffffffffff;
                var8 = var2;
                var9 = storage[0x1];

                if(var8 >= var9) {
                    invalid();
                }

                $tmp = var8;
                *0x0 = 0x1;
                var8 = keccak256(0x0, 0x20);
                var7 = storage[$tmp * 0x7 + var8 + 0x6];
                var9 = send(var5, var7);

                if(var9 == 0x0) {
                    revert(0x0, 0x0);
                }

                var6 = msg.sender;
                var7 = var2;
                var8 = par1;
                var9 = par2;
                uint256 var11 = var2;
                var12 = storage[0x1];

                if(var11 >= var12) {
                    invalid();
                }

                $tmp = var11;
                *0x0 = 0x1;
                var11 = keccak256(0x0, 0x20);
                var11 = storage[$tmp * 0x7 + var11 + 0x5];
                uint256 var10 = var11 & 0xff;
                var11 = $msg.value;
                uint256 var13 = var2;
                var14 = storage[0x1];

                if(var13 >= var14) {
                    invalid();
                }

                $tmp = var13;
                *0x0 = 0x1;
                var13 = keccak256(0x0, 0x20);
                var12 = storage[$tmp * 0x7 + var13 + 0x6];
                var14 = var2;
                var15 = storage[0x1];

                if(var14 >= var15) {
                    invalid();
                }

                $tmp = var14;
                *0x0 = 0x1;
                var14 = keccak256(0x0, 0x20);
                var14 = storage[$tmp * 0x7 + var14 + 0x5];
                sub_121E((var14 / 0x100) & 0xff, var12, var11, var10, var9, var8, var7, var6);
                var0 = 0x1;
            }
        }
    }

    return var0;
}
