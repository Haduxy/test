// Decompiled by JEB v3.7.0.201909272058

function getGameIds() public view /*NON-PAYABLE*/ {
    uint256 var0 = __impl_getGameIds();
    uint256* var1 = *0x40;
    uint256* var3 = var1 + 1;
    *var1 = (uint256)(((int256)var3) - ((int256)var1));
    *var3 = *var0;
    ++var3;
    uint256 var5 = *var0 * 0x20;
    uint256 var6 = *var0 * 0x20;
    uint256* var7 = var3;
    uint256 var8 = var0 + 0x20;

    for(uint256 var9 = 0x0; var9 < var6; var9 += 0x20) {
        *((uint256*)(((int256)var7) + var9)) = *(var8 + var9);
    }

    return(*0x40, ((uint256)(((int256)var3) + var5)) - *0x40);
}
