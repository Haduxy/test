// Decompiled by JEB v3.7.0.201909272058

function __impl_getMaxBetAmount() private view returns (uint256) {
    var1 = storage[0x4];
    return var1;
}
