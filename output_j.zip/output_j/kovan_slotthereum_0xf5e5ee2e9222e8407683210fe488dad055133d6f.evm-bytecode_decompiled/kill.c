// Decompiled by JEB v3.7.0.201909272058

function kill() public /*NON-PAYABLE*/ {
    __impl_kill();
    stop();
}
