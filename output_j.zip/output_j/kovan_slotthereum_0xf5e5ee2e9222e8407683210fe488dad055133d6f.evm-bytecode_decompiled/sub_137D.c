// Decompiled by JEB v3.7.0.201909272058

function sub_137D(uint256 par1, uint256 par2) private returns (uint256) {
    uint256 var0 = par2;
    par2 = par1;

    while(par2 > var0) {
        var4 = storage[var0];
        storage[var0] = var4 & 0xffffffffffffffffffffffff0000000000000000000000000000000000000000;
        storage[var0 + 0x1] = 0x0;
        storage[var0 + 0x2] = 0x0;
        uint256 var2 = var0 + 0x3;
        var4 = storage[var2];
        storage[var2] = var4 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00;
        var2 = var0 + 0x3;
        var4 = storage[var2];
        storage[var2] = var4 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ff;
        storage[var0 + 0x4] = 0x0;
        var2 = var0 + 0x5;
        var4 = storage[var2];
        storage[var2] = var4 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00;
        var2 = var0 + 0x5;
        var4 = storage[var2];
        storage[var2] = var4 & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ff;
        storage[var0 + 0x6] = 0x0;
        var0 += 0x7;
    }

    return par2;
}
