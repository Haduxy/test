// Decompiled by JEB v3.7.0.201909272058

function sub_10A2(uint256 par1) private view returns (uint256) {

    if(par1 > 0xff) {
        par1 = 0xff;
    }

    if(par1 < 0x0) {
        par1 = 0x1;
    }

    var2 = number();
    return blockhash(var2 - par1);
}
