// Decompiled by JEB v3.7.0.201909272058

function getGameWin() public view /*NON-PAYABLE*/ {
    var3 = calldataload(0x4);
    uint256 var0 = __impl_getGameWin(var3);
    uint256* var2 = *0x40;
    *var2 = (uint256)(var0 != 0x0);
    return(*0x40, var2 + 1 - *0x40);
}
