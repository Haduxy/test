// Decompiled by JEB v3.7.0.201909272058

function getMaxBetAmount() public view /*NON-PAYABLE*/ {
    uint256 var0 = __impl_getMaxBetAmount();
    uint256* var2 = *0x40;
    *var2 = var0;
    return(*0x40, var2 + 1 - *0x40);
}
