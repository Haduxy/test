// Decompiled by JEB v3.7.0.201909272058

function __impl_getGameWin(uint256 par1) private view returns (uint256) {
    uint256 var2 = par1;
    var3 = storage[0x1];

    if(var2 >= var3) {
        invalid();
    }

    uint256 $tmp = var2;
    *0x0 = 0x1;
    var2 = keccak256(0x0, 0x20);
    var2 = storage[((int256)$tmp) * 0x7 + var2 + 0x5];
    return (var2 / 0x100) & 0xff;
}
