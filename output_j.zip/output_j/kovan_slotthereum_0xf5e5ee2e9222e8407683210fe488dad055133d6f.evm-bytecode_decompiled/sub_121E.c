// Decompiled by JEB v3.7.0.201909272058

function sub_121E(uint256 par1, uint256 par2, uint256 par3, uint256 par4, uint256 par5, uint256 par6, uint256 par7, uint256 par8) private {
    uint256* var9;

    if(par8 != 0x0) {
        var9 = *0x40;
        *var9 = par3 & 0xff;
        ++var9;
        *var9 = par4 & 0xff;
        ++var9;
        *var9 = par5 & 0xff;
        ++var9;
        *var9 = par6;
        ++var9;
        *var9 = par7;
        emit GameWin(*0x40, var9 + 1 - *0x40);
    }
    else {
        var9 = *0x40;
        *var9 = par3 & 0xff;
        ++var9;
        *var9 = par4 & 0xff;
        ++var9;
        *var9 = par5 & 0xff;
        ++var9;
        *var9 = par6;
        ++var9;
        *var9 = par7;
        emit GameLoose(*0x40, var9 + 1 - *0x40);
    }
}
