// Decompiled by JEB v3.7.0.201909272058

function __impl_setMinBetAmount(uint256 par1) private returns (uint256) {
    int256 var0 = 0x0;
    var2 = storage[0x0];
    int256 var1 = var2;
    var2 = msg.sender;

    if((address(var1)) == (address(msg.sender))) {
        g1_0 = par1;
        var2 = storage[0x3];
        uint256* var4 = *0x40;
        *var4 = var2;
        emit MinBetAmountChanged(*0x40, var4 + 1 - *0x40);
        var1 = storage[0x3];
        var0 = var1;
    }

    return var0;
}
