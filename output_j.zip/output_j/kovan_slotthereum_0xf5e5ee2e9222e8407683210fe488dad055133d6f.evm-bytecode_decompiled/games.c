// Decompiled by JEB v3.7.0.201909272058

function games() public view /*NON-PAYABLE*/ {
    var3 = calldataload(0x4);
    (uint256 var0, uint256 var1, uint256 var2, var3, uint256 var4, uint256 var5, uint256 var6, uint256 var7, uint256 var8, uint256 var9) = __impl_games(var3);
    uint256* var11 = *0x40;
    *var11 = address(var1);
    var11 = var11 + 1;
    *var11 = var2;
    var11 = var11 + 1;
    *var11 = var3;
    var11 = var11 + 1;
    *var11 = var4 & 0xff;
    var11 = var11 + 1;
    *var11 = var5 & 0xff;
    var11 = var11 + 1;
    *var11 = var6;
    var11 = var11 + 1;
    *var11 = var7 & 0xff;
    var11 = var11 + 1;
    *var11 = (uint256)(var8 != 0x0);
    var11 = var11 + 1;
    *var11 = var9;
    return(*0x40, var11 + 1 - *0x40);
}
