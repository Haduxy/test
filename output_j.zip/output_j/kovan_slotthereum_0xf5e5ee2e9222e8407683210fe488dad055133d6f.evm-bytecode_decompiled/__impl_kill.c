// Decompiled by JEB v3.7.0.201909272058

function __impl_kill() private {
    var1 = storage[0x0];
    int256 var0 = var1;
    var1 = msg.sender;

    if((address(var0)) == (address(msg.sender))) {
        var1 = storage[0x0];
        suicide(address(var1));
    }
}
