// Decompiled by JEB v3.7.0.201909272058

function setMaxBetAmount() public /*NON-PAYABLE*/ {
    var3 = calldataload(0x4);
    uint256 var0 = __impl_setMaxBetAmount(var3);
    uint256* var2 = *0x40;
    *var2 = var0;
    return(*0x40, var2 + 1 - *0x40);
}
