// Decompiled by JEB v3.7.0.201909272058

function feeTake() public payable {
    var1 = storage[0x4];
    uint256* var3 = var1;
    var1 = *0x40;
    *var1 = var3;
    return(var1, 0x20);
}
