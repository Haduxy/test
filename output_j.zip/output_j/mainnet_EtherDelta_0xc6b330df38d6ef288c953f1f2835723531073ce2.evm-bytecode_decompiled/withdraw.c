// Decompiled by JEB v3.7.0.201909272058

function withdraw() public payable {
    var1 = calldataload(0x4);

    if($msg.value > 0x0) {
        throw();
    }

    var2 = msg.sender;
    *0x0 = (uint256)(address(((int256)msg.sender)));
    codecopy(0x0, 0xca9, 0x20);
    *0x20 = *0x0;
    var2 = keccak256(0x0, 0x40);
    var2 = storage[var2];

    if(!((unsigned char)(var1 <= ((int256)var2)))) {
        throw();
    }

    var2 = msg.sender;
    var2 = (uint256*)(address(((int256)var2)));
    *0x0 = var2;
    codecopy(0x0, 0xca9, 0x20);
    *0x20 = *0x0;
    var5 = keccak256(0x0, 0x40);
    var6 = storage[var5];
    storage[var5] = var6 - var1;
    var6 = *0x40;
    var12 = gasleft();
    var5 = call(var12 - 0x8502, var2, var1, var6, 0x0, var6, 0x0);

    if(var5 == 0x0) {
        throw();
    }

    var2 = msg.sender;
    var2 = (uint256*)(address(((int256)var2)));
    *0x0 = var2;
    codecopy(0x0, 0xca9, 0x20);
    *0x20 = *0x0;
    var6 = keccak256(0x0, 0x40);
    var6 = storage[var6];
    uint256* var3 = *0x40;
    *var3 = 0x0;
    *(var3 + 1) = var2;
    *(var3 + &loc_2) = var1;
    *(var3 + 3) = var6;
    var2 = var3;
    var3 = *0x40;
    emit Withdraw(var3, ((uint256)(((int256)var2) - ((int256)var3))) + 0x80);
    stop();
}
