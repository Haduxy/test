// Decompiled by JEB v3.7.0.201909272058

function testTrade() public payable {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    var3 = calldataload(0x44);
    var4 = calldataload(0x64);
    var5 = calldataload(0x84);
    var6 = calldataload(0xa4);
    var7 = calldataload(0xc4);
    var8 = calldataload(0xe4);
    var9 = calldataload(0x104);
    var10 = calldataload(0x124);
    var11 = calldataload(0x144);
    var12 = calldataload(0x164);
    *0x0 = address(var1);
    *0x20 = 0x0;
    var17 = keccak256(0x0, 0x40);
    *0x0 = address(var12);
    *0x20 = var17;
    var14 = keccak256(0x0, 0x40);
    var14 = storage[var14];
    var14 = (uint256)(var11 > var14);
    uint256 var15 = var14;
    var14 = (uint256)(var14 == 0x0);

    if(!var15) {
        uint256 var18 = var3, var20 = var5, var22 = var7, var23 = var8, var24 = var9, var25 = var10;
        uint256* var38 = *0x40;
        *var38 = (address(var1)) * 0x1000000000000000000000000;
        var38 = (uint256*)(((char*)var38) + 0x14);
        *var38 = var2;
        ++var38;
        *var38 = (address(var3)) * 0x1000000000000000000000000;
        var38 = (uint256*)(((char*)var38) + 0x14);
        *var38 = var4;
        ++var38;
        *var38 = var5;
        ++var38;
        *var38 = var6;
        uint256 var33 = *0x40;
        var39 = gasleft();
        var32 = call_sha256(var39 - 0x61da, 0x2, 0x0, var33, var38 + 1 - var33, var33, 0x20);

        if(var32 == 0x0) {
            throw();
        }

        uint256* var31 = *0x40;
        var32 = *var31;
        *(var31 + 1) = var23 & 0xff;
        *(var31 + &loc_2) = var24;
        *(var31 + 3) = var25;
        uint256 var27 = var32;
        uint256 var30 = address(var22);
        uint256 var34 = *0x40;
        var40 = gasleft();
        var33 = call_ecrecover(var40 - 0x61da, 0x1, 0x0, var34, ((uint256)(((int256)var31) - var34)) + 0x80, var34, 0x20);

        if(var33 == 0x0) {
            throw();
        }

        var30 = (uint256)((address(**0x40)) == var30);

        if(var30 != 0x0) {
            var31 = number();
            var30 = (uint256)(((unsigned char)(var20 >= ((int256)var31))));
        }

        if(var30 != 0x0) {
            *0x0 = var27;
            *0x20 = 0x1;
            var31 = keccak256(0x0, 0x40);
            var31 = storage[var31];
            *0x0 = address(var18);
            *0x20 = 0x0;
            var33 = keccak256(0x0, 0x40);
            *0x0 = address(var22);
            *0x20 = var33;
            var29 = keccak256(0x0, 0x40);
            var29 = storage[var29];
        }

        jump 0xa6d;
    }

    uint256* var13 = var14 == 0x0 ? 0x0: 0x1;
    var2 = var13;
    var0 = *0x40;
    *var0 = (uint256)(((unsigned char)(((int256)var13) != 0x0)));
    return(var0, 0x20);
}
