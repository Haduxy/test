// Decompiled by JEB v3.7.0.201909272058

function balanceOf() public payable {
    var1 = calldataload(0x4);
    *0x0 = address(var1);
    *0x20 = 0x0;
    var4 = keccak256(0x0, 0x40);
    var5 = calldataload(0x24);
    *0x0 = address(var5);
    *0x20 = var4;
    var0 = keccak256(0x0, 0x40);
    var0 = storage[var0];
    uint256* var2 = var0;
    var0 = *0x40;
    *var0 = var2;
    return(var0, 0x20);
}
