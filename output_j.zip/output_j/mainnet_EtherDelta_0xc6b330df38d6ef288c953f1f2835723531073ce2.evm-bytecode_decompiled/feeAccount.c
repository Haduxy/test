// Decompiled by JEB v3.7.0.201909272058

function feeAccount() public payable {
    var1 = storage[0x2];
    uint256 var3 = (uint256)(address(((int256)var1)));
    var1 = *0x40;
    *var1 = address(var3);
    return(var1, 0x20);
}
