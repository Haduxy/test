// Decompiled by JEB v3.7.0.201909272058

function depositToken() public payable {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    uint256* var3 = (uint256)($msg.value > 0x0);

    if(!var3) {
        var3 = (uint256)((address(var1)) == 0x0);
    }

    if(!((unsigned char)(((int256)var3) == 0x0))) {
        throw();
    }

    var5 = msg.sender;
    var6 = address(this);
    uint256* var8 = *0x40;
    *var8 = 0x23b872dd00000000000000000000000000000000000000000000000000000000;
    int256 var9 = (int256)(((char*)var8) + 0x4);
    *var9 = address(msg.sender);
    var9 += 0x20;
    *var9 = address(address(this));
    var9 += 0x20;
    *var9 = var2;
    uint256 var7 = *0x40;
    var13 = gasleft();
    var6 = call(var13 - 0x61da, address(var1), 0x0, var7, var9 + 0x20 - var7, var7, 0x20);

    if(var6 == 0x0) {
        throw();
    }

    if(**0x40 == 0x0) {
        throw();
    }

    *0x0 = address(var1);
    *0x20 = 0x0;
    var8 = keccak256(0x0, 0x40);
    var9 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = var8;
    var7 = keccak256(0x0, 0x40);
    var8 = storage[var7];
    uint256 $tmp = (uint256)(var2 + ((int256)var8));
    storage[var7] = $tmp;
    uint256* var4 = *0x40;
    *var4 = address(var1);
    *(var4 + 1) = address(var9);
    *(var4 + &loc_2) = var2;
    *(var4 + 3) = $tmp;
    var3 = var4;
    var4 = *0x40;
    emit Deposit(var4, ((uint256)(((int256)var3) - ((int256)var4))) + 0x80);
    stop();
}
