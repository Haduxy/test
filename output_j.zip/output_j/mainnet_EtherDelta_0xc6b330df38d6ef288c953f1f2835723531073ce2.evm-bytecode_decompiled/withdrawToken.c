// Decompiled by JEB v3.7.0.201909272058

function withdrawToken() public payable {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    uint256* var3 = (uint256)($msg.value > 0x0);

    if(!var3) {
        var3 = (uint256)((address(var1)) == 0x0);
    }

    if(!((unsigned char)(((int256)var3) == 0x0))) {
        throw();
    }

    *0x0 = address(var1);
    *0x20 = 0x0;
    var7 = keccak256(0x0, 0x40);
    var8 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = var7;
    var3 = keccak256(0x0, 0x40);
    var3 = storage[var3];

    if(!((unsigned char)(var2 <= ((int256)var3)))) {
        throw();
    }

    *0x0 = address(var1);
    *0x20 = 0x0;
    var8 = keccak256(0x0, 0x40);
    var9 = msg.sender;
    *0x0 = address(msg.sender);
    uint256 $tmp = address(msg.sender);
    *0x20 = var8;
    var8 = keccak256(0x0, 0x40);
    var9 = storage[var8];
    storage[var8] = var9 - var2;
    var8 = *0x40;
    *var8 = 0xa9059cbb00000000000000000000000000000000000000000000000000000000;
    *(var8 + 0x4) = $tmp;
    *(var8 + 0x24) = var2;
    var7 = *0x40;
    var13 = gasleft();
    var6 = call(var13 - 0x61da, address(var1), 0x0, var7, var8 - var7 + 0x44, var7, 0x20);

    if(var6 == 0x0) {
        throw();
    }

    if(**0x40 == 0x0) {
        throw();
    }

    *0x0 = address(var1);
    *0x20 = 0x0;
    var8 = keccak256(0x0, 0x40);
    var9 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = var8;
    var7 = keccak256(0x0, 0x40);
    var7 = storage[var7];
    uint256* var4 = *0x40;
    *var4 = address(var1);
    *(var4 + 1) = address(var9);
    *(var4 + &loc_2) = var2;
    *(var4 + 3) = var7;
    var3 = var4;
    var4 = *0x40;
    emit Withdraw(var4, ((uint256)(((int256)var3) - ((int256)var4))) + 0x80);
    stop();
}
