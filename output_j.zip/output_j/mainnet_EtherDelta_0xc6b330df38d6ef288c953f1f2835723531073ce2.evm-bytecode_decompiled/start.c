// Decompiled by JEB v3.7.0.201909272058

function start() {
    *0x40 = 0x60;
    var0 = msg.data.length;

    if(var0 != 0x0) {
        var0 = (uint256)$msg.sig;

        if(var0 == 0xa19b14a) {
            trade();
        }

        if(var0 == 0x2e1a7d4d) {
            withdraw();
        }

        if(var0 == 0x338b5dea) {
            depositToken();
        }

        if(var0 == 0x57786394) {
            feeMake();
        }

        if(var0 == 0x65e17c9d) {
            feeAccount();
        }

        if(var0 == 0x6c86888b) {
            testTrade();
        }

        if(var0 == 0x93f0bb51) {
            order();
        }

        if(var0 == 0x9e281a98) {
            withdrawToken();
        }

        if(var0 == 0xc281309e) {
            feeTake();
        }

        if(var0 == 0xd0e30db0) {
            deposit();
        }

        if(var0 == 0xf7888aec) {
            balanceOf();
        }

        if(var0 == 0xfb6e155f) {
            availableVolume();
        }
    }

    throw();
}
