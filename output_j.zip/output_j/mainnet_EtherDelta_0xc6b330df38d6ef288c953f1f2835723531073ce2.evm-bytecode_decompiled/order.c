// Decompiled by JEB v3.7.0.201909272058

function order() public payable {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    var3 = calldataload(0x44);
    var4 = calldataload(0x64);
    var5 = calldataload(0x84);
    var6 = calldataload(0xa4);
    var7 = calldataload(0xc4);
    var8 = calldataload(0xe4);
    var9 = calldataload(0x104);

    if($msg.value > 0x0) {
        throw();
    }

    uint256* var11 = *0x40;
    *var11 = address(var1);
    *(var11 + 1) = var2;
    *(var11 + &loc_2) = address(var3);
    *(var11 + 3) = var4;
    *(var11 + &loc_4) = var5;
    *(var11 + &loc_5) = var6;
    var13 = msg.sender;
    *(var11 + &loc_6) = address(msg.sender);
    *(var11 + &loc_7) = var7 & 0xff;
    *(var11 + 8) = var8;
    *(var11 + 9) = var9;
    uint256* var10 = var11;
    var11 = *0x40;
    emit Order(var11, ((uint256)(((int256)var10) - ((int256)var11))) + 0x140);
    stop();
}
