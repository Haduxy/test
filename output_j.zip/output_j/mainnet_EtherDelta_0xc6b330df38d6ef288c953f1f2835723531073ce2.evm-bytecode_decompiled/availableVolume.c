// Decompiled by JEB v3.7.0.201909272058

function availableVolume() public payable {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    var3 = calldataload(0x44);
    var4 = calldataload(0x64);
    var5 = calldataload(0x84);
    var6 = calldataload(0xa4);
    var7 = calldataload(0xc4);
    var8 = calldataload(0xe4);
    var9 = calldataload(0x104);
    var10 = calldataload(0x124);
    uint256* var23 = *0x40;
    *var23 = (address(var1)) * 0x1000000000000000000000000;
    var23 = (uint256*)(((char*)var23) + 0x14);
    *var23 = var2;
    ++var23;
    *var23 = (address(var3)) * 0x1000000000000000000000000;
    var23 = (uint256*)(((char*)var23) + 0x14);
    *var23 = var4;
    ++var23;
    *var23 = var5;
    ++var23;
    *var23 = var6;
    uint256 var18 = *0x40;
    var24 = gasleft();
    var17 = call_sha256(var24 - 0x61da, 0x2, 0x0, var18, var23 + 1 - var18, var18, 0x20);

    if(var17 == 0x0) {
        throw();
    }

    uint256* var16 = *0x40;
    var17 = *var16;
    *(var16 + 1) = var8 & 0xff;
    *(var16 + &loc_2) = var9;
    *(var16 + 3) = var10;
    uint256 var12 = var17;
    uint256 var15 = address(var7);
    uint256 var19 = *0x40;
    var25 = gasleft();
    var18 = call_ecrecover(var25 - 0x61da, 0x1, 0x0, var19, ((uint256)(((int256)var16) - var19)) + 0x80, var19, 0x20);

    if(var18 == 0x0) {
        throw();
    }

    var15 = (uint256)((address(**0x40)) == var15);

    if(var15 != 0x0) {
        var16 = number();
        var15 = (uint256)(((unsigned char)(var5 >= ((int256)var16))));
    }

    if(var15 != 0x0) {
        *0x0 = var12;
        *0x20 = 0x1;
        var16 = keccak256(0x0, 0x40);
        var16 = storage[var16];
        *0x0 = address(var3);
        *0x20 = 0x0;
        var18 = keccak256(0x0, 0x40);
        *0x0 = address(var7);
        *0x20 = var18;
        var14 = keccak256(0x0, 0x40);
        var14 = storage[var14];
    }

    jump 0x2ac;
}
