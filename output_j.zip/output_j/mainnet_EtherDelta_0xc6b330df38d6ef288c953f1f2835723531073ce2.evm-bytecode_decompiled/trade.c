// Decompiled by JEB v3.7.0.201909272058

function trade() public payable {
    var1 = calldataload(0x4);
    var2 = calldataload(0x24);
    var3 = calldataload(0x44);
    var4 = calldataload(0x64);
    var5 = calldataload(0x84);
    var6 = calldataload(0xa4);
    var7 = calldataload(0xc4);
    var8 = calldataload(0xe4);
    var9 = calldataload(0x104);
    var10 = calldataload(0x124);
    var11 = calldataload(0x144);

    if($msg.value > 0x0) {
        throw();
    }

    uint256* var21 = *0x40;
    *var21 = (address(var1)) * 0x1000000000000000000000000;
    var21 = (uint256*)(((char*)var21) + 0x14);
    *var21 = var2;
    ++var21;
    *var21 = (address(var3)) * 0x1000000000000000000000000;
    var21 = (uint256*)(((char*)var21) + 0x14);
    *var21 = var4;
    ++var21;
    *var21 = var5;
    ++var21;
    *var21 = var6;
    int256 var16 = *0x40;
    var22 = gasleft();
    var15 = call_sha256(var22 - 0x61da, 0x2, 0x0, var16, var21 + 1 - var16, var16, 0x20);

    if(var15 == 0x0) {
        throw();
    }

    uint256* var14 = *0x40;
    var15 = *var14;
    *(var14 + 1) = var8 & 0xff;
    *(var14 + &loc_2) = var9;
    *(var14 + 3) = var10;
    uint256 var12 = var15;
    uint256 var13 = address(var7);
    int256 var17 = *0x40;
    var23 = gasleft();
    var16 = call_ecrecover(var23 - 0x61da, 0x1, 0x0, var17, ((uint256)(((int256)var14) - var17)) + 0x80, var17, 0x20);

    if(var16 == 0x0) {
        throw();
    }

    var13 = (uint256)((address(**0x40)) == var13);

    if(var13 != 0x0) {
        var14 = number();
        var13 = (uint256)(((unsigned char)(var5 >= ((int256)var14))));
    }

    if(var13 != 0x0) {
        *0x0 = var12;
        *0x20 = 0x1;
        var13 = keccak256(0x0, 0x40);
        var13 = storage[var13];
        var13 = (uint256)(var11 + var13 <= var2);
    }

    if(var13 != 0x0) {
        *0x0 = address(var1);
        *0x20 = 0x0;
        var17 = keccak256(0x0, 0x40);
        var18 = msg.sender;
        *0x0 = address(msg.sender);
        *0x20 = var17;
        var13 = keccak256(0x0, 0x40);
        var13 = storage[var13];
        var13 = (uint256)(var11 <= var13);
    }

    if(var13 != 0x0) {
        *0x0 = address(var3);
        *0x20 = 0x0;
        var17 = keccak256(0x0, 0x40);
        *0x0 = address(var7);
        *0x20 = var17;
        var13 = keccak256(0x0, 0x40);
        var13 = storage[var13];
        var13 = (uint256)(var4 * ((int256)var11) / var2 <= var13);
    }

    if(var13 == 0x0) {
        throw();
    }

    *0x0 = address(var1);
    *0x20 = 0x0;
    var14 = keccak256(0x0, 0x40);
    var16 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = var14;
    var14 = keccak256(0x0, 0x40);
    var17 = storage[var14];
    storage[var14] = var17 - var11;
    var14 = storage[0x3];
    var13 = ((int256)(0xde0b6b3a7640000 - ((int256)var14))) * ((int256)var11) / 0xde0b6b3a7640000;
    *0x0 = address(var1);
    *0x20 = 0x0;
    var14 = keccak256(0x0, 0x40);
    *0x0 = address(var7);
    *0x20 = var14;
    var14 = keccak256(0x0, 0x40);
    var17 = storage[var14];
    storage[var14] = var13 + var17;
    var14 = storage[0x3];
    var13 = ((uint256)(((int256)var11) * ((int256)(((int256*)var14))))) / 0xde0b6b3a7640000;
    *0x0 = address(var1);
    *0x20 = 0x0;
    var14 = keccak256(0x0, 0x40);
    var17 = storage[0x2];
    *0x0 = address(var17);
    *0x20 = var14;
    var14 = keccak256(0x0, 0x40);
    var17 = storage[var14];
    storage[var14] = var13 + var17;
    *0x0 = address(var3);
    *0x20 = 0x0;
    var14 = keccak256(0x0, 0x40);
    *0x0 = address(var7);
    *0x20 = var14;
    var14 = keccak256(0x0, 0x40);
    var17 = storage[var14];
    storage[var14] = var17 - var4 * ((int256)var11) / var2;
    var17 = storage[0x4];
    var13 = (0xde0b6b3a7640000 - var17) * var4 * ((int256)var11) / var2 / 0xde0b6b3a7640000;
    *0x0 = address(var3);
    *0x20 = 0x0;
    var14 = keccak256(0x0, 0x40);
    var16 = msg.sender;
    *0x0 = address(msg.sender);
    *0x20 = var14;
    var14 = keccak256(0x0, 0x40);
    var17 = storage[var14];
    storage[var14] = var13 + var17;
    var17 = storage[0x4];
    var13 = var4 * ((int256)var11) * var17 / var2 / 0xde0b6b3a7640000;
    *0x0 = address(var3);
    *0x20 = 0x0;
    var14 = keccak256(0x0, 0x40);
    var17 = storage[0x2];
    *0x0 = address(var17);
    *0x20 = var14;
    var14 = keccak256(0x0, 0x40);
    var17 = storage[var14];
    storage[var14] = var13 + var17;
    *0x0 = var12;
    *0x20 = 0x1;
    var14 = keccak256(0x0, 0x40);
    var17 = storage[var14];
    storage[var14] = var11 + var17;
    var19 = msg.sender;
    var21 = *0x40;
    *var21 = address(var1);
    ++var21;
    *var21 = var11;
    ++var21;
    *var21 = address(var3);
    ++var21;
    *var21 = var4 * ((int256)var11) / var2;
    ++var21;
    *var21 = address(var7);
    ++var21;
    *var21 = address(msg.sender);
    emit Trade(*0x40, var21 + 1 - *0x40);
    stop();
}
