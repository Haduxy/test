// Decompiled by JEB v3.7.0.201909272058

function deposit() public payable {
    var0 = msg.sender;
    var0 &= 0xffffffffffffffffffffffffffffffffffffffff;
    *0x0 = var0;
    codecopy(0x0, 0xca9, 0x20);
    *0x20 = *0x0;
    var4 = keccak256(0x0, 0x40);
    var5 = storage[var4];
    uint256 var6 = var4;
    var4 = $msg.value + var5;
    storage[var6] = var4;
    uint256* var1 = *0x40;
    *var1 = 0x0;
    *(var1 + 1) = var0;
    *(var1 + &loc_2) = $msg.value;
    *(var1 + 3) = var4;
    uint256 var2 = *0x40;
    emit Deposit(var2, ((uint256)(((int256)var1) - var2)) + 0x80);
    stop();
}
